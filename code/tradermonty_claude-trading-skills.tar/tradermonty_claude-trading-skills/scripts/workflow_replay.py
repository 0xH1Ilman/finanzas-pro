#!/usr/bin/env python3
"""Deterministic workflow contract replay harness (Issue #294, coverage 12/12).

The harness executes real offline CLIs for the Stockbee fluency, 20% study,
trade-memory, market-regime, monthly-performance-review, core-portfolio,
kanchi-dividend-weekly, shapiro-contrarian, stockbee-ep-daily, swing-opportunity-daily,
multi-asset-opportunity-daily, and strategy-research-pipeline workflows. Human decisions
and fixture-backed native API evidence are reported separately from full skill
execution. Golden outputs are comparison targets only and are never used as
replay inputs.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any

import yaml
from jsonschema import Draft202012Validator, FormatChecker
from validate_provenance import validate_provenance

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_COVERAGE = REPO_ROOT / "examples" / "workflows" / "replay-coverage.yaml"
SPEC_SCHEMA = REPO_ROOT / "examples" / "workflows" / "replay-spec.schema.json"
MANUAL_LESSONS_SCHEMA = REPO_ROOT / "examples" / "workflows" / "manual-lessons.schema.json"
TWENTY_PCT_LESSONS_SCHEMA = REPO_ROOT / "examples" / "workflows" / "twenty-pct-lessons.schema.json"
CORE_PORTFOLIO_SCHEMA = (
    REPO_ROOT / "examples" / "workflows" / "core-portfolio-weekly" / "replay-contract.schema.json"
)
KANCHI_REPLAY_SCHEMA = (
    REPO_ROOT / "examples" / "workflows" / "kanchi-dividend-weekly" / "replay-contract.schema.json"
)
EP_ANALYZE_SCHEMA = (
    REPO_ROOT / "examples" / "workflows" / "stockbee-ep-daily" / "replay-contract.schema.json"
)
MULTI_ASSET_REPLAY_SCHEMA = (
    REPO_ROOT
    / "examples"
    / "workflows"
    / "multi-asset-opportunity-daily"
    / "replay-contract.schema.json"
)
KANCHI_ACTIONABLE_VERDICTS = frozenset({"CLEAN-PASS", "PASS-CAUTION", "CONDITIONAL-PASS"})
KANCHI_FORBIDDEN_REVIEW_TOKENS = frozenset(
    {"sell", "liquidat", "trim", "exit", "reduce", "close", "redeem"}
)
VARIANTS = ("required-only", "full-path")

# Coverage 12/12 leaves no workflow deferred. This frozen baseline prevents a
# newly introduced workflow from being waved through as another deferral.
FROZEN_DEFERRED_WORKFLOWS = frozenset()

MARKET_COMPONENT_CONFIG = {
    "breadth": {
        "input": "market_breadth_components",
        "artifact": "market_breadth_report",
        "skill": "market-breadth-analyzer",
        "components": frozenset(
            {
                "breadth_level_trend",
                "ma_crossover",
                "cycle_position",
                "bearish_signal",
                "historical_percentile",
                "divergence",
            }
        ),
        "warning_flags": frozenset(),
    },
    "uptrend": {
        "input": "market_uptrend_components",
        "artifact": "uptrend_report",
        "skill": "uptrend-analyzer",
        "components": frozenset(
            {
                "market_breadth",
                "sector_participation",
                "sector_rotation",
                "momentum",
                "historical_context",
            }
        ),
        "warning_flags": frozenset({"late_cycle", "high_spread", "divergence"}),
    },
    "top_risk": {
        "input": "market_top_risk_components",
        "artifact": "top_risk_report",
        "skill": "market-top-detector",
        "components": frozenset(
            {
                "distribution_days",
                "leading_stocks",
                "defensive_rotation",
                "breadth_divergence",
                "index_technical",
                "sentiment",
            }
        ),
        "warning_flags": frozenset(),
    },
}

TIMESTAMP_FIELDS = frozenset(
    {"generated_at", "created_at", "updated_at", "last_outcome_update_at", "recorded_at"}
)
SENSITIVE_ENV_MARKERS = ("API_KEY", "TOKEN", "SECRET", "PASSWORD", "PROXY")
DIGEST_ALLOWLIST_KEYS = frozenset(
    {
        "setup_fluency_summary",
        "rule_candidates",
        "twenty_pct_cohort_summary",
        "edge_hints_yaml",
        "closed_thesis_record",
        "realized_returns",
        "native_postmortem_record",
        "coach_report",
        "coach_report_sha256",
        "postmortem_findings",
        "backtest_validation",
    }
)
RFC3339_PATTERN = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$"
)


class ReplayError(RuntimeError):
    """Fail-closed replay error with an auditable completed-step boundary."""

    def __init__(self, message: str, completed_steps: list[int] | None = None):
        super().__init__(message)
        self.completed_steps = list(completed_steps or [])


@dataclass(frozen=True)
class ExecutorRegistration:
    """An executor and its non-overridable evidence classification."""

    mode: str
    run: Callable[..., dict[str, dict[str, Any]]]
    components: tuple[str, ...] = ()


def load_yaml(path: Path) -> dict[str, Any]:
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ReplayError(f"cannot load YAML {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ReplayError(f"YAML root must be a mapping: {path}")
    return payload


def _load_json(path: Path, label: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ReplayError(f"invalid {label} JSON at {path}: {exc}") from exc


def _dump_yaml_with_digest_allowlist(payload: Any) -> str:
    """Serialize fixture evidence while marking deterministic hashes as non-secrets."""
    rendered = yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
    keys = "|".join(sorted(re.escape(key) for key in DIGEST_ALLOWLIST_KEYS))
    digest_line = re.compile(
        rf"^(\s+(?:{keys}): [0-9a-f]{{64}})$",
        re.MULTILINE,
    )
    return digest_line.sub(r"\1  # pragma: allowlist secret", rendered)


def _schema_error_details(schema: Mapping[str, Any], payload: Any) -> list[str]:
    errors = sorted(
        Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(payload),
        key=lambda error: list(error.path),
    )
    return [f"{'.'.join(map(str, error.path)) or '<root>'}: {error.message}" for error in errors]


def _require_rfc3339(value: Any, label: str) -> None:
    if not isinstance(value, str) or not RFC3339_PATTERN.fullmatch(value):
        raise ReplayError(f"{label} must be an RFC 3339 date-time with timezone")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ReplayError(f"{label} must be a valid RFC 3339 date-time: {value!r}") from exc
    if parsed.utcoffset() is None:
        raise ReplayError(f"{label} must include an RFC 3339 timezone")


def _validate_manual_contract(payload: Any, definition: str) -> None:
    schema = _load_json(MANUAL_LESSONS_SCHEMA, "manual-lessons schema")
    selected = {
        "$schema": schema["$schema"],
        "$defs": schema["$defs"],
        "$ref": f"#/$defs/{definition}",
    }
    errors = _schema_error_details(selected, payload)
    if errors:
        raise ReplayError(f"invalid manual lessons {definition} schema:\n- " + "\n- ".join(errors))


def _validate_twenty_pct_manual_contract(payload: Any, definition: str) -> None:
    schema = _load_json(TWENTY_PCT_LESSONS_SCHEMA, "twenty-percent lessons schema")
    selected = {
        "$schema": schema["$schema"],
        "$defs": schema["$defs"],
        "$ref": f"#/$defs/{definition}",
    }
    errors = _schema_error_details(selected, payload)
    if errors:
        raise ReplayError(
            f"invalid twenty-percent lessons {definition} schema:\n- " + "\n- ".join(errors)
        )


def coverage_errors(workflow_ids: set[str], coverage: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    covered = coverage.get("covered") or {}
    deferred = coverage.get("deferred") or {}
    if not isinstance(covered, dict):
        errors.append("covered must be a mapping")
        covered = {}
    if not isinstance(deferred, dict):
        errors.append("deferred must be a mapping")
        deferred = {}

    overlap = set(covered) & set(deferred)
    if overlap:
        errors.append(f"workflows cannot be both covered and deferred: {sorted(overlap)}")

    classified = set(covered) | set(deferred)
    missing = workflow_ids - classified
    unknown = classified - workflow_ids
    if missing:
        errors.append(f"missing replay coverage for workflows: {sorted(missing)}")
    if unknown:
        errors.append(f"coverage references unknown workflows: {sorted(unknown)}")

    if set(deferred) != FROZEN_DEFERRED_WORKFLOWS:
        errors.append(
            "deferred workflows must match the frozen coverage 12/12 deferred set; "
            f"expected {sorted(FROZEN_DEFERRED_WORKFLOWS)}, got {sorted(deferred)}"
        )
    for workflow_id, entry in deferred.items():
        if not isinstance(entry, dict):
            errors.append(f"deferred.{workflow_id} must be a mapping")
            continue
        if entry.get("issue") != 294:
            errors.append(f"deferred.{workflow_id}.issue must be 294")
        if not str(entry.get("reason") or "").strip():
            errors.append(f"deferred.{workflow_id}.reason is required")

    for workflow_id, entry in covered.items():
        if not isinstance(entry, dict):
            errors.append(f"covered.{workflow_id} must be a mapping")
            continue
        variants = entry.get("variants")
        if variants != list(VARIANTS):
            errors.append(
                f"covered.{workflow_id}.variants must be {list(VARIANTS)}, got {variants!r}"
            )
        if not str(entry.get("spec") or "").strip():
            errors.append(f"covered.{workflow_id}.spec is required")
    return errors


def validate_coverage(repo_root: Path, coverage_path: Path) -> dict[str, Any]:
    coverage = load_yaml(coverage_path)
    workflow_ids = {path.stem for path in (repo_root / "workflows").glob("*.yaml")}
    errors = coverage_errors(workflow_ids, coverage)
    covered = coverage.get("covered") or {}
    if not errors:
        for workflow_id, entry in covered.items():
            spec_path = (coverage_path.parent / entry["spec"]).resolve()
            summary = validate_spec(repo_root, spec_path)
            if summary["workflow_id"] != workflow_id:
                errors.append(
                    f"covered key {workflow_id!r} does not match spec workflow "
                    f"{summary['workflow_id']!r}"
                )
    if errors:
        raise ReplayError("invalid replay coverage:\n- " + "\n- ".join(errors))
    return {
        "covered": sorted(covered),
        "deferred": sorted(coverage.get("deferred") or {}),
        "variants": {workflow_id: entry["variants"] for workflow_id, entry in covered.items()},
    }


def _safe_relative(base: Path, value: str, label: str) -> Path:
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts:
        raise ReplayError(f"{label} must be a safe relative path: {value!r}")
    resolved = (base / relative).resolve()
    try:
        resolved.relative_to(base.resolve())
    except ValueError as exc:
        raise ReplayError(f"{label} escapes {base}: {value!r}") from exc
    return resolved


def _paths_overlap(left: Path, right: Path) -> bool:
    """Return whether two resolved paths are equal or one contains the other."""
    left = left.resolve()
    right = right.resolve()
    return left == right or left in right.parents or right in left.parents


def _validate_golden_dirs(
    spec_path: Path,
    variants: Mapping[str, Any],
    input_paths: Mapping[str, Path],
) -> None:
    """Keep generated trees disjoint from replay sources and from each other."""
    spec_path = spec_path.resolve()
    spec_dir = spec_path.parent
    golden_paths: dict[str, Path] = {}
    for variant_name in VARIANTS:
        label = f"variants.{variant_name}.golden_dir"
        golden = _safe_relative(spec_dir, variants[variant_name]["golden_dir"], label)
        if golden == spec_dir or _paths_overlap(golden, spec_path):
            raise ReplayError(f"{label} overlaps replay source: {golden}")
        for input_name, input_path in input_paths.items():
            if _paths_overlap(golden, input_path.parent):
                raise ReplayError(
                    f"{label} overlaps replay source inputs.{input_name} parent: "
                    f"{input_path.parent}"
                )
        if golden.exists() and not golden.is_dir():
            raise ReplayError(f"{label} must resolve to a directory: {golden}")
        golden_paths[variant_name] = golden

    required = golden_paths["required-only"]
    full = golden_paths["full-path"]
    if _paths_overlap(required, full):
        raise ReplayError(
            f"variant golden_dir paths overlap: required-only={required}, full-path={full}"
        )


def _validate_runtime_output(
    repo_root: Path,
    spec_path: Path,
    spec: Mapping[str, Any],
    inputs: Mapping[str, Path],
    output_dir: Path,
) -> None:
    """Reject runtime destinations that could replace replay source data."""
    output = output_dir.resolve()
    if output.exists() and not output.is_dir():
        raise ReplayError(f"output_dir must be a directory: {output}")
    protected: dict[str, Path] = {
        "repository root": repo_root.resolve(),
        "replay spec": spec_path.resolve(),
        "replay spec directory": spec_path.resolve().parent,
    }
    for name, path in inputs.items():
        protected[f"inputs.{name} parent"] = path.resolve().parent
    for variant in VARIANTS:
        protected[f"variants.{variant}.golden_dir"] = _safe_relative(
            spec_path.resolve().parent,
            spec["variants"][variant]["golden_dir"],
            f"variants.{variant}.golden_dir",
        )
    for label, path in protected.items():
        if _paths_overlap(output, path):
            raise ReplayError(f"output_dir overlaps protected {label}: {path}")


def validate_spec(repo_root: Path, spec_path: Path) -> dict[str, Any]:
    spec = load_yaml(spec_path)
    schema = _load_json(SPEC_SCHEMA, "replay-spec schema")
    schema_errors = _schema_error_details(schema, spec)
    if schema_errors:
        raise ReplayError("invalid replay spec schema:\n- " + "\n- ".join(schema_errors))
    # jsonschema treats formats without optional validators as annotations.
    # Enforce the normalization anchor independently in every environment.
    _require_rfc3339(spec["fixed_timestamp"], "fixed_timestamp")

    workflow_id = spec["workflow_id"]
    workflow_path = repo_root / "workflows" / f"{workflow_id}.yaml"
    workflow = load_yaml(workflow_path)
    if workflow.get("id") != workflow_id:
        raise ReplayError(f"workflow id mismatch in {workflow_path}")

    workflow_steps = {int(step["step"]): step for step in workflow["steps"]}
    spec_steps = {int(step["step"]): step for step in spec["steps"]}
    if set(spec_steps) != set(workflow_steps):
        raise ReplayError(
            f"spec steps must exactly match workflow steps: expected {sorted(workflow_steps)}, "
            f"got {sorted(spec_steps)}"
        )

    native_steps: list[int] = []
    native_api_steps: list[int] = []
    manual_steps: list[int] = []
    composite_steps: list[int] = []
    executor_components: dict[int, list[str]] = {}
    output_path_owners: dict[Path, str] = {}
    provenance_declaration_owners: dict[str, int] = {}
    for number, step in workflow_steps.items():
        replay_step = spec_steps[number]
        expected_outputs = set(step.get("produces") or [])
        configured_outputs = set((replay_step.get("output_files") or {}).keys())
        if expected_outputs != configured_outputs:
            raise ReplayError(
                f"step {number} output_files must match produces: "
                f"expected {sorted(expected_outputs)}, got {sorted(configured_outputs)}"
            )
        for artifact_id in replay_step.get("required_provenance", []):
            roles = replay_step["output_files"].get(artifact_id)
            canonical = roles.get("canonical") if roles else None
            if not canonical or Path(canonical).suffix.lower() not in {".json", ".yaml", ".yml"}:
                raise ReplayError(
                    f"step {number} required_provenance {artifact_id!r} must name a produced "
                    "artifact with a canonical JSON/YAML file"
                )
            previous_step = provenance_declaration_owners.get(artifact_id)
            if previous_step is not None:
                raise ReplayError(
                    f"duplicate required_provenance declaration for artifact {artifact_id!r}: "
                    f"step {previous_step} and step {number}"
                )
            provenance_declaration_owners[artifact_id] = number
        expected_policy = (
            {"record_only", "continue", "halt"} if step.get("decision_gate") else {"continue"}
        )
        if replay_step["gate_policy"] not in expected_policy:
            raise ReplayError(
                f"step {number} gate_policy {replay_step['gate_policy']!r} is incompatible "
                f"with decision_gate={bool(step.get('decision_gate'))}"
            )
        executor_name = replay_step["executor"]
        registration = EXECUTORS.get(executor_name)
        if registration is None:
            raise ReplayError(f"step {number} references unknown executor {executor_name!r}")
        mode = registration.mode
        if replay_step["executor_mode"] != mode:
            raise ReplayError(
                f"step {number} executor_mode must be {mode!r} for executor "
                f"{executor_name!r}, got {replay_step['executor_mode']!r}"
            )
        configured_components = tuple(replay_step.get("executor_components") or [])
        if configured_components != registration.components:
            raise ReplayError(
                f"step {number} executor_components must be "
                f"{list(registration.components)!r} for executor {executor_name!r}, "
                f"got {list(configured_components)!r}"
            )
        if mode == "native_cli":
            native_steps.append(number)
        elif mode == "native_api":
            native_api_steps.append(number)
        elif mode == "manual_contract":
            manual_steps.append(number)
        elif mode == "composite":
            composite_steps.append(number)
            executor_components[number] = list(registration.components)
        for artifact_id, roles in replay_step["output_files"].items():
            for role, filename in roles.items():
                output_path = _safe_relative(
                    Path("/safe"), filename, f"step {number} {artifact_id}.{role}"
                )
                owner = f"step {number} {artifact_id}.{role}"
                previous_owner = output_path_owners.get(output_path)
                if previous_owner:
                    raise ReplayError(
                        f"duplicate output path {filename!r}: {previous_owner} and {owner}"
                    )
                output_path_owners[output_path] = owner

    input_paths: dict[str, Path] = {}
    for name, value in spec["inputs"].items():
        input_path = _safe_relative(spec_path.parent, value, f"inputs.{name}")
        if not input_path.is_file():
            raise ReplayError(f"inputs.{name} does not exist: {input_path}")
        input_paths[name] = input_path

    executor_required_inputs = {
        "stockbee_fluency_ingest": {"screener"},
        "stockbee_fluency_update": {"prices"},
        "manual_lessons_log": {"accepted_lessons"},
        "twenty_pct_scan": {"prices"},
        "twenty_pct_enrich": {"news"},
        "twenty_pct_update_outcomes": {"prices"},
        "manual_twenty_pct_lessons": {"accepted_lessons"},
        "trade_memory_close": {"active_thesis", "close_instruction"},
        "trade_memory_postmortem": {"realized_returns", "root_cause_decision"},
        "trade_memory_coach": {"coach_decision"},
        "trade_memory_backtest": {"backtest_metrics"},
        "strategy_research_detect_initial": {"ohlcv"},
        "strategy_research_detect_final": {"ohlcv"},
        "strategy_research_hold": {"backtest_metrics"},
        "trade_memory_lessons": {"lessons_required", "lessons_full"},
        "market_regime_breadth": {"market_breadth_components"},
        "market_regime_uptrend": {"market_uptrend_components"},
        "market_regime_top_risk": {"market_top_risk_components"},
        "market_regime_exposure": {
            "market_breadth_components",
            "market_uptrend_components",
            "market_top_risk_components",
        },
        "core_portfolio_snapshot": {"holdings_snapshot"},
        "core_portfolio_allocation": {"allocation_decision"},
        "core_portfolio_dividend": {"dividend_enrichment"},
        "core_portfolio_rebalance": {
            "rebalance_decision_required",
            "rebalance_decision_full",
        },
        "core_portfolio_journal": {
            "journal_decision_required",
            "journal_decision_full",
        },
        "monthly_aggregate": {"closed_theses"},
        "monthly_postmortem": {"postmortems", "pattern_decision"},
        "monthly_coach": {"coach_decision"},
        "monthly_backtest": {"backtest_params"},
        "monthly_skill_review": {"skill_review_target"},
        "monthly_decision_log": {"rule_change_decision"},
        "swing_circuit_breaker": {"sizing_parameters"},
        "swing_vcp_screen": {"vcp_scan"},
        "swing_momentum_burst": {"momentum_burst"},
        "swing_exhaustion_hammer": {"exhaustion_hammer"},
        "swing_canslim": {"canslim"},
        "swing_theme": {"theme"},
        "swing_validate_setups": {"validated_setups"},
        "swing_position_size": {"sizing_parameters"},
        "swing_journal": {"journal"},
        "swing_discipline": {"exposure_decision"},
        "kanchi_high_yield_screen": {"high_yield_candidates"},
        "kanchi_pullback_screen": {"pullback_candidates"},
        "kanchi_underwrite": {"underwriting_evidence", "underwriting_decision"},
        "kanchi_tax_advice": {"tax_holdings"},
        "kanchi_review_queue": {"review_monitor"},
        "kanchi_register_thesis": {"register_decision"},
        "multi_macro_regime": {"macro_components"},
        "multi_theme": {"theme_evidence"},
        "multi_news_brief": {"news_brief"},
        "multi_hypotheses": {"hypotheses_bundle", "raw_hypotheses", "gate_decision"},
        "multi_position_size": {"sizing_params"},
        "multi_register": {"register_decision"},
    }
    for number, replay_step in spec_steps.items():
        required_inputs = executor_required_inputs.get(replay_step["executor"], set())
        missing_inputs = required_inputs - set(input_paths)
        if missing_inputs:
            raise ReplayError(
                f"step {number} executor {replay_step['executor']!r} requires offline "
                f"inputs {sorted(missing_inputs)}"
            )

    expected_required = [
        number for number, step in workflow_steps.items() if not bool(step.get("optional"))
    ]
    expected_full = sorted(workflow_steps)
    variants = spec["variants"]
    if variants["required-only"]["enabled_steps"] != expected_required:
        raise ReplayError(
            "required-only enabled_steps must contain exactly the non-optional workflow steps"
        )
    if variants["full-path"]["enabled_steps"] != expected_full:
        raise ReplayError("full-path enabled_steps must contain every workflow step")
    _validate_golden_dirs(spec_path, variants, input_paths)

    return {
        "workflow_id": workflow_id,
        "variants": list(variants),
        "native_steps": native_steps,
        "native_api_steps": native_api_steps,
        "manual_contract_steps": manual_steps,
        "composite_steps": composite_steps,
        "executor_components": executor_components,
        "inputs": input_paths,
    }


def _canonicalize(value: Any, fixed_timestamp: str, replacements: Mapping[str, str]) -> Any:
    path_replacements = {}
    resolved_replacements = {}
    literal_replacements = {}
    for source, replacement in replacements.items():
        path = Path(source)
        if not path.is_absolute():
            literal_replacements[source] = replacement
            continue
        resolved = str(path.resolve())
        # Path drops the trailing separator, but directory-prefix substitutions
        # need it to preserve relative output and avoid matching sibling names.
        if source.endswith((os.sep, os.altsep) if os.altsep else (os.sep,)):
            resolved = resolved.rstrip(os.sep) + source[-1]
        if resolved in resolved_replacements:
            previous = resolved_replacements[resolved]
            if previous != replacement:
                raise ReplayError(
                    f"conflicting path replacement for {resolved}: {previous} vs {replacement}"
                )
        resolved_replacements[resolved] = replacement
        # Keep both lexical and resolved spellings: output may contain either.
        path_replacements[source] = replacement
        path_replacements.setdefault(resolved, replacement)

    # The lexical /tmp prefix can also occur inside its resolved /private/tmp
    # spelling. Replace the longer spelling first, as well as specific files
    # before their parent directory. Ordinary literal replacements retain order.
    ordered_replacements = sorted(path_replacements.items(), key=lambda item: -len(item[0]))
    ordered_replacements.extend(literal_replacements.items())
    return _canonicalize_values(value, fixed_timestamp, ordered_replacements)


def _canonicalize_values(
    value: Any, fixed_timestamp: str, replacements: list[tuple[str, str]]
) -> Any:
    if isinstance(value, dict):
        normalized: dict[str, Any] = {}
        for key, child in value.items():
            if key in TIMESTAMP_FIELDS:
                normalized[key] = fixed_timestamp
            else:
                normalized[key] = _canonicalize_values(child, fixed_timestamp, replacements)
        return normalized
    if isinstance(value, list):
        return [_canonicalize_values(item, fixed_timestamp, replacements) for item in value]
    if isinstance(value, str):
        result = value
        for source, replacement in replacements:
            result = result.replace(source, replacement)
        return result
    return value


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _normalize_json_file(
    source: Path,
    destination: Path,
    fixed_timestamp: str,
    replacements: Mapping[str, str],
) -> None:
    payload = _load_json(source, source.name)
    _write_json(destination, _canonicalize(payload, fixed_timestamp, replacements))


def _normalize_jsonl_file(
    source: Path,
    destination: Path,
    fixed_timestamp: str,
    replacements: Mapping[str, str],
) -> None:
    records = []
    try:
        for line_number, line in enumerate(source.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ReplayError(
                    f"invalid staged model book JSONL at line {line_number}: {exc}"
                ) from exc
    except OSError as exc:
        raise ReplayError(f"cannot read staged model book {source}: {exc}") from exc
    destination.parent.mkdir(parents=True, exist_ok=True)
    text = "".join(
        json.dumps(
            _canonicalize(record, fixed_timestamp, replacements),
            ensure_ascii=False,
            sort_keys=True,
        )
        + "\n"
        for record in records
    )
    destination.write_text(text, encoding="utf-8", newline="\n")


def _scrubbed_environment() -> dict[str, str]:
    return {
        key: value
        for key, value in os.environ.items()
        if not any(marker in key.upper() for marker in SENSITIVE_ENV_MARKERS)
    }


def _run_cli(
    command: list[str],
    repo_root: Path,
    *,
    path_override: Path | None = None,
    env_overrides: Mapping[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    environment = _scrubbed_environment()
    # Native CLIs print Unicode status lines. On Windows a pipe otherwise uses
    # the legacy code page, which cannot encode them, so pin stdio to UTF-8.
    environment["PYTHONIOENCODING"] = "utf-8"
    if path_override is not None:
        environment["PATH"] = str(path_override)
    if env_overrides:
        for key in env_overrides:
            if any(marker in key.upper() for marker in SENSITIVE_ENV_MARKERS):
                raise ReplayError(f"env_overrides must not set a sensitive variable: {key}")
        environment.update(env_overrides)
    completed = subprocess.run(
        command,
        cwd=repo_root,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip() or "no CLI output"
        raise ReplayError(f"native CLI failed ({completed.returncode}): {detail}")
    return completed


def _latest_report(directory: Path, pattern: str) -> Path:
    matches = sorted(directory.glob(pattern))
    if len(matches) != 1:
        raise ReplayError(
            f"expected exactly one report matching {pattern!r} in {directory}, got {len(matches)}"
        )
    return matches[0]


def _artifact_paths(
    stage: Path, output_files: Mapping[str, Mapping[str, str]]
) -> dict[str, dict[str, Any]]:
    artifacts: dict[str, dict[str, Any]] = {}
    for artifact_id, roles in output_files.items():
        artifacts[artifact_id] = {
            "files": {role: str((stage / filename).resolve()) for role, filename in roles.items()}
        }
    return artifacts


def _validate_artifact_files(
    stage: Path,
    artifacts: Mapping[str, dict[str, Any]],
    label: str,
) -> None:
    stage_root = stage.resolve()
    seen: dict[Path, str] = {}
    for artifact_id, bundle in artifacts.items():
        files = bundle.get("files") if isinstance(bundle, dict) else None
        if not isinstance(files, dict) or not files:
            raise ReplayError(f"{label} artifact {artifact_id!r} has no declared files")
        for role, raw_path in files.items():
            path = Path(raw_path).resolve()
            try:
                path.relative_to(stage_root)
            except ValueError as exc:
                raise ReplayError(
                    f"{label} artifact {artifact_id}.{role} escapes staging: {path}"
                ) from exc
            if not path.is_file():
                raise ReplayError(
                    f"{label} artifact {artifact_id}.{role} is a missing staged file: {path}"
                )
            previous = seen.get(path)
            if previous:
                raise ReplayError(
                    f"{label} has duplicate staged file {path.name!r}: "
                    f"{previous} and {artifact_id}.{role}"
                )
            seen[path] = f"{artifact_id}.{role}"


def _validate_artifact_provenance(
    artifacts: Mapping[str, dict[str, Any]],
    required: Mapping[str, int],
    label: str,
) -> None:
    """Validate canonical provenance; declarations survive mutable artifact bundles."""
    for artifact_id, bundle in artifacts.items():
        producer = required.get(artifact_id)
        context = f"{label} artifact {artifact_id!r}"
        if producer is not None:
            context += f" (provenance required by producer step {producer})"
        canonical = bundle["files"].get("canonical")
        if not canonical:
            if producer is not None:
                raise ReplayError(f"{context}: missing canonical role for data_provenance")
            continue
        path = Path(canonical)
        suffix = path.suffix.lower()
        if suffix not in {".json", ".yaml", ".yml"}:
            if producer is not None:
                raise ReplayError(f"{context}: data_provenance requires canonical JSON/YAML")
            continue
        try:
            text = path.read_text(encoding="utf-8")
            payload = json.loads(text) if suffix == ".json" else yaml.safe_load(text)
        except (OSError, UnicodeError, ValueError, yaml.YAMLError) as exc:
            raise ReplayError(
                f"{context}: cannot parse canonical provenance payload: {exc}"
            ) from exc
        has_block = isinstance(payload, dict) and "data_provenance" in payload
        if not has_block:
            if producer is not None:
                raise ReplayError(f"{context}: missing data_provenance object")
            continue
        errors = validate_provenance(payload["data_provenance"])
        if errors:
            raise ReplayError(f"{context}: invalid data_provenance:\n- " + "\n- ".join(errors))


def _artifact_file_digests(
    artifacts: Mapping[str, dict[str, Any]],
) -> dict[str, str]:
    """Seal every declared artifact file by its stable artifact-role identity."""
    digests: dict[str, str] = {}
    for artifact_id, bundle in artifacts.items():
        for role, raw_path in bundle["files"].items():
            digests[f"{artifact_id}.{role}"] = _file_sha256(Path(raw_path))
    return digests


def _stockbee_ingest(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    _consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    _load_json(inputs["screener"], "screener")
    state = work / "model_book.jsonl"
    reports = work / "reports"
    reports.mkdir(parents=True)
    script = (
        repo_root / "skills" / "stockbee-setup-fluency-trainer" / "scripts" / "build_model_book.py"
    )
    _run_cli(
        [
            sys.executable,
            str(script),
            "ingest",
            "--screener-json",
            str(inputs["screener"]),
            "--model-book",
            str(state),
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    report_out = Path(artifacts["model_book_ingest"]["files"]["canonical"])
    state_out = Path(artifacts["model_book_ingest"]["files"]["state"])
    replacements = {
        str(inputs["screener"]): "$INPUT/screener.json",
        str(state): "$STATE/model_book.jsonl",
        str(reports): "$WORK/reports",
    }
    _normalize_json_file(
        _latest_report(reports, "stockbee_setup_fluency_ingest_*.json"),
        report_out,
        spec["fixed_timestamp"],
        replacements,
    )
    _normalize_jsonl_file(state, state_out, spec["fixed_timestamp"], replacements)
    return artifacts


def _stockbee_update(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    _load_json(inputs["prices"], "prices")
    source_state = Path(consumed["model_book_ingest"]["files"]["state"])
    state = work / "model_book.jsonl"
    _normalize_jsonl_file(source_state, state, spec["fixed_timestamp"], {})
    reports = work / "reports"
    reports.mkdir(parents=True)
    script = (
        repo_root / "skills" / "stockbee-setup-fluency-trainer" / "scripts" / "build_model_book.py"
    )
    _run_cli(
        [
            sys.executable,
            str(script),
            "update",
            "--model-book",
            str(state),
            "--prices-json",
            str(inputs["prices"]),
            "--horizons",
            "3,5",
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    report_out = Path(artifacts["matured_setup_outcomes"]["files"]["canonical"])
    state_out = Path(artifacts["matured_setup_outcomes"]["files"]["state"])
    replacements = {
        str(inputs["prices"]): "$INPUT/prices.json",
        str(state): "$STATE/model_book.jsonl",
        str(reports): "$WORK/reports",
    }
    _normalize_json_file(
        _latest_report(reports, "stockbee_setup_fluency_update_*.json"),
        report_out,
        spec["fixed_timestamp"],
        replacements,
    )
    _normalize_jsonl_file(state, state_out, spec["fixed_timestamp"], replacements)
    return artifacts


def _stockbee_summarize(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    _inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    source_state = Path(consumed["matured_setup_outcomes"]["files"]["state"])
    state = work / "model_book.jsonl"
    _normalize_jsonl_file(source_state, state, spec["fixed_timestamp"], {})
    reports = work / "reports"
    reports.mkdir(parents=True)
    script = (
        repo_root / "skills" / "stockbee-setup-fluency-trainer" / "scripts" / "build_model_book.py"
    )
    _run_cli(
        [
            sys.executable,
            str(script),
            "summarize",
            "--model-book",
            str(state),
            "--group-by",
            "rating,primary_trigger,setup_tags",
            "--min-sample",
            "5",
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    summary_source = _latest_report(reports, "stockbee_setup_fluency_summary_*.json")
    replacements = {str(state): "$STATE/model_book.jsonl", str(reports): "$WORK/reports"}
    normalized = _canonicalize(
        _load_json(summary_source, "summary"), spec["fixed_timestamp"], replacements
    )
    summary_out = Path(artifacts["setup_fluency_summary"]["files"]["canonical"])
    rules_out = Path(artifacts["rule_candidates"]["files"]["canonical"])
    _write_json(summary_out, normalized)
    _write_json(
        rules_out,
        {
            "schema_version": normalized["schema_version"],
            "generated_at": spec["fixed_timestamp"],
            "rule_candidates": normalized.get("rule_candidates", []),
        },
    )
    return artifacts


def _manual_lessons(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    source = load_yaml(inputs["accepted_lessons"])
    _validate_manual_contract(source, "input")
    expected_sources = ["setup_fluency_summary", "rule_candidates"]
    if source.get("human_approved") is not True:
        raise ReplayError("accepted_lessons manual contract requires human_approved: true")
    if source.get("source_artifacts") != expected_sources:
        raise ReplayError(
            f"accepted_lessons source_artifacts must be {expected_sources}, "
            f"got {source.get('source_artifacts')!r}"
        )
    if set(consumed) != set(expected_sources):
        raise ReplayError("manual lessons did not receive both declared consumed artifacts")
    summary_path = Path(consumed["setup_fluency_summary"]["files"]["canonical"])
    rules_path = Path(consumed["rule_candidates"]["files"]["canonical"])
    summary_payload = _load_json(summary_path, "setup_fluency_summary handoff")
    rules_payload = _load_json(rules_path, "rule_candidates handoff")
    if not isinstance(summary_payload, dict) or not isinstance(rules_payload, dict):
        raise ReplayError("manual lessons consumed artifacts must be JSON objects")
    if rules_payload.get("rule_candidates") != summary_payload.get("rule_candidates"):
        raise ReplayError("rule_candidates handoff does not match setup_fluency_summary evidence")
    source_sha256 = {
        "setup_fluency_summary": hashlib.sha256(summary_path.read_bytes()).hexdigest(),
        "rule_candidates": hashlib.sha256(rules_path.read_bytes()).hexdigest(),
    }
    if source["source_sha256"] != source_sha256:
        raise ReplayError(
            "accepted_lessons source_sha256 does not match the replayed step-3 evidence"
        )
    payload = {
        "schema_version": 1,
        "workflow_id": spec["workflow_id"],
        "recorded_at": spec["fixed_timestamp"],
        "source_artifacts": expected_sources,
        "lessons": source.get("lessons") or [],
        "provenance": {
            "execution_mode": "manual_contract",
            "native_trader_memory_validated": False,
            "source_sha256": source_sha256,
            "note": "Human-approved fixture staged by replay harness; no trader-memory-core append API was executed.",
        },
    }
    _validate_manual_contract(payload, "output")
    artifacts = _artifact_paths(stage, step["output_files"])
    output = Path(artifacts["accepted_lessons_log"]["files"]["canonical"])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(_dump_yaml_with_digest_allowlist(payload), encoding="utf-8", newline="\n")
    return artifacts


def _twenty_pct_script(repo_root: Path) -> Path:
    return repo_root / "skills" / "stockbee-20pct-study" / "scripts" / "run_20pct_study.py"


def _stage_state_handoff(
    source: Path,
    destination: Path,
    fixed_timestamp: str,
) -> None:
    _normalize_jsonl_file(source, destination, fixed_timestamp, {})


def _twenty_pct_scan(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    _consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    _load_json(inputs["prices"], "twenty-percent prices")
    state = work / "events.jsonl"
    reports = work / "reports"
    reports.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(_twenty_pct_script(repo_root)),
            "scan",
            "--prices-json",
            str(inputs["prices"]),
            "--as-of",
            spec["fixed_timestamp"][:10],
            "--lookback-days",
            "5",
            "--min-price",
            "1",
            "--min-dollar-volume",
            "0",
            "--include-down-movers",
            "--state-file",
            str(state),
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    replacements = {
        str(inputs["prices"]): "$INPUT/prices.json",
        str(state): "$STATE/events.jsonl",
        str(reports): "$WORK/reports",
    }
    _normalize_json_file(
        _latest_report(reports, "stockbee_20pct_events_*.json"),
        Path(artifacts["twenty_pct_mover_events"]["files"]["canonical"]),
        spec["fixed_timestamp"],
        replacements,
    )
    _normalize_jsonl_file(
        state,
        Path(artifacts["twenty_pct_mover_events"]["files"]["state"]),
        spec["fixed_timestamp"],
        replacements,
    )
    return artifacts


def _twenty_pct_enrich(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    _load_json(inputs["news"], "twenty-percent news")
    source = consumed["twenty_pct_mover_events"]
    events = Path(source["files"]["canonical"])
    _load_json(events, "twenty-percent mover events handoff")
    state = work / "events.jsonl"
    _stage_state_handoff(Path(source["files"]["state"]), state, spec["fixed_timestamp"])
    reports = work / "reports"
    reports.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(_twenty_pct_script(repo_root)),
            "enrich",
            "--events-json",
            str(events),
            "--news-json",
            str(inputs["news"]),
            "--state-file",
            str(state),
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    replacements = {
        str(events): "$ARTIFACT/twenty_pct_mover_events.json",
        str(inputs["news"]): "$INPUT/news.json",
        str(state): "$STATE/events.jsonl",
        str(reports): "$WORK/reports",
    }
    _normalize_json_file(
        _latest_report(reports, "stockbee_20pct_enriched_*.json"),
        Path(artifacts["classified_event_study"]["files"]["canonical"]),
        spec["fixed_timestamp"],
        replacements,
    )
    _normalize_jsonl_file(
        state,
        Path(artifacts["classified_event_study"]["files"]["state"]),
        spec["fixed_timestamp"],
        replacements,
    )
    return artifacts


def _twenty_pct_update_outcomes(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    _load_json(inputs["prices"], "twenty-percent prices")
    source = consumed["classified_event_study"]
    state = work / "events.jsonl"
    _stage_state_handoff(Path(source["files"]["state"]), state, spec["fixed_timestamp"])
    reports = work / "reports"
    reports.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(_twenty_pct_script(repo_root)),
            "update-outcomes",
            "--prices-json",
            str(inputs["prices"]),
            "--horizons",
            "5",
            "--state-file",
            str(state),
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    replacements = {
        str(inputs["prices"]): "$INPUT/prices.json",
        str(state): "$STATE/events.jsonl",
        str(reports): "$WORK/reports",
    }
    _normalize_json_file(
        _latest_report(reports, "stockbee_20pct_outcome_update_*.json"),
        Path(artifacts["matured_event_outcomes"]["files"]["canonical"]),
        spec["fixed_timestamp"],
        replacements,
    )
    _normalize_jsonl_file(
        state,
        Path(artifacts["matured_event_outcomes"]["files"]["state"]),
        spec["fixed_timestamp"],
        replacements,
    )
    return artifacts


def _twenty_pct_summarize(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    _inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    source = consumed["matured_event_outcomes"]
    state = work / "events.jsonl"
    _stage_state_handoff(Path(source["files"]["state"]), state, spec["fixed_timestamp"])
    reports = work / "reports"
    reports.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(_twenty_pct_script(repo_root)),
            "summarize",
            "--state-file",
            str(state),
            "--group-by",
            "direction,catalyst.label,technical_context.pattern_label,technical_context.close_quality",
            "--min-sample",
            "1",
            "--horizon",
            "5",
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    summary_source = _latest_report(reports, "stockbee_20pct_cohort_summary_*.json")
    hints_source = _latest_report(reports, "stockbee_20pct_edge_hints_*.yaml")
    summary = _canonicalize(
        _load_json(summary_source, "twenty-percent cohort summary"),
        spec["fixed_timestamp"],
        {str(state): "$STATE/events.jsonl", str(reports): "$WORK/reports"},
    )
    hints = _canonicalize(
        _load_json(hints_source, "twenty-percent edge hints"),
        spec["fixed_timestamp"],
        {str(state): "$STATE/events.jsonl", str(reports): "$WORK/reports"},
    )
    if hints.get("edge_hints") != summary.get("rule_candidates"):
        raise ReplayError("edge_hints handoff does not match cohort summary rule_candidates")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["twenty_pct_cohort_summary"]["files"]["canonical"]), summary)
    _write_json(Path(artifacts["edge_hints_yaml"]["files"]["canonical"]), hints)
    return artifacts


def _manual_twenty_pct_lessons(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    source = load_yaml(inputs["accepted_lessons"])
    _validate_twenty_pct_manual_contract(source, "input")
    expected_sources = ["twenty_pct_cohort_summary", "edge_hints_yaml"]
    if source.get("human_approved") is not True:
        raise ReplayError("twenty-percent lessons manual contract requires human_approved: true")
    if source.get("source_artifacts") != expected_sources:
        raise ReplayError(
            f"twenty-percent source_artifacts must be {expected_sources}, "
            f"got {source.get('source_artifacts')!r}"
        )
    if set(consumed) != set(expected_sources):
        raise ReplayError("twenty-percent lessons did not receive both declared artifacts")
    summary_path = Path(consumed["twenty_pct_cohort_summary"]["files"]["canonical"])
    hints_path = Path(consumed["edge_hints_yaml"]["files"]["canonical"])
    summary = _load_json(summary_path, "twenty_pct_cohort_summary handoff")
    hints = load_yaml(hints_path)
    if hints.get("edge_hints") != summary.get("rule_candidates"):
        raise ReplayError("edge_hints handoff does not match cohort summary evidence")
    source_sha256 = {
        "twenty_pct_cohort_summary": hashlib.sha256(summary_path.read_bytes()).hexdigest(),
        "edge_hints_yaml": hashlib.sha256(hints_path.read_bytes()).hexdigest(),
    }
    if source["source_sha256"] != source_sha256:
        raise ReplayError(
            "twenty-percent lessons source_sha256 does not match replayed step-4 evidence"
        )
    payload = {
        "schema_version": 1,
        "workflow_id": spec["workflow_id"],
        "recorded_at": spec["fixed_timestamp"],
        "source_artifacts": expected_sources,
        "lessons": source.get("lessons") or [],
        "provenance": {
            "execution_mode": "manual_contract",
            "native_trader_memory_validated": False,
            "source_sha256": source_sha256,
            "note": "Human-approved fixture staged by replay harness; no trader-memory-core append API was executed.",
        },
    }
    _validate_twenty_pct_manual_contract(payload, "output")
    artifacts = _artifact_paths(stage, step["output_files"])
    output = Path(artifacts["accepted_lessons_log"]["files"]["canonical"])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(_dump_yaml_with_digest_allowlist(payload), encoding="utf-8", newline="\n")
    return artifacts


def _repo_module(repo_root: Path, module_name: str, scripts_dir: Path) -> Any:
    """Import one repository script module without invoking the uv launcher."""
    scripts_text = str(scripts_dir.resolve())
    if scripts_text not in sys.path:
        sys.path.insert(0, scripts_text)
    importlib.invalidate_caches()
    module = importlib.import_module(module_name)
    module_path = Path(module.__file__).resolve()
    if scripts_dir.resolve() not in module_path.parents:
        raise ReplayError(
            f"refusing unexpected {module_name} import outside repository skill: {module_path}"
        )
    return module


def _trader_memory_modules(repo_root: Path) -> tuple[Any, Any]:
    scripts_dir = repo_root / "skills" / "trader-memory-core" / "scripts"
    store = _repo_module(repo_root, "thesis_store", scripts_dir)
    review = _repo_module(repo_root, "thesis_review", scripts_dir)
    return store, review


def _canonical_json_bytes(
    payload: Any,
    fixed_timestamp: str,
    replacements: Mapping[str, str] | None = None,
) -> bytes:
    canonical = _canonicalize(payload, fixed_timestamp, replacements or {})
    return (json.dumps(canonical, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode()


def _payload_sha256(
    payload: Any,
    fixed_timestamp: str,
    replacements: Mapping[str, str] | None = None,
) -> str:
    return hashlib.sha256(_canonical_json_bytes(payload, fixed_timestamp, replacements)).hexdigest()


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


_ELAPSED_RE = re.compile(r" in \d+\.\d+s\b")


def _normalize_elapsed(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _normalize_elapsed(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_normalize_elapsed(v) for v in obj]
    if isinstance(obj, str):
        return _ELAPSED_RE.sub(" in <elapsed>s", obj)
    return obj


def _normalize_review_test_command(report: dict[str, Any]) -> None:
    """Replace the environment-specific pytest launcher with a replay token."""
    auto_review = report.get("auto_review")
    if not isinstance(auto_review, dict):
        raise ReplayError("skill review auto_review must be a mapping")

    status = auto_review.get("test_status")
    command = auto_review.get("test_command")
    command_statuses = {"passed", "failed", "timeout"}
    no_command_statuses = {"not_found", "tool_missing", "not_applicable", "skipped"}
    if status in no_command_statuses:
        if command is not None:
            raise ReplayError(f"skill review test_status {status!r} requires test_command: null")
        return
    if status not in command_statuses:
        raise ReplayError(f"unexpected skill review test_status: {status!r}")
    if not isinstance(command, str) or not command.strip():
        raise ReplayError(f"skill review test_status {status!r} requires a test command")

    prefixes = (
        "uv run --extra dev pytest ",
        f"{sys.executable} -m pytest ",
    )
    prefix = next((candidate for candidate in prefixes if command.startswith(candidate)), None)
    if prefix is None:
        raise ReplayError(f"unexpected skill review test command: {command!r}")

    # Keep every pytest argument byte-for-byte; only the launcher is replay metadata.
    pytest_arguments = command[len(prefix) :]
    if not pytest_arguments.strip():
        raise ReplayError("skill review test command requires pytest arguments")
    shell_markers = ("\n", "\r", "&&", "||", ";", "|", "&", ">", "<", "`", "$(")
    if any(marker in pytest_arguments for marker in shell_markers):
        raise ReplayError("skill review test command contains shell control syntax")
    auto_review["test_command"] = f"pytest {pytest_arguments}"


_PYTEST_WARNINGS_HEADER_RE = re.compile(r"^=+\s*warnings summary\s*=+$")
_PYTEST_DOCS_RE = re.compile(r"^-- Docs: https://docs\.pytest\.org/")
_PYTEST_WARNINGS_COUNT_RE = re.compile(r", \d+ warnings?(?= in \d+\.\d+s\b)")
_PYTEST_WARNING_ENTRY_RE = re.compile(
    r"^\s*(?:\S+\.py:\d+:\s*)?(?P<category>[A-Za-z_][\w.]*): (?P<message>.*)$"
)
_PYTEST_STATUS_LINE_RE = re.compile(
    r"^(?:\d+ (?:passed|failed|error|errors|skipped|deselected|xfailed|xpassed"
    r"|subtests? (?:passed|failed|skipped))|no tests ran)"
)
_PYTEST_LOCATION_LINE_RE = re.compile(r"^\S+\.py:\d+\s*$")
# Unbannered (layout B) entry: pytest 9 emits GC-time rm_rf warnings after the
# results line, without a ``warnings summary`` header or a ``-- Docs:`` footer.
_RM_RF_ENTRY_RE = re.compile(r".*_pytest/pathlib\.py:\d+: PytestWarning: \(rm_rf\) error removing ")
_RM_RF_OS_ERROR_RE = re.compile(r"<class 'OSError'>: \[Errno \d+\] Directory not empty: '")
_RM_RF_WARN_CALL_RE = re.compile(r"^\s*warnings\.warn\($")


def _remove_status_line_warnings_count(lines: list[str]) -> list[str]:
    """Remove the ``, N warnings`` fragment from the terminal status line only."""
    for index in range(len(lines) - 1, -1, -1):
        if _PYTEST_STATUS_LINE_RE.match(lines[index].strip()):
            result = list(lines)
            result[index] = _PYTEST_WARNINGS_COUNT_RE.sub("", result[index])
            return result
    return lines


def _is_warning_structural_line(line: str) -> bool:
    """True for the non-entry scaffolding lines pytest emits around warnings."""
    return (
        line.strip() == ""
        or _PYTEST_WARNINGS_HEADER_RE.match(line) is not None
        or _PYTEST_DOCS_RE.match(line) is not None
        or _PYTEST_LOCATION_LINE_RE.match(line) is not None
        or _RM_RF_OS_ERROR_RE.search(line) is not None
        or _RM_RF_WARN_CALL_RE.match(line) is not None
    )


def _is_rm_rf_warnings_noise(block: str) -> bool:
    """True when every summary entry is the known pytest temp-GC noise.

    The entry category is any identifier/dotted name, so a genuine custom
    warning class (e.g. ``DataQualityAlert``) is detected even though it does not
    end in ``Warning`` — otherwise the noise check would wrongly pass and the
    whole block (genuine warning included) would be deleted. Any line that is
    neither a parsed entry nor recognized scaffolding fails closed (block kept),
    so an unrecognized evidence line can never be silently removed.
    """
    entries = []
    for line in block.split("\n"):
        match = _PYTEST_WARNING_ENTRY_RE.match(line)
        if match is not None:
            entries.append(match)
            continue
        if not _is_warning_structural_line(line):
            return False
    if not entries:
        return False
    for match in entries:
        if match.group("category").rsplit(".", 1)[-1] != "PytestWarning":
            return False
        if "(rm_rf) error removing" not in match.group("message"):
            return False
    return True


def _strip_banner_framed_rm_rf(text: str) -> str:
    """Strip a ``warnings summary`` ... ``-- Docs:`` block that is all rm_rf noise."""
    lines = text.split("\n")
    header_index = next(
        (index for index, line in enumerate(lines) if _PYTEST_WARNINGS_HEADER_RE.match(line)),
        None,
    )
    if header_index is None:
        return text
    docs_index = next(
        (
            index
            for index in range(header_index + 1, len(lines))
            if _PYTEST_DOCS_RE.match(lines[index])
        ),
        None,
    )
    if docs_index is None:
        return text
    block = "\n".join(lines[header_index : docs_index + 1])
    if not _is_rm_rf_warnings_noise(block):
        return text
    kept = lines[:header_index] + lines[docs_index + 1 :]
    return "\n".join(_remove_status_line_warnings_count(kept))


def _strip_unbannered_tail_rm_rf(text: str) -> str:
    """Strip a trailing run of unbannered ``(rm_rf)`` warning entries.

    pytest 9 emits GC-time ``(rm_rf)`` warnings *after* the results line, without
    a ``warnings summary`` header or a ``-- Docs:`` footer, so the banner-framed
    stripper cannot observe them. Each entry is a ``pathlib.py:N: PytestWarning:
    (rm_rf) …`` line followed by an ``OSError`` detail line and a
    ``warnings.warn(`` call. Only a trailing block that is entirely this known
    noise is removed; a genuine unbannered warning (e.g. a source
    ``DeprecationWarning``) is left intact so it still surfaces as drift.
    """
    lines = text.split("\n")
    last_content_index = -1
    for index, line in enumerate(lines):
        if line == "":
            continue
        rm_rf_entry = bool(_RM_RF_ENTRY_RE.match(line)) or bool(_RM_RF_OS_ERROR_RE.match(line))
        warn_call = (
            bool(_RM_RF_WARN_CALL_RE.match(line))
            and index > 0
            and bool(_RM_RF_OS_ERROR_RE.match(lines[index - 1]))
        )
        if rm_rf_entry or warn_call:
            continue
        last_content_index = index
    block = "\n".join(lines[last_content_index + 1 :])
    if not _RM_RF_ENTRY_RE.search(block):
        return text
    kept = lines[: last_content_index + 1]
    while kept and kept[-1] == "":
        kept.pop()
    return "\n".join(_remove_status_line_warnings_count(kept))


def _strip_pytest_warning_summary(text: str) -> str:
    """Drop pytest's environment-specific ``(rm_rf)`` warnings, if present.

    The warning embeds the random pytest base-temp path and fails ``ENOTEMPTY``
    cleanup on stale local state, so it is not reproducible and must not be part
    of a replay golden. It is removed only when every warning entry is that known
    noise; genuine warnings are left intact so they still surface as drift. Both
    the banner-framed ``warnings summary`` / ``-- Docs:`` layout (other pytest
    setups) and the unbannered trailing layout (pytest 9 GC-time) are handled.
    """
    text = _strip_banner_framed_rm_rf(text)
    text = _strip_unbannered_tail_rm_rf(text)
    return text


def _normalize_review_test_output(report: dict[str, Any]) -> None:
    """Normalize captured pytest output in a skill-review report for replay."""
    auto_review = report.get("auto_review")
    if not isinstance(auto_review, dict):
        raise ReplayError("skill review auto_review must be a mapping")
    output = auto_review.get("test_output")
    if isinstance(output, str):
        auto_review["test_output"] = _strip_pytest_warning_summary(output)


def _exact_payload_sha256(payload: Any) -> str:
    rendered = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(rendered).hexdigest()


def _write_yaml(path: Path, payload: Any, *, digest_allowlist: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if digest_allowlist:
        text = _dump_yaml_with_digest_allowlist(payload)
    else:
        text = yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def _require_mapping_keys(
    payload: Any,
    *,
    label: str,
    required: set[str],
    optional: set[str] | None = None,
) -> Mapping[str, Any]:
    if not isinstance(payload, dict):
        raise ReplayError(f"{label} must be a mapping")
    missing = required - set(payload)
    unexpected = set(payload) - required - set(optional or set())
    if missing or unexpected:
        raise ReplayError(
            f"invalid {label} keys: missing={sorted(missing)}, unexpected={sorted(unexpected)}"
        )
    return payload


def _require_non_empty_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ReplayError(f"{label} must be a non-empty string")
    return value


def _require_finite_number(
    value: Any,
    label: str,
    *,
    minimum: float | None = None,
    maximum: float | None = None,
    integer: bool = False,
) -> int | float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ReplayError(f"{label} must be {'an integer' if integer else 'numeric'}")
    if integer and not isinstance(value, int):
        raise ReplayError(f"{label} must be an integer")
    if not math.isfinite(value):
        raise ReplayError(f"{label} must be finite")
    if minimum is not None and value < minimum:
        raise ReplayError(f"{label} must be >= {minimum:g}")
    if maximum is not None and value > maximum:
        raise ReplayError(f"{label} must be <= {maximum:g}")
    return value


def _trade_memory_close(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    _consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    active = load_yaml(inputs["active_thesis"])
    instruction = load_yaml(inputs["close_instruction"])
    instruction = _require_mapping_keys(
        instruction,
        label="close instruction",
        required={"thesis_id", "exit_reason", "actual_price", "actual_date", "event_date"},
    )
    thesis_store, _review = _trader_memory_modules(repo_root)
    try:
        thesis_store.validate_thesis(active)
    except Exception as exc:
        raise ReplayError(f"invalid active thesis: {exc}") from exc
    if active.get("status") != "ACTIVE":
        raise ReplayError("trade-memory close input must have status ACTIVE")
    if instruction["thesis_id"] != active.get("thesis_id"):
        raise ReplayError("close instruction thesis_id does not match active thesis")

    state_dir = work / "trade-memory-state"
    state_dir.mkdir(parents=True)
    source = state_dir / f"{active['thesis_id']}.yaml"
    _write_yaml(source, active)
    script = repo_root / "skills" / "trader-memory-core" / "scripts" / "thesis_store.py"
    _run_cli(
        [
            sys.executable,
            str(script),
            "--state-dir",
            str(state_dir),
            "close",
            str(instruction["thesis_id"]),
            "--exit-reason",
            str(instruction["exit_reason"]),
            "--actual-price",
            str(instruction["actual_price"]),
            "--actual-date",
            str(instruction["actual_date"]),
            "--event-date",
            str(instruction["event_date"]),
        ],
        repo_root,
    )
    closed = load_yaml(source)
    try:
        thesis_store.validate_thesis(closed)
    except Exception as exc:
        raise ReplayError(f"native close produced invalid thesis: {exc}") from exc
    if closed.get("status") != "CLOSED":
        raise ReplayError("native close did not produce CLOSED thesis")

    artifacts = _artifact_paths(stage, step["output_files"])
    output = Path(artifacts["closed_thesis_record"]["files"]["canonical"])
    canonical = _canonicalize(closed, spec["fixed_timestamp"], {str(state_dir): "$STATE"})
    canonical["created_at"] = closed["created_at"]
    try:
        thesis_store.validate_thesis(canonical)
    except Exception as exc:
        raise ReplayError(f"normalized close artifact is invalid: {exc}") from exc
    _write_yaml(output, canonical)
    return artifacts


def _trade_memory_postmortem(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"closed_thesis_record"}:
        raise ReplayError("trade-memory postmortem requires closed_thesis_record")
    closed_path = Path(consumed["closed_thesis_record"]["files"]["canonical"])
    closed = load_yaml(closed_path)
    realized = _load_json(inputs["realized_returns"], "realized returns")
    realized = _require_mapping_keys(
        realized,
        label="realized returns",
        required={"schema_version", "trade_direction", "returns", "regime_at_exit"},
    )
    if realized["schema_version"] != 1 or realized["trade_direction"] not in {"LONG", "SHORT"}:
        raise ReplayError("invalid realized returns contract")
    returns = realized["returns"]
    if not isinstance(returns, dict) or set(returns) != {"5d", "20d"}:
        raise ReplayError("realized returns must contain exactly 5d and 20d")
    for horizon, value in returns.items():
        _require_finite_number(value, f"realized returns {horizon}")
    _require_non_empty_string(realized["regime_at_exit"], "realized returns regime_at_exit")

    position = closed.get("position") or {}
    expected_direction = (
        position.get("direction") if position.get("asset_type") == "futures" else "LONG"
    )
    if realized["trade_direction"] != expected_direction:
        raise ReplayError("realized returns trade_direction does not match thesis position")
    if closed.get("status") != "CLOSED":
        raise ReplayError("postmortem input thesis must be CLOSED")
    entry = closed.get("entry") or {}
    exit_data = closed.get("exit") or {}
    signal = {
        "signal_id": closed["thesis_id"],
        "ticker": closed["ticker"],
        "signal_date": str(entry["actual_date"])[:10],
        "predicted_direction": realized["trade_direction"],
        "source_skill": closed["origin"]["skill"],
        "entry_price": entry["actual_price"],
        "regime": (closed.get("market_context") or {}).get("regime") or "UNKNOWN",
    }
    recorder = _repo_module(
        repo_root,
        "postmortem_recorder",
        repo_root / "skills" / "signal-postmortem" / "scripts",
    )
    native = recorder.create_postmortem_record(
        signal,
        returns,
        exit_data["actual_price"],
        str(exit_data["actual_date"])[:10],
        regime_at_exit=str(realized["regime_at_exit"]),
    )
    native = _canonicalize(native, spec["fixed_timestamp"], {})

    root_decision = load_yaml(inputs["root_cause_decision"])
    root_decision = _require_mapping_keys(
        root_decision,
        label="root cause decision",
        required={
            "human_approved",
            "thesis_id",
            "expected_native_classification",
            "expected_source_sha256",
            "classification",
            "summary",
        },
    )
    if root_decision["human_approved"] is not True:
        raise ReplayError("root cause decision requires human_approved: true")
    if root_decision["thesis_id"] != closed["thesis_id"]:
        raise ReplayError("root cause decision thesis_id mismatch")
    if root_decision["expected_native_classification"] != native["outcome_category"]:
        raise ReplayError("root cause decision native classification mismatch")
    if root_decision["classification"] not in {
        "thesis_quality",
        "execution",
        "market_environment",
        "randomness",
    }:
        raise ReplayError("root cause decision classification is invalid")
    _require_non_empty_string(root_decision["summary"], "root cause decision summary")
    expected_hashes = root_decision["expected_source_sha256"]
    actual_hashes = {
        "closed_thesis_record": _file_sha256(closed_path),
        "realized_returns": _payload_sha256(realized, spec["fixed_timestamp"]),
        "native_postmortem_record": _payload_sha256(native, spec["fixed_timestamp"]),
    }
    if expected_hashes != actual_hashes:
        raise ReplayError(
            f"root cause decision source_sha256 mismatch: expected {expected_hashes}, "
            f"actual {actual_hashes}"
        )

    payload = {
        "schema_version": 1,
        "source_snapshot": {"closed_thesis_record": closed},
        "native_postmortem": native,
        "manual_root_cause": {
            "human_approved": True,
            "classification": root_decision["classification"],
            "summary": root_decision["summary"],
        },
        "provenance": {
            "execution_mode": "composite",
            "components": ["native_api", "manual_contract"],
            "native_component": "signal-postmortem.create_postmortem_record",
            "native_classification_basis": "fixture_supplied_realized_returns",
            "source_sha256": actual_hashes,
            "source_snapshot_sha256": {"closed_thesis_record": _exact_payload_sha256(closed)},
            "limitation": "Root cause is a human-approved fixture decision, not native inference.",
        },
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["postmortem_findings"]["files"]["canonical"]), payload)
    return artifacts


def _trade_memory_coach(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"closed_thesis_record", "postmortem_findings"}:
        raise ReplayError("trade-memory coach requires closed thesis and postmortem")
    closed = load_yaml(Path(consumed["closed_thesis_record"]["files"]["canonical"]))
    postmortem = _load_json(
        Path(consumed["postmortem_findings"]["files"]["canonical"]), "postmortem findings"
    )
    created_at = datetime.fromisoformat(str(closed["created_at"]).replace("Z", "+00:00"))
    entered_at = datetime.fromisoformat(str(closed["entry"]["actual_date"]).replace("Z", "+00:00"))
    coach_input = {
        "review_id": "trade-memory-loop-fictional-exmpl",
        "review_type": "single_trade",
        "trade_id": closed["thesis_id"],
        "outcome": postmortem["native_postmortem"]["outcome_category"],
        "planned": {
            "thesis": closed["thesis_statement"],
            "thesis_recorded_before_entry": created_at <= entered_at,
            "entry_price": closed["entry"]["actual_price"],
            "stop_price": closed["exit"]["stop_loss"],
            "market_regime": closed["market_context"]["regime"],
        },
        "actual": {
            "entry_price": closed["entry"]["actual_price"],
            "exit_price": closed["exit"]["actual_price"],
        },
        "postmortem": {
            "root_cause": postmortem["manual_root_cause"]["classification"],
            "root_cause_notes": postmortem["manual_root_cause"]["summary"],
        },
    }
    input_path = work / "coach-input.json"
    _write_json(input_path, coach_input)
    reports = work / "reports"
    script = (
        repo_root / "skills" / "trade-performance-coach" / "scripts" / "review_trade_performance.py"
    )
    _run_cli(
        [
            sys.executable,
            str(script),
            "--input",
            str(input_path),
            "--output-dir",
            str(reports),
            "--json-name",
            "coach.json",
        ],
        repo_root,
    )
    coach = _load_json(reports / "coach.json", "coach report")
    coach = _canonicalize(
        coach,
        spec["fixed_timestamp"],
        # The coach records source paths with forward slashes on every platform.
        {input_path.as_posix(): "$INPUT/coach-input.json"},
    )

    decision = load_yaml(inputs["coach_decision"])
    decision = _require_mapping_keys(
        decision,
        label="coach decision",
        required={"human_approved", "action", "expected_source_sha256", "accepted_rules"},
    )
    coach_sha = _payload_sha256(coach, spec["fixed_timestamp"])
    if decision["human_approved"] is not True:
        raise ReplayError("coach decision requires human_approved: true")
    if decision["expected_source_sha256"] != {"coach_report": coach_sha}:
        raise ReplayError(
            f"coach decision source_sha256 mismatch: expected "
            f"{decision['expected_source_sha256']}, actual {{'coach_report': {coach_sha!r}}}"
        )
    if decision["action"] not in coach["human_decision_gate"]["allowed_actions"]:
        raise ReplayError("coach decision action is not allowed by native report")
    accepted_rules = decision["accepted_rules"]
    if not isinstance(accepted_rules, list) or not all(
        isinstance(rule, str) and rule.strip() for rule in accepted_rules
    ):
        raise ReplayError("coach decision accepted_rules must be a list of non-empty strings")
    native_rules = {
        item["rule"]
        for item in coach["next_session_operating_rules"]
        if isinstance(item, Mapping) and isinstance(item.get("rule"), str)
    }
    action = decision["action"]
    if action == "accept_rules" and (
        not accepted_rules or not set(accepted_rules).issubset(native_rules)
    ):
        raise ReplayError(
            "coach decision accepted_rules must come from the native coach report; "
            f"available={sorted(native_rules)}"
        )
    if action in {"defer", "journal_only"} and accepted_rules:
        raise ReplayError(f"coach decision action {action!r} cannot accept rules")
    if action == "modify_rules" and not accepted_rules:
        raise ReplayError("coach decision action 'modify_rules' requires modified rules")

    artifacts = _artifact_paths(stage, step["output_files"])
    coach_out = Path(artifacts["performance_coach_report"]["files"]["canonical"])
    _write_json(coach_out, coach)
    rules = {
        "human_approved": True,
        "action": decision["action"],
        "accepted_rules": accepted_rules,
        "provenance": {
            "execution_mode": "manual_contract",
            "coach_report_sha256": _file_sha256(coach_out),
            "native_coach_default_action": coach["human_decision_gate"]["default_action"],
        },
    }
    _write_yaml(
        Path(artifacts["next_session_operating_rules"]["files"]["canonical"]),
        rules,
        digest_allowlist=True,
    )
    return artifacts


def _trade_memory_backtest(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"postmortem_findings"}:
        raise ReplayError("trade-memory backtest evaluation requires postmortem_findings")
    metrics = _load_json(inputs["backtest_metrics"], "backtest metrics")
    required = {
        "total_trades",
        "win_rate",
        "avg_win_pct",
        "avg_loss_pct",
        "max_drawdown_pct",
        "years_tested",
        "num_parameters",
        "slippage_tested",
    }
    metrics = _require_mapping_keys(metrics, label="backtest metrics", required=required)
    _require_finite_number(
        metrics["total_trades"], "backtest total_trades", minimum=0, integer=True
    )
    _require_finite_number(metrics["win_rate"], "backtest win_rate", minimum=0, maximum=100)
    _require_finite_number(metrics["avg_win_pct"], "backtest avg_win_pct", minimum=0)
    _require_finite_number(metrics["avg_loss_pct"], "backtest avg_loss_pct", minimum=0)
    _require_finite_number(
        metrics["max_drawdown_pct"], "backtest max_drawdown_pct", minimum=0, maximum=100
    )
    _require_finite_number(
        metrics["years_tested"], "backtest years_tested", minimum=0, integer=True
    )
    _require_finite_number(
        metrics["num_parameters"], "backtest num_parameters", minimum=0, integer=True
    )
    reports = work / "reports"
    script = repo_root / "skills" / "backtest-expert" / "scripts" / "evaluate_backtest.py"
    command = [
        sys.executable,
        str(script),
        "--total-trades",
        str(metrics["total_trades"]),
        "--win-rate",
        str(metrics["win_rate"]),
        "--avg-win-pct",
        str(metrics["avg_win_pct"]),
        "--avg-loss-pct",
        str(metrics["avg_loss_pct"]),
        "--max-drawdown-pct",
        str(metrics["max_drawdown_pct"]),
        "--years-tested",
        str(metrics["years_tested"]),
        "--num-parameters",
        str(metrics["num_parameters"]),
        "--output-dir",
        str(reports),
    ]
    if metrics["slippage_tested"] is True:
        command.append("--slippage-tested")
    elif metrics["slippage_tested"] is not False:
        raise ReplayError("backtest metrics slippage_tested must be boolean")
    _run_cli(command, repo_root)
    result_path = _latest_report(reports, "backtest_eval_*.json")
    result = _load_json(result_path, "backtest evaluation")
    postmortem_path = Path(consumed["postmortem_findings"]["files"]["canonical"])
    result["provenance"] = {
        "execution": "native_cli_evaluated_fixture_metrics",
        "metrics_source": "bundled fictional aggregate metrics",
        "adapter_bound_source_sha256": {"postmortem_source_sha256": _file_sha256(postmortem_path)},
        "limitation": (
            "The native CLI evaluated supplied aggregate metrics; it did not run a strategy "
            "backtest or consume the postmortem."
        ),
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["backtest_validation"]["files"]["canonical"]), result)
    return artifacts


def _without_lesson_side_effects(thesis: Mapping[str, Any]) -> dict[str, Any]:
    clone = json.loads(json.dumps(thesis))
    clone.pop("updated_at", None)
    outcome = clone.get("outcome") or {}
    for key in ("lessons_learned", "mae_pct", "mfe_pct", "mae_mfe_source"):
        outcome.pop(key, None)
    return clone


def _trade_memory_lessons(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if "postmortem_findings" not in consumed:
        raise ReplayError("trade-memory lessons requires postmortem_findings")
    unexpected = set(consumed) - {"postmortem_findings", "backtest_validation"}
    if unexpected:
        raise ReplayError(
            f"trade-memory lessons received unexpected artifacts: {sorted(unexpected)}"
        )
    variant = "full-path" if "backtest_validation" in consumed else "required-only"
    decision_key = "lessons_full" if variant == "full-path" else "lessons_required"
    decision = load_yaml(inputs[decision_key])
    decision = _require_mapping_keys(
        decision,
        label="lessons decision",
        required={
            "human_approved",
            "variant",
            "source_artifacts",
            "source_sha256",
            "decision",
            "lesson_text",
        },
    )
    if decision["human_approved"] is not True:
        raise ReplayError("lessons decision requires human_approved: true")
    if decision["variant"] != variant:
        raise ReplayError(
            f"lessons decision variant {decision['variant']!r} does not match {variant!r}"
        )
    expected_artifacts = ["postmortem_findings"]
    if variant == "full-path":
        expected_artifacts.append("backtest_validation")
    if decision["source_artifacts"] != expected_artifacts:
        raise ReplayError("lessons decision source_artifacts do not match executed variant")
    source_hashes = {
        artifact_id: _file_sha256(Path(consumed[artifact_id]["files"]["canonical"]))
        for artifact_id in expected_artifacts
    }
    if decision["source_sha256"] != source_hashes:
        raise ReplayError(
            f"lessons decision source_sha256 mismatch: expected "
            f"{decision['source_sha256']}, actual {source_hashes}"
        )
    if decision["decision"] not in {"journal_only", "research_rule"}:
        raise ReplayError("unsupported lessons decision")
    lesson_text = decision["lesson_text"]
    if not isinstance(lesson_text, str) or not lesson_text.strip():
        raise ReplayError("lessons decision lesson_text is required")

    thesis_store, thesis_review = _trader_memory_modules(repo_root)
    postmortem = _load_json(
        Path(consumed["postmortem_findings"]["files"]["canonical"]), "postmortem findings"
    )
    snapshot = _require_mapping_keys(
        postmortem.get("source_snapshot"),
        label="postmortem source_snapshot",
        required={"closed_thesis_record"},
    )
    closed = snapshot["closed_thesis_record"]
    if not isinstance(closed, dict):
        raise ReplayError("postmortem closed thesis snapshot must be a mapping")
    try:
        thesis_store.validate_thesis(closed)
    except Exception as exc:
        raise ReplayError(f"postmortem closed thesis snapshot is invalid: {exc}") from exc
    expected_closed_sha = (
        (postmortem.get("provenance") or {})
        .get("source_snapshot_sha256", {})
        .get("closed_thesis_record")
    )
    if _exact_payload_sha256(closed) != expected_closed_sha:
        raise ReplayError("postmortem closed thesis snapshot SHA-256 mismatch")
    thesis_id = postmortem["native_postmortem"]["signal_id"]
    if closed.get("thesis_id") != thesis_id:
        raise ReplayError("postmortem closed thesis snapshot thesis_id mismatch")
    state_dir = work / "trade-memory-state"
    state_dir.mkdir(parents=True)
    state_path = state_dir / f"{thesis_id}.yaml"
    _write_yaml(state_path, closed)
    try:
        thesis_store.update(
            state_dir,
            closed["thesis_id"],
            {"outcome": {"lessons_learned": lesson_text}},
        )
        journal_dir = work / "journal"
        journal_path = Path(
            thesis_review.generate_postmortem(
                closed["thesis_id"],
                str(state_dir),
                price_adapter=None,
                journal_dir=str(journal_dir),
            )
        )
        updated = load_yaml(state_path)
    except Exception as exc:
        raise ReplayError(f"trade-memory lessons native API failed: {exc}") from exc
    if _without_lesson_side_effects(updated) != _without_lesson_side_effects(closed):
        raise ReplayError("trade-memory lessons changed non-target thesis state")
    if updated["outcome"]["lessons_learned"] != lesson_text:
        raise ReplayError("trade-memory lessons did not persist approved text")

    artifacts = _artifact_paths(stage, step["output_files"])
    canonical = Path(artifacts["lessons_log_entry"]["files"]["canonical"])
    canonical.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_bytes(journal_path.read_bytes())
    normalized = _canonicalize(updated, spec["fixed_timestamp"], {str(state_dir): "$STATE"})
    normalized["created_at"] = closed["created_at"]
    try:
        thesis_store.validate_thesis(normalized)
    except Exception as exc:
        raise ReplayError(f"normalized lessons state is invalid: {exc}") from exc
    _write_yaml(Path(artifacts["lessons_log_entry"]["files"]["state"]), normalized)
    provenance = {
        "human_approved": True,
        "variant": variant,
        "decision": decision["decision"],
        "source_sha256": source_hashes,
        "execution_mode": "composite",
        "components": ["native_api", "manual_contract"],
        "atomicity_scope": {
            "individual_state_files": "atomic replace by trader-memory-core",
            "temporary_state": "discarded on replay failure",
            "published_tree": "transactional replacement by workflow replay harness",
        },
    }
    _write_yaml(
        Path(artifacts["lessons_log_entry"]["files"]["provenance"]),
        provenance,
        digest_allowlist=True,
    )
    return artifacts


def _load_module_from_path(path: Path, label: str) -> Any:
    """Load same-named skill modules under a path-derived collision-free name."""
    path = path.resolve()
    if not path.is_file():
        raise ReplayError(f"missing native module for {label}: {path}")
    digest = hashlib.sha256(str(path).encode()).hexdigest()[:16]
    module_name = f"_workflow_replay_{re.sub(r'[^a-z0-9]+', '_', label.lower())}_{digest}"
    module_spec = importlib.util.spec_from_file_location(module_name, path)
    if module_spec is None or module_spec.loader is None:
        raise ReplayError(f"cannot load native module for {label}: {path}")
    module = importlib.util.module_from_spec(module_spec)
    # dataclasses and postponed annotation resolution consult sys.modules while
    # the module body is executing. Register the collision-free name first.
    sys.modules[module_name] = module
    try:
        module_spec.loader.exec_module(module)
    except Exception as exc:
        sys.modules.pop(module_name, None)
        raise ReplayError(f"cannot initialize native module for {label}: {exc}") from exc
    return module


def _assert_finite_json(value: Any, label: str) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            _assert_finite_json(child, f"{label}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _assert_finite_json(child, f"{label}[{index}]")
    elif isinstance(value, float) and not math.isfinite(value):
        raise ReplayError(f"{label} must be finite")


def _parse_rfc3339(value: Any, label: str) -> datetime:
    _require_rfc3339(value, label)
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


def _validate_market_component_fixture(
    payload: Any,
    kind: str,
    fixed_timestamp: str,
) -> Mapping[str, Any]:
    config = MARKET_COMPONENT_CONFIG[kind]
    payload = _require_mapping_keys(
        payload,
        label=f"{kind} component fixture",
        required={
            "schema_version",
            "kind",
            "as_of",
            "max_age_days",
            "component_scores",
            "data_availability",
            "warning_flags",
        },
    )
    if payload["schema_version"] != 1 or payload["kind"] != kind:
        raise ReplayError(f"invalid {kind} component fixture identity")
    as_of = _parse_rfc3339(payload["as_of"], f"{kind}.as_of")
    fixed = _parse_rfc3339(fixed_timestamp, "fixed_timestamp")
    max_age_days = payload["max_age_days"]
    if (
        isinstance(max_age_days, bool)
        or not isinstance(max_age_days, int)
        or not 0 <= max_age_days <= 30
    ):
        raise ReplayError(f"{kind}.max_age_days must be an integer from 0 to 30")
    age_seconds = (fixed - as_of).total_seconds()
    if age_seconds < 0:
        raise ReplayError(f"{kind}.as_of cannot be later than fixed_timestamp")
    if age_seconds > max_age_days * 86400:
        raise ReplayError(f"{kind} component evidence is stale at fixed_timestamp")

    scores = payload["component_scores"]
    availability = payload["data_availability"]
    warning_flags = payload["warning_flags"]
    if not isinstance(scores, dict) or set(scores) != config["components"]:
        raise ReplayError(f"{kind}.component_scores must contain the canonical component set")
    if not isinstance(availability, dict) or set(availability) != config["components"]:
        raise ReplayError(f"{kind}.data_availability must contain the canonical component set")
    if not isinstance(warning_flags, dict) or set(warning_flags) != config["warning_flags"]:
        raise ReplayError(f"{kind}.warning_flags must contain the canonical flag set")
    for name, value in scores.items():
        _require_finite_number(value, f"{kind}.component_scores.{name}", minimum=0, maximum=100)
    for name, value in availability.items():
        if not isinstance(value, bool):
            raise ReplayError(f"{kind}.data_availability.{name} must be boolean")
        if not value:
            raise ReplayError(f"{kind} has insufficient component evidence: {name} unavailable")
    for name, value in warning_flags.items():
        if not isinstance(value, bool):
            raise ReplayError(f"{kind}.warning_flags.{name} must be boolean")
    return payload


def _load_market_fixture_set(
    inputs: Mapping[str, Path],
    spec: Mapping[str, Any],
    kinds: set[str] | None = None,
) -> dict[str, Mapping[str, Any]]:
    selected = kinds or set(MARKET_COMPONENT_CONFIG)
    fixtures = {
        kind: _validate_market_component_fixture(
            _load_json(inputs[config["input"]], f"{kind} component fixture"),
            kind,
            spec["fixed_timestamp"],
        )
        for kind, config in MARKET_COMPONENT_CONFIG.items()
        if kind in selected
    }
    as_of_values = {fixture["as_of"] for fixture in fixtures.values()}
    if len(as_of_values) != 1:
        raise ReplayError("market component fixtures must use one consistent as_of timestamp")
    return fixtures


def _market_modules(repo_root: Path, kind: str) -> tuple[Any, Any]:
    skill = MARKET_COMPONENT_CONFIG[kind]["skill"]
    scripts = repo_root / "skills" / skill / "scripts"
    scorer = _load_module_from_path(scripts / "scorer.py", f"{kind}_scorer")
    reporter = _load_module_from_path(scripts / "report_generator.py", f"{kind}_reporter")
    return scorer, reporter


def _market_composite(scorer: Any, kind: str, fixture: Mapping[str, Any]) -> dict[str, Any]:
    scores = dict(fixture["component_scores"])
    availability = dict(fixture["data_availability"])
    if kind == "uptrend":
        composite = scorer.calculate_composite_score(
            scores,
            availability,
            dict(fixture["warning_flags"]),
        )
    else:
        composite = scorer.calculate_composite_score(scores, availability)
    if not isinstance(composite, dict):
        raise ReplayError(f"{kind} native scorer returned a non-mapping result")
    _assert_finite_json(composite, f"{kind} native scorer result")
    score = composite.get("composite_score")
    _require_finite_number(score, f"{kind} composite_score", minimum=0, maximum=100)
    return composite


MARKET_PROVENANCE_RUN_ID = "fictional-market-regime-daily-run-001"


def _market_analysis(
    scorer: Any,
    kind: str,
    fixture: Mapping[str, Any],
    fixed_timestamp: str,
) -> dict[str, Any]:
    result = {
        "schema_version": 1,
        "metadata": {
            "generated_at": fixed_timestamp,
            "as_of": fixture["as_of"],
            "data_mode": "fictional offline component fixture",
        },
        "composite": _market_composite(scorer, kind, fixture),
        "components": {
            name: {"score": score, "data_available": fixture["data_availability"][name]}
            for name, score in fixture["component_scores"].items()
        },
        "provenance": {
            "execution_mode": "native_api",
            "native_surface": "scorer.calculate_composite_score + report_generator.generate_json_report",
            "fixture_boundaries": [
                "provider fetch not executed",
                "individual component calculators not executed",
                "live API failure not exercised",
            ],
        },
    }

    if kind in {"breadth", "uptrend"}:
        contract = _load_module_from_path(
            REPO_ROOT / "skills" / "exposure-coach" / "scripts" / "provenance_contract.py",
            "market_provenance_contract",
        )
        result["data_provenance"] = contract.build_provenance(
            provider="fictional-fixture",
            endpoint=f"market-regime-{kind}-component-fixture",
            retrieved_at=fixed_timestamp,
            as_of=fixture["as_of"],
            run_id=MARKET_PROVENANCE_RUN_ID,
        )
        result["data_provenance"]["scope"] = (
            "fictional component fixture only; provider fetch not executed"
        )
    return result


def _validate_market_report(
    payload: Any,
    kind: str,
    fixture: Mapping[str, Any],
    scorer: Any,
    fixed_timestamp: str,
) -> Mapping[str, Any]:
    payload = _require_mapping_keys(
        payload,
        label=f"{kind} market artifact",
        required={"schema_version", "metadata", "composite", "components", "provenance"}
        | ({"data_provenance"} if kind in {"breadth", "uptrend"} else set()),
    )
    expected = _market_analysis(scorer, kind, fixture, fixed_timestamp)
    _assert_finite_json(payload, f"{kind} market artifact")
    if payload != expected:
        raise ReplayError(f"{kind} market artifact does not match native scorer recomputation")
    return payload


def _market_regime_component(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    _consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
    *,
    kind: str,
) -> dict[str, dict[str, Any]]:
    fixture = _load_market_fixture_set(inputs, spec, {kind})[kind]
    scorer, reporter = _market_modules(repo_root, kind)
    analysis = _market_analysis(scorer, kind, fixture, spec["fixed_timestamp"])
    artifacts = _artifact_paths(stage, step["output_files"])
    artifact_id = MARKET_COMPONENT_CONFIG[kind]["artifact"]
    output = Path(artifacts[artifact_id]["files"]["canonical"])
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        reporter.generate_json_report(analysis, str(output))
    except Exception as exc:
        raise ReplayError(f"{kind} native report API failed: {exc}") from exc
    produced = _load_json(output, f"{kind} generated market artifact")
    _validate_market_report(produced, kind, fixture, scorer, spec["fixed_timestamp"])
    # Native report writers do not consistently append a final newline. Re-emit the
    # already validated payload in the harness's canonical JSON form for stable goldens.
    _write_json(output, produced)
    return artifacts


def _market_regime_breadth(*args: Any, **kwargs: Any) -> dict[str, dict[str, Any]]:
    return _market_regime_component(*args, **kwargs, kind="breadth")


def _market_regime_uptrend(*args: Any, **kwargs: Any) -> dict[str, dict[str, Any]]:
    return _market_regime_component(*args, **kwargs, kind="uptrend")


def _market_regime_top_risk(*args: Any, **kwargs: Any) -> dict[str, dict[str, Any]]:
    return _market_regime_component(*args, **kwargs, kind="top_risk")


def _expected_exposure_decision(
    repo_root: Path,
    consumed_payloads: Mapping[str, Mapping[str, Any]],
    fixed_timestamp: str,
) -> dict[str, Any]:
    module = _load_module_from_path(
        repo_root / "skills" / "exposure-coach" / "scripts" / "calculate_exposure.py",
        "exposure_coach",
    )
    scores: dict[str, Any] = {
        "breadth": module.extract_breadth_score(consumed_payloads.get("market_breadth_report")),
        "uptrend": module.extract_uptrend_score(consumed_payloads.get("uptrend_report")),
        "regime": None,
        "top_risk": module.extract_top_risk_score(consumed_payloads.get("top_risk_report")),
        "ftd": None,
        "theme": None,
        "sector": None,
        "institutional": None,
    }
    composite, provided, missing = module.calculate_composite_score(scores)
    missing_critical = len(set(missing) & module.CRITICAL_INPUTS)
    recommendation = module.determine_recommendation(
        composite, scores["top_risk"], missing_critical
    )
    bias = module.determine_bias("Unknown", scores["theme"], None, None)
    participation = module.determine_participation(scores["uptrend"], scores["breadth"], None)
    confidence = module.determine_confidence(provided, missing)
    result = {
        "schema_version": "1.0",
        "generated_at": fixed_timestamp,
        "exposure_ceiling_pct": module.determine_exposure_ceiling(composite),
        "bias": bias,
        "participation": participation,
        "recommendation": recommendation,
        "confidence": confidence,
        "composite_score": round(composite, 1),
        "component_scores": {
            f"{key}_score": value for key, value in scores.items() if value is not None
        },
        "inputs_provided": provided,
        "inputs_missing": missing,
        "rationale": module.generate_rationale(
            composite, recommendation, participation, bias, scores, missing
        ),
    }

    result["input_lineage"] = module.validate_market_inputs(
        consumed_payloads.get("market_breadth_report"),
        consumed_payloads.get("uptrend_report"),
        run_id=MARKET_PROVENANCE_RUN_ID,
        evaluation=fixed_timestamp,
        max_age_days=3,
    )
    return result


def _market_regime_exposure(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    expected_artifacts = {"market_breadth_report", "uptrend_report"}
    if "top_risk_report" in consumed:
        expected_artifacts.add("top_risk_report")
    if set(consumed) != expected_artifacts:
        raise ReplayError(f"market exposure received unexpected artifacts: {sorted(consumed)}")

    kind_by_artifact = {
        "market_breadth_report": "breadth",
        "uptrend_report": "uptrend",
        "top_risk_report": "top_risk",
    }
    fixtures = _load_market_fixture_set(
        inputs,
        spec,
        {kind_by_artifact[artifact_id] for artifact_id in consumed},
    )
    payloads: dict[str, Mapping[str, Any]] = {}
    for artifact_id, bundle in consumed.items():
        kind = kind_by_artifact[artifact_id]
        path = Path(bundle["files"]["canonical"])
        payload = _load_json(path, f"{artifact_id} handoff")
        scorer, _reporter = _market_modules(repo_root, kind)
        payloads[artifact_id] = _validate_market_report(
            payload, kind, fixtures[kind], scorer, spec["fixed_timestamp"]
        )

    reports = work / "reports"
    reports.mkdir()
    command = [
        sys.executable,
        str(repo_root / "skills" / "exposure-coach" / "scripts" / "calculate_exposure.py"),
        "--breadth",
        str(Path(consumed["market_breadth_report"]["files"]["canonical"])),
        "--uptrend",
        str(Path(consumed["uptrend_report"]["files"]["canonical"])),
    ]
    if "top_risk_report" in consumed:
        command.extend(["--top-risk", str(Path(consumed["top_risk_report"]["files"]["canonical"]))])
    command.extend(
        [
            "--output-dir",
            str(reports),
            "--json-only",
            "--require-provenance",
            "--run-id",
            MARKET_PROVENANCE_RUN_ID,
            "--as-of",
            spec["fixed_timestamp"],
        ]
    )
    _run_cli(command, repo_root)
    source = _latest_report(reports, "exposure_posture_*.json")
    actual = _load_json(source, "exposure decision")
    _assert_finite_json(actual, "exposure decision")
    expected = _expected_exposure_decision(repo_root, payloads, spec["fixed_timestamp"])
    if not isinstance(actual, dict) or set(actual) != set(expected):
        raise ReplayError("exposure decision must contain the exact canonical schema")
    _require_rfc3339(actual.get("generated_at"), "exposure decision generated_at")
    canonical = dict(actual)
    canonical["generated_at"] = spec["fixed_timestamp"]
    if canonical != expected:
        raise ReplayError("exposure decision does not match native API recomputation")

    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["exposure_decision"]["files"]["canonical"]), canonical)
    return artifacts


def _validate_core_contract(payload: Any, definition: str) -> Mapping[str, Any]:
    schema = _load_json(CORE_PORTFOLIO_SCHEMA, "core portfolio replay contract schema")
    selected = {
        "$schema": schema["$schema"],
        "$defs": schema["$defs"],
        "$ref": f"#/$defs/{definition}",
    }
    errors = _schema_error_details(selected, payload)
    if errors:
        raise ReplayError(
            f"invalid core portfolio {definition} contract:\n- " + "\n- ".join(errors)
        )
    _assert_finite_json(payload, f"core portfolio {definition}")
    return payload


def _core_date(spec: Mapping[str, Any]) -> str:
    return _parse_rfc3339(spec["fixed_timestamp"], "fixed_timestamp").date().isoformat()


def _core_snapshot_sha256(snapshot: Mapping[str, Any]) -> str:
    canonical = (json.dumps(snapshot, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode()
    return hashlib.sha256(canonical).hexdigest()


def _close_number(left: int | float, right: int | float) -> bool:
    return math.isclose(float(left), float(right), rel_tol=0, abs_tol=1e-6)


def _validate_core_snapshot(payload: Any, spec: Mapping[str, Any]) -> Mapping[str, Any]:
    snapshot = _validate_core_contract(payload, "holdings_snapshot")
    if snapshot["as_of"] != _core_date(spec):
        raise ReplayError("holdings snapshot as_of must match fixed_timestamp date")
    account = snapshot["account"]
    if not re.fullmatch(r"SIM-\*{4}-\d{3}", account["account_id"]):
        raise ReplayError("holdings snapshot account_id must be masked and fictional")
    positions = snapshot["positions"]
    symbols = [row["symbol"] for row in positions]
    if len(symbols) != len(set(symbols)):
        raise ReplayError("holdings snapshot symbols must be unique")
    for row in positions:
        expected_value = row["quantity"] * row["current_price"]
        if not _close_number(row["market_value"], expected_value):
            raise ReplayError(f"holdings snapshot market_value mismatch for {row['symbol']}")
        expected_weight = row["market_value"] / account["equity"] * 100
        if not _close_number(row["portfolio_weight_pct"], expected_weight):
            raise ReplayError(f"holdings snapshot weight mismatch for {row['symbol']}")
    long_value = sum(row["market_value"] for row in positions)
    if not _close_number(long_value, account["long_market_value"]):
        raise ReplayError("holdings snapshot long_market_value does not match positions")
    if not _close_number(account["long_market_value"] + account["cash"], account["equity"]):
        raise ReplayError("holdings snapshot cash plus positions does not match equity")
    return snapshot


def _core_consumed_path(consumed: Mapping[str, dict[str, Any]], artifact_id: str) -> Path:
    try:
        return Path(consumed[artifact_id]["files"]["canonical"])
    except (KeyError, TypeError) as exc:
        raise ReplayError(f"missing canonical {artifact_id} handoff") from exc


def _core_portfolio_snapshot(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if consumed:
        raise ReplayError("core portfolio snapshot must not consume prior artifacts")
    snapshot = _validate_core_snapshot(
        _load_json(inputs["holdings_snapshot"], "core portfolio holdings snapshot"), spec
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["holdings_snapshot"]["files"]["canonical"]), snapshot)
    return artifacts


def _core_allocation_payload(
    snapshot: Mapping[str, Any], decision: Mapping[str, Any]
) -> dict[str, Any]:
    account = snapshot["account"]
    target_by_bucket = {row["bucket"]: row["target_pct"] for row in decision["targets"]}
    allocation = []
    for position in snapshot["positions"]:
        current = position["market_value"] / account["equity"] * 100
        target = target_by_bucket[position["symbol"]]
        allocation.append(
            {
                "bucket": position["symbol"],
                "current_pct": round(current, 6),
                "target_pct": target,
                "variance_pct": round(current - target, 6),
            }
        )
    cash_pct = account["cash"] / account["equity"] * 100
    cash_target = target_by_bucket["CASH"]
    allocation.append(
        {
            "bucket": "CASH",
            "current_pct": round(cash_pct, 6),
            "target_pct": cash_target,
            "variance_pct": round(cash_pct - cash_target, 6),
        }
    )
    largest = max(snapshot["positions"], key=lambda row: row["portfolio_weight_pct"])
    human = decision["human_decision"]
    return {
        "schema_version": "1.0",
        "as_of": snapshot["as_of"],
        "portfolio_value": account["equity"],
        "allocation": allocation,
        "allocation_total_pct": round(sum(row["current_pct"] for row in allocation), 6),
        "largest_position": {
            "symbol": largest["symbol"],
            "weight_pct": largest["portfolio_weight_pct"],
        },
        "decision": human["decision"],
        "rationale": human["rationale"],
    }


def _core_allocation_markdown(payload: Mapping[str, Any]) -> str:
    largest = payload["largest_position"]
    cash = next(row for row in payload["allocation"] if row["bucket"] == "CASH")
    return (
        "# Fictional Allocation Report\n\n"
        f"- Portfolio value: **${payload['portfolio_value']:,.2f}**\n"
        f"- Current cash: **{cash['current_pct']:.1f}%**\n"
        f"- Allocation total: **{payload['allocation_total_pct']:.1f}%**\n"
        f"- Largest position: **{largest['symbol']} at {largest['weight_pct']:.1f}%**\n"
        f"- Human decision: **{payload['decision']}**\n\n"
        "The allocation arithmetic was recomputed from the fictional snapshot and target "
        "fixture. The rebalance decision remains a human contract; no order is placed.\n"
    )


def _load_core_decision(
    inputs: Mapping[str, Path], name: str, definition: str
) -> Mapping[str, Any]:
    return _validate_core_contract(load_yaml(inputs[name]), definition)


def _validate_core_allocation_decision(
    snapshot: Mapping[str, Any], decision: Mapping[str, Any]
) -> None:
    if decision["snapshot_sha256"] != _core_snapshot_sha256(snapshot):
        raise ReplayError("allocation decision snapshot_sha256 does not match step-1 handoff")
    buckets = [row["bucket"] for row in decision["targets"]]
    expected = [row["symbol"] for row in snapshot["positions"]] + ["CASH"]
    if len(buckets) != len(set(buckets)) or set(buckets) != set(expected):
        raise ReplayError("allocation targets must match snapshot symbols plus CASH exactly")
    if not _close_number(sum(row["target_pct"] for row in decision["targets"]), 100):
        raise ReplayError("allocation target percentages must total 100")


def _core_portfolio_allocation(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"holdings_snapshot"}:
        raise ReplayError("core allocation requires only the holdings_snapshot handoff")
    snapshot_path = _core_consumed_path(consumed, "holdings_snapshot")
    snapshot = _validate_core_snapshot(_load_json(snapshot_path, "holdings_snapshot handoff"), spec)
    decision = _load_core_decision(inputs, "allocation_decision", "allocation_decision")
    _validate_core_allocation_decision(snapshot, decision)
    payload = _core_allocation_payload(snapshot, decision)
    artifacts = _artifact_paths(stage, step["output_files"])
    files = artifacts["allocation_report"]["files"]
    _write_json(Path(files["canonical"]), payload)
    Path(files["companion"]).write_text(
        _core_allocation_markdown(payload), encoding="utf-8", newline="\n"
    )
    return artifacts


def _core_dividend_payload(
    snapshot: Mapping[str, Any], enrichment: Mapping[str, Any]
) -> dict[str, Any]:
    if enrichment["as_of"] != snapshot["as_of"]:
        raise ReplayError("dividend enrichment as_of does not match holdings snapshot")
    if enrichment["snapshot_sha256"] != _core_snapshot_sha256(snapshot):
        raise ReplayError("dividend enrichment snapshot_sha256 does not match step-1 handoff")
    snapshot_symbols = {row["symbol"] for row in snapshot["positions"]}
    covered = enrichment["covered_tickers"]
    enriched = [row["ticker"] for row in enrichment["holdings"]]
    if not covered or len(covered) != len(set(covered)):
        raise ReplayError("dividend covered_tickers must be non-empty and unique")
    if len(enriched) != len(set(enriched)) or set(enriched) != set(covered):
        raise ReplayError("dividend enrichment holdings must match covered_tickers exactly")
    if not set(covered) <= snapshot_symbols:
        raise ReplayError("dividend covered_tickers must be an explicit snapshot symbol subset")
    return {"as_of": snapshot["as_of"], "holdings": enrichment["holdings"]}


def _run_core_dividend_native(
    repo_root: Path, payload: Mapping[str, Any], fixed_timestamp: str
) -> Mapping[str, Any]:
    module = _load_module_from_path(
        repo_root
        / "skills"
        / "kanchi-dividend-review-monitor"
        / "scripts"
        / "build_review_queue.py",
        "core_portfolio_dividend_review",
    )
    try:
        report = module.build_report(dict(payload))
    except Exception as exc:
        raise ReplayError(f"native dividend rule API failed: {exc}") from exc
    report = dict(report)
    _require_rfc3339(report.get("generated_at"), "dividend report generated_at")
    report["generated_at"] = fixed_timestamp
    _assert_finite_json(report, "native dividend report")
    if report.get("as_of") != payload["as_of"]:
        raise ReplayError("native dividend report as_of does not match replay input")
    if not isinstance(report.get("results"), list) or not report["results"]:
        raise ReplayError("native dividend report must contain at least one result")
    return report


def _expected_core_dividend_report(
    repo_root: Path,
    spec: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
) -> Mapping[str, Any]:
    if set(consumed) != {"holdings_snapshot"}:
        raise ReplayError("core dividend review requires the holdings_snapshot handoff")
    snapshot_path = _core_consumed_path(consumed, "holdings_snapshot")
    snapshot = _validate_core_snapshot(_load_json(snapshot_path, "holdings_snapshot handoff"), spec)
    enrichment = _validate_core_contract(
        _load_json(inputs["dividend_enrichment"], "dividend enrichment"),
        "dividend_enrichment",
    )
    if enrichment["as_of"] != _core_date(spec):
        raise ReplayError("dividend enrichment as_of must match fixed_timestamp date")
    payload = _core_dividend_payload(snapshot, enrichment)
    return _run_core_dividend_native(repo_root, payload, spec["fixed_timestamp"])


def _core_portfolio_dividend(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    first = _expected_core_dividend_report(repo_root, spec, inputs, consumed)
    second = _expected_core_dividend_report(repo_root, spec, inputs, consumed)
    if first != second:
        raise ReplayError("native dividend rule API was non-deterministic after normalization")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["dividend_review_findings"]["files"]["canonical"]), first)
    return artifacts


def _validate_core_allocation_handoff(
    spec: Mapping[str, Any], inputs: Mapping[str, Path], consumed: Mapping[str, dict[str, Any]]
) -> tuple[Mapping[str, Any], Path, Mapping[str, Any], Mapping[str, Any]]:
    allocation_path = _core_consumed_path(consumed, "allocation_report")
    allocation = _load_json(allocation_path, "allocation_report handoff")
    snapshot = _validate_core_snapshot(
        _load_json(inputs["holdings_snapshot"], "core portfolio holdings snapshot"), spec
    )
    decision = _load_core_decision(inputs, "allocation_decision", "allocation_decision")
    # The decision is sealed to the canonical step-1 bytes, not the source fixture's layout.
    if decision["snapshot_sha256"] != _core_snapshot_sha256(snapshot):
        raise ReplayError("allocation decision snapshot_sha256 is not canonical step-1 evidence")
    expected = _core_allocation_payload(snapshot, decision)
    if allocation != expected:
        raise ReplayError("allocation_report handoff does not match recomputed arithmetic")
    return allocation, allocation_path, snapshot, decision


def _core_rebalance_payload(
    allocation: Mapping[str, Any],
    snapshot: Mapping[str, Any],
    decision: Mapping[str, Any],
    dividend_report: Mapping[str, Any] | None,
) -> dict[str, Any]:
    positions = {row["symbol"]: row for row in snapshot["positions"]}
    projected_values = {symbol: row["market_value"] for symbol, row in positions.items()}
    projected_cash = snapshot["account"]["cash"]
    action_ids = [row["action_id"] for row in decision["actions"]]
    if len(action_ids) != len(set(action_ids)):
        raise ReplayError("rebalance action_id values must be unique")
    actions = []
    for action in decision["actions"]:
        position = positions.get(action["symbol"])
        if position is None:
            raise ReplayError(f"rebalance action references unknown symbol {action['symbol']}")
        if action["action"] != "TRIM":
            raise ReplayError("core replay supports only manual TRIM proposals")
        if not _close_number(action["reference_price"], position["current_price"]):
            raise ReplayError("rebalance reference price does not match snapshot")
        estimated = action["shares"] * action["reference_price"]
        remaining = projected_values[action["symbol"]] - estimated
        if remaining < 0:
            raise ReplayError("rebalance action cannot trim more than the held market value")
        projected_values[action["symbol"]] = remaining
        projected_cash += estimated
        actions.append(
            {
                **action,
                "estimated_value": estimated,
                "status": "PROPOSED_NOT_SUBMITTED",
            }
        )
    equity = snapshot["account"]["equity"]
    projected = {
        f"{symbol}_pct": round(value / equity * 100, 6)
        for symbol, value in projected_values.items()
    }
    projected["cash_pct"] = round(projected_cash / equity * 100, 6)
    if dividend_report is None:
        dividend_review = {
            "status": "NOT_RUN",
            "reason": "Optional step 3 was skipped in the required-only replay.",
        }
    else:
        warnings = [
            (row, finding)
            for row in dividend_report["results"]
            for finding in row.get("findings", [])
            if row.get("status") == "WARN" and finding.get("trigger") == "T2"
        ]
        if len(warnings) != 1:
            raise ReplayError("full-path dividend review must contain exactly one T2 WARN")
        row, finding = warnings[0]
        response = decision.get("dividend_response")
        if response != "PAUSE_OPTIONAL_ADDS_PENDING_HUMAN_REVIEW":
            raise ReplayError("T2 WARN must propagate PAUSE_OPTIONAL_ADDS to rebalance")
        dividend_review = {
            "status": "WARN",
            "symbol": row["ticker"],
            "trigger": finding["trigger"],
            "response": response,
        }
    return {
        "schema_version": "1.0",
        "as_of": allocation["as_of"],
        "decision": decision["decision"],
        "dividend_review": dividend_review,
        "actions": actions,
        "projected_allocation": projected,
        "manual_execution_required": True,
    }


def _core_portfolio_rebalance(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    expected_consumed = {"allocation_report"}
    full_path = "dividend_review_findings" in consumed
    if full_path:
        expected_consumed.add("dividend_review_findings")
    if set(consumed) != expected_consumed:
        raise ReplayError(f"rebalance received unexpected artifacts: {sorted(consumed)}")
    allocation, allocation_path, snapshot, _ = _validate_core_allocation_handoff(
        spec, inputs, consumed
    )
    input_name = "rebalance_decision_full" if full_path else "rebalance_decision_required"
    decision = _load_core_decision(inputs, input_name, "rebalance_decision")
    if decision["allocation_report_sha256"] != _file_sha256(allocation_path):
        raise ReplayError("rebalance decision allocation_report_sha256 mismatch")
    dividend_report = None
    dividend_path = None
    if full_path:
        dividend_path = _core_consumed_path(consumed, "dividend_review_findings")
        dividend_report = _load_json(dividend_path, "dividend_review_findings handoff")
        expected_dividend = _expected_core_dividend_report(
            repo_root,
            spec,
            inputs,
            {
                "holdings_snapshot": {
                    "files": {
                        "canonical": str(inputs["holdings_snapshot"]),
                    }
                }
            },
        )
        if dividend_report != expected_dividend:
            raise ReplayError("dividend_review_findings handoff failed native recomputation")
        if decision["dividend_review_sha256"] != _file_sha256(dividend_path):
            raise ReplayError("rebalance decision dividend_review_sha256 mismatch")
    elif decision["dividend_review_sha256"] is not None:
        raise ReplayError("required-only rebalance must not bind optional dividend evidence")
    elif decision["dividend_response"] is not None:
        raise ReplayError("required-only rebalance must not include an optional dividend response")
    if decision["human_approved"] is not True or decision["execution_authorized"] is not False:
        raise ReplayError("rebalance decision must be human-approved but not execution-authorized")
    payload = _core_rebalance_payload(allocation, snapshot, decision, dividend_report)
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_yaml(Path(artifacts["rebalance_actions"]["files"]["canonical"]), payload)
    return artifacts


def _core_portfolio_journal(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"rebalance_actions"}:
        raise ReplayError("core journal requires only the rebalance_actions handoff")
    rebalance_path = _core_consumed_path(consumed, "rebalance_actions")
    rebalance = load_yaml(rebalance_path)
    full_path = rebalance.get("dividend_review", {}).get("status") != "NOT_RUN"
    input_name = "journal_decision_full" if full_path else "journal_decision_required"
    decision = _load_core_decision(inputs, input_name, "journal_decision")
    if decision["rebalance_actions_sha256"] != _file_sha256(rebalance_path):
        raise ReplayError("journal decision rebalance_actions_sha256 mismatch")
    if decision["human_approved"] is not True or decision["execution_authorized"] is not False:
        raise ReplayError("journal decision must be human-approved but not execution-authorized")
    dividend = rebalance["dividend_review"]
    payload: dict[str, Any] = {
        "schema_version": "1.0",
        "journal_type": "core_portfolio_weekly",
        "review_date": _core_date(spec),
        "source_snapshot": "01_holdings_snapshot.json",
        "allocation_decision": decision["allocation_decision"],
        "dividend_review_status": dividend["status"],
    }
    if full_path:
        payload["dividend_review"] = {
            key: dividend[key] for key in ("symbol", "trigger", "response")
        }
    payload.update(
        {
            "proposed_actions": [
                {
                    "action_id": row["action_id"],
                    "symbol": row["symbol"],
                    "action": row["action"],
                    "shares": row["shares"],
                    "estimated_value": row["estimated_value"],
                    "broker_status": "NOT_SUBMITTED",
                }
                for row in rebalance["actions"]
            ],
            "projected_cash_pct": rebalance["projected_allocation"]["cash_pct"],
            "human_confirmation": {
                "broker_state_verified": decision["broker_state_verified"],
                "disclosure_reviewed": decision["disclosure_reviewed"],
                "tax_impact_reviewed": decision["tax_impact_reviewed"],
                "execution_authorized": decision["execution_authorized"],
            },
            "note": decision["note"],
        }
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_yaml(Path(artifacts["weekly_journal_entry"]["files"]["canonical"]), payload)
    return artifacts


def _monthly_aggregate(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if consumed:
        raise ReplayError("monthly aggregate must not consume upstream artifacts")
    bundle = _require_mapping_keys(
        _load_json(inputs["closed_theses"], "closed theses"),
        label="closed theses",
        required={"schema_version", "period", "thesis_records"},
    )
    if bundle["schema_version"] != 1:
        raise ReplayError("closed theses schema_version must be 1")
    period = _require_mapping_keys(bundle["period"], label="period", required={"start", "end"})
    for key in ("start", "end"):
        _require_non_empty_string(period[key], f"period.{key}")
    records = bundle["thesis_records"]
    if not isinstance(records, list) or not records:
        raise ReplayError("closed theses thesis_records must be a non-empty list")

    trade_rows: list[dict[str, Any]] = []
    realized_total = 0.0
    winners = 0
    losers = 0
    max_consecutive = 0
    current_consecutive = 0
    violations = 0
    root_cause_counts: dict[str, int] = {}
    for row in records:
        row = _require_mapping_keys(
            row,
            label="thesis record",
            required={
                "trade_id",
                "symbol",
                "outcome",
                "realized_pnl",
                "root_cause",
                "process_followed",
            },
        )
        trade_id = _require_non_empty_string(row["trade_id"], "thesis record trade_id")
        outcome = row["outcome"]
        if outcome not in {"win", "loss"}:
            raise ReplayError(f"thesis record {trade_id} outcome must be win or loss")
        pnl = _require_finite_number(row["realized_pnl"], f"{trade_id} realized_pnl")
        root_cause = _require_non_empty_string(row["root_cause"], f"{trade_id} root_cause")
        if row["process_followed"] is not True:
            violations += 1
        realized_total += pnl
        if outcome == "win":
            winners += 1
            current_consecutive = 0
        else:
            losers += 1
            current_consecutive += 1
            max_consecutive = max(max_consecutive, current_consecutive)
        root_cause_counts[root_cause] = root_cause_counts.get(root_cause, 0) + 1
        trade_rows.append(
            {
                "trade_id": trade_id,
                "symbol": _require_non_empty_string(row["symbol"], f"{trade_id} symbol"),
                "outcome": outcome,
                "realized_pnl": round(pnl, 2),
                "root_cause": root_cause,
            }
        )

    month = period["start"][:7]
    dominant_root = max(root_cause_counts, key=root_cause_counts.get)
    closed = len(records)
    aggregate = {
        "schema_version": 1,
        "review_type": "monthly_aggregate",
        "trade_id": f"monthly_{month}_fictional",
        "period": period,
        "outcome": "mixed",
        "planned": {
            "thesis_recorded_before_entry": True,
            "setup_confirmed": True,
            "market_regime": "allowed",
        },
        "actual": {
            "portfolio_heat_r": 3,
            "stop_moved": False,
            "entry_before_confirmation": False,
            "traded_against_regime": False,
        },
        "risk_plan": {"max_risk_per_trade_r": 1.0, "max_portfolio_heat_r": 4.0},
        "monthly": {
            "trades": [row["trade_id"] for row in trade_rows],
            "consecutive_losses": max_consecutive,
            "rule_violations": violations,
        },
        "postmortem": {
            "root_cause": dominant_root,
            "notes": [f"{v} trades traced to {k}" for k, v in sorted(root_cause_counts.items())],
        },
        "journal": {
            "reflection": "Monthly aggregate reconstructed from the closed-theses log.",
            "emotions": [],
        },
        "trades": trade_rows,
        "summary": {
            "closed_trades": closed,
            "winners": winners,
            "losers": losers,
            "realized_pnl": round(realized_total, 2),
            "win_rate_pct": round(winners / closed * 100, 2),
        },
        "provenance": {
            "execution_mode": "manual_contract",
            "deferred_evidence": (
                "Monthly aggregate is consolidated in-harness from the closed-theses log; "
                "trader-memory-core journal synthesis remains deferred (issue 294)."
            ),
        },
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["monthly_aggregate"]["files"]["canonical"]), aggregate)
    return artifacts


def _monthly_postmortem(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"monthly_aggregate"}:
        raise ReplayError("monthly postmortem requires exactly monthly_aggregate")
    decision = _require_mapping_keys(
        load_yaml(inputs["pattern_decision"]),
        label="pattern decision",
        required={
            "human_approved",
            "expected_native_classifications",
            "classifications",
            "summary",
        },
    )
    if decision["human_approved"] is not True:
        raise ReplayError("pattern decision requires human_approved: true")
    classifications = decision["classifications"]
    if not isinstance(classifications, list) or not classifications:
        raise ReplayError("pattern decision classifications must be a non-empty list")
    allowed_categories = {"thesis_quality", "execution", "market_environment", "randomness"}
    category_counts: dict[str, int] = {}
    for item in classifications:
        item = _require_mapping_keys(
            item,
            label="pattern classification",
            required={"category", "pattern", "count", "qualifier"},
        )
        category = item["category"]
        if category not in allowed_categories:
            raise ReplayError(f"unexpected pattern category {category!r}")
        category_counts[category] = category_counts.get(category, 0) + item["count"]
    _require_non_empty_string(decision["summary"], "pattern decision summary")

    expected_native = sorted(decision["expected_native_classifications"])
    if expected_native != sorted(allowed_categories):
        raise ReplayError(
            "expected_native_classifications must list the canonical postmortem category set; "
            f"got {expected_native}"
        )

    aggregate = _load_json(
        Path(consumed["monthly_aggregate"]["files"]["canonical"]), "monthly aggregate"
    )
    _require_mapping_keys(
        aggregate,
        label="monthly aggregate",
        required={"trades", "summary"},
        optional={
            "schema_version",
            "review_type",
            "trade_id",
            "period",
            "outcome",
            "planned",
            "actual",
            "risk_plan",
            "monthly",
            "postmortem",
            "journal",
            "provenance",
        },
    )
    trades = aggregate["trades"]
    if not isinstance(trades, list) or not trades:
        raise ReplayError("monthly aggregate trades must be a non-empty list")
    trade_ids: list[str] = []
    for row in trades:
        if not isinstance(row, dict) or "root_cause" not in row:
            raise ReplayError("monthly aggregate trade must be a mapping with a root_cause")
        if row["root_cause"] not in allowed_categories:
            raise ReplayError(
                f"monthly aggregate trade has unexpected root_cause {row['root_cause']!r}"
            )
        trade_ids.append(row.get("trade_id"))
    summary = _require_mapping_keys(
        aggregate["summary"],
        label="monthly aggregate summary",
        required={"closed_trades", "winners", "losers"},
        optional={"realized_pnl", "win_rate_pct"},
    )
    closed = _require_finite_number(
        summary["closed_trades"], "monthly aggregate closed_trades", integer=True, minimum=0
    )
    winners = _require_finite_number(
        summary["winners"], "monthly aggregate winners", integer=True, minimum=0
    )
    losers = _require_finite_number(
        summary["losers"], "monthly aggregate losers", integer=True, minimum=0
    )
    if closed != len(trades):
        raise ReplayError("monthly aggregate summary.closed_trades must equal the number of trades")
    if winners + losers != closed:
        raise ReplayError("monthly aggregate summary winners + losers must equal closed_trades")

    pm_records = _load_json(inputs["postmortems"], "postmortems")
    if isinstance(pm_records, dict):
        pm_records = pm_records.get("records") or []
    if not isinstance(pm_records, list) or not pm_records:
        raise ReplayError("postmortems must be a non-empty list")
    pm_dir = work / "postmortems"
    pm_dir.mkdir(parents=True, exist_ok=True)
    for index, pm in enumerate(pm_records, 1):
        _write_json(pm_dir / f"pm_{index:03d}.json", pm)

    analyzer = _repo_module(
        repo_root, "postmortem_analyzer", repo_root / "skills" / "signal-postmortem" / "scripts"
    )
    fixed_now = datetime.fromisoformat(spec["fixed_timestamp"].replace("Z", "+00:00"))
    loaded = analyzer.load_postmortems(str(pm_dir), days_back=2000, now=fixed_now)
    if not loaded:
        raise ReplayError("no postmortems loaded from fixture")
    metrics = analyzer.calculate_skill_metrics(loaded)

    aggregate_postmortem = {
        "schema_version": 1,
        "native_skill_metrics": metrics,
        "category_counts": {
            category: category_counts.get(category, 0) for category in sorted(allowed_categories)
        },
        "findings": classifications,
        "decision": "documented",
        "summary": decision["summary"],
        "warnings": [],
        "provenance": {
            "postmortem_records": len(pm_records),
            "source_skills": sorted(
                {pm.get("source_skill") for pm in pm_records if pm.get("source_skill")}
            ),
            "aggregate": {
                "postmortem_root_cause": aggregate.get("postmortem", {}).get("root_cause"),
                "closed_trades": aggregate.get("summary", {}).get("closed_trades"),
                "trade_ids": trade_ids,
                "sha256": _payload_sha256(aggregate, spec["fixed_timestamp"]),
            },
        },
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["aggregate_postmortem"]["files"]["canonical"]), aggregate_postmortem)
    return artifacts


def _canonical_source_record(record: Any) -> Any:
    """Keep relative source references; remove machine roots from absolute ones."""
    if isinstance(record, str):
        if PurePosixPath(record).is_absolute():
            return "./" + PurePosixPath(record).name
        windows_path = PureWindowsPath(record)
        if windows_path.is_absolute():
            return "./" + windows_path.name
    return record


_MONTHLY_COACH_ARTIFACTS = {
    "monthly_performance_coach_report",
    "monthly_behavior_patterns",
    "next_month_operating_rules",
}


def _validate_monthly_coach_decision(
    payload: Any, coach: Mapping[str, Any], *, published: bool = False
) -> dict[str, Any]:
    decision = _require_mapping_keys(
        payload,
        label="coach decision",
        required={"source_review_id", "action", "accepted_rules", "human_notes"}
        | ({"schema_version"} if published else set()),
    )
    review_id = _require_non_empty_string(coach.get("review_id"), "coach review_id")
    if decision["source_review_id"] != review_id:
        raise ReplayError("coach decision source_review_id must match the coach report")
    if published and decision["schema_version"] != 1:
        raise ReplayError("coach decision schema_version must be 1")
    action = decision["action"]
    allowed_actions = {"accept_rules", "modify_rules", "defer", "journal_only"}
    native_actions = (coach.get("human_decision_gate") or {}).get("allowed_actions") or []
    if not isinstance(action, str) or action not in allowed_actions or action not in native_actions:
        raise ReplayError("coach decision action not in coach allowed actions")
    rules = decision["accepted_rules"]
    if not isinstance(rules, list):
        raise ReplayError("coach decision accepted_rules must be a list")
    for rule in rules:
        _require_non_empty_string(rule, "coach decision accepted_rule")
    if len({rule.strip() for rule in rules}) != len(rules):
        raise ReplayError("coach decision accepted_rules must be unique")
    if action in {"accept_rules", "modify_rules"} and not rules:
        raise ReplayError("coach decision accept/modify requires non-empty accepted_rules")
    if action in {"defer", "journal_only"} and rules:
        raise ReplayError("coach decision defer/journal_only cannot contain accepted_rules")
    native_rules = {
        row["rule"]
        for row in coach.get("next_session_operating_rules", [])
        if isinstance(row, dict) and isinstance(row.get("rule"), str)
    }
    if action == "accept_rules" and not set(rules).issubset(native_rules):
        raise ReplayError("coach decision accept_rules must come from native coach proposals")
    _require_non_empty_string(decision["human_notes"], "coach decision human_notes")
    return dict(decision)


def _monthly_coach(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"monthly_aggregate", "aggregate_postmortem"}:
        raise ReplayError("monthly coach requires monthly_aggregate and aggregate_postmortem")
    agg_path = Path(consumed["monthly_aggregate"]["files"]["canonical"])
    reports = work / "reports"
    script = (
        repo_root / "skills" / "trade-performance-coach" / "scripts" / "review_trade_performance.py"
    )
    _run_cli(
        [
            sys.executable,
            str(script),
            "--input",
            str(agg_path),
            "--output-dir",
            str(reports),
            "--json-name",
            "monthly-coach.json",
        ],
        repo_root,
    )
    coach = _canonicalize(
        _load_json(reports / "monthly-coach.json", "coach report"), spec["fixed_timestamp"], {}
    )
    source_records = coach.get("source_records")
    if isinstance(source_records, list):
        coach["source_records"] = [_canonical_source_record(rec) for rec in source_records]

    decision = _validate_monthly_coach_decision(load_yaml(inputs["coach_decision"]), coach)

    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["monthly_performance_coach_report"]["files"]["canonical"]), coach)
    behavioral = {
        "schema_version": 1,
        "behavioral_pattern_tags": coach.get("behavioral_pattern_tags") or [],
        "primary_root_cause": coach.get("summary", {}).get("primary_root_cause", "unknown"),
        "review_id": coach.get("review_id"),
    }
    _write_json(Path(artifacts["monthly_behavior_patterns"]["files"]["canonical"]), behavioral)
    _write_yaml(
        Path(artifacts["next_month_operating_rules"]["files"]["canonical"]),
        {
            "schema_version": 1,
            **decision,
        },
    )
    return artifacts


def _monthly_backtest(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if consumed and set(consumed) != {"aggregate_postmortem"}:
        raise ReplayError(f"monthly backtest received unexpected artifacts: {sorted(consumed)}")
    params = _require_mapping_keys(
        _load_json(inputs["backtest_params"], "backtest params"),
        label="backtest params",
        required={
            "hypothesis_id",
            "symbol",
            "total_trades",
            "win_rate",
            "avg_win_pct",
            "avg_loss_pct",
            "max_drawdown_pct",
            "years_tested",
            "num_parameters",
            "slippage_tested",
        },
    )
    hypothesis_id = _require_non_empty_string(params["hypothesis_id"], "backtest hypothesis_id")
    slippage_tested = params["slippage_tested"]
    if not isinstance(slippage_tested, bool):
        raise ReplayError("backtest params slippage_tested must be a boolean")
    batch = work / "bt"
    script = repo_root / "skills" / "backtest-expert" / "scripts" / "evaluate_backtest.py"
    backtest_command = [
        sys.executable,
        str(script),
        "--total-trades",
        str(_require_finite_number(params["total_trades"], "total_trades")),
        "--win-rate",
        str(_require_finite_number(params["win_rate"], "win_rate")),
        "--avg-win-pct",
        str(_require_finite_number(params["avg_win_pct"], "avg_win_pct")),
        "--avg-loss-pct",
        str(_require_finite_number(params["avg_loss_pct"], "avg_loss_pct")),
        "--max-drawdown-pct",
        str(_require_finite_number(params["max_drawdown_pct"], "max_drawdown_pct")),
        "--years-tested",
        str(_require_finite_number(params["years_tested"], "years_tested")),
        "--num-parameters",
        str(_require_finite_number(params["num_parameters"], "num_parameters")),
    ]
    if slippage_tested:
        backtest_command.append("--slippage-tested")
    backtest_command.extend(["--output-dir", str(batch)])
    _run_cli(backtest_command, repo_root)
    evaluation = _canonicalize(
        _load_json(_latest_report(batch, "backtest_eval_*.json"), "backtest evaluation"),
        spec["fixed_timestamp"],
        {},
    )
    payload = {
        "schema_version": 1,
        "hypothesis_id": hypothesis_id,
        "symbol": _require_non_empty_string(params["symbol"], "backtest symbol"),
        "evaluation": evaluation,
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["hypothesis_revalidation"]["files"]["canonical"]), payload)
    return artifacts


def _monthly_skill_review(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if consumed and set(consumed) != {"aggregate_postmortem"}:
        raise ReplayError(f"monthly skill review received unexpected artifacts: {sorted(consumed)}")
    target = _require_mapping_keys(
        load_yaml(inputs["skill_review_target"]),
        label="skill review target",
        required={"skill_name"},
    )
    skill_name = _require_non_empty_string(target["skill_name"], "skill review target skill_name")
    batch = work / "dual"
    script = (
        repo_root / "skills" / "dual-axis-skill-reviewer" / "scripts" / "run_dual_axis_review.py"
    )
    python_fallback_path = work / "python-fallback-path"
    python_fallback_path.mkdir(parents=True, exist_ok=True)
    _run_cli(
        [
            sys.executable,
            str(script),
            "--project-root",
            str(repo_root),
            "--skill",
            skill_name,
            "--output-dir",
            str(batch),
        ],
        repo_root,
        path_override=python_fallback_path,
        env_overrides={"NO_COLOR": "1", "PY_COLORS": "0"},
    )
    report = _load_json(_latest_report(batch, f"skill_review_{skill_name}_*.json"), "skill review")
    _normalize_review_test_command(report)
    _normalize_review_test_output(report)
    report = _canonicalize(
        report,
        spec["fixed_timestamp"],
        # The reviewer serializes paths with forward slashes on every platform, so
        # both the lexical and the resolved root are stripped in that spelling.
        {repo_root.as_posix() + "/": "", repo_root.resolve().as_posix() + "/": ""},
    )
    report = _normalize_elapsed(report)
    payload = {
        "schema_version": 1,
        "skill_name": report.get("skill_name", skill_name),
        "selection_mode": "manual",
        "grades": report.get("auto_review", {}).get("grades", {}),
        "final_score": report.get("final_review", {}).get("score"),
        "review": report,
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["skill_review_findings"]["files"]["canonical"]), payload)
    return artifacts


def _monthly_decision_log(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    expected = {"aggregate_postmortem"}
    coach_artifacts = set(consumed) & _MONTHLY_COACH_ARTIFACTS
    if coach_artifacts and coach_artifacts != _MONTHLY_COACH_ARTIFACTS:
        raise ReplayError("monthly decision log requires the complete coach artifact group")
    expected.update(coach_artifacts)
    if "hypothesis_revalidation" in consumed:
        expected.add("hypothesis_revalidation")
    if "skill_review_findings" in consumed:
        expected.add("skill_review_findings")
    if set(consumed) != expected:
        raise ReplayError(f"monthly decision log received unexpected artifacts: {sorted(consumed)}")
    decision = _require_mapping_keys(
        load_yaml(inputs["rule_change_decision"]),
        label="rule change decision",
        required={
            "human_approved",
            "trade_rule_changes",
            "repo_improvements",
            "skill_improvement_backlog",
            "expected",
        },
    )
    if decision["human_approved"] is not True:
        raise ReplayError("rule change decision requires human_approved: true")
    for key in ("trade_rule_changes", "repo_improvements", "skill_improvement_backlog", "expected"):
        if not isinstance(decision[key], list):
            raise ReplayError(f"rule change decision {key} must be a list")
    coach_decision = None
    coach_hashes = dict.fromkeys(sorted(_MONTHLY_COACH_ARTIFACTS))
    if coach_artifacts:
        payloads = {}
        for artifact_id in sorted(coach_artifacts):
            path = Path(consumed[artifact_id]["files"]["canonical"])
            payloads[artifact_id] = load_yaml(path)
            coach_hashes[artifact_id] = _payload_sha256(
                payloads[artifact_id], spec["fixed_timestamp"]
            )
        coach = payloads["monthly_performance_coach_report"]
        if not isinstance(coach, dict):
            raise ReplayError("monthly coach report must be a mapping")
        coach_decision = _validate_monthly_coach_decision(
            payloads["next_month_operating_rules"], coach, published=True
        )
        behavior = payloads["monthly_behavior_patterns"]
        if not isinstance(behavior, dict) or behavior.get("review_id") != coach["review_id"]:
            raise ReplayError("monthly behavior review_id must match the coach report")

    postmortem_path = Path(consumed["aggregate_postmortem"]["files"]["canonical"])
    postmortem = _load_json(postmortem_path, "aggregate postmortem")

    log_entry = {
        "schema_version": 1,
        "coach_rule_decision": coach_decision,
        "rule_activation": "not_performed",
        "monthly_aggregate_root_cause": postmortem.get("summary", "unknown"),
        "rule_changes": decision["trade_rule_changes"],
        "repo_improvements": decision["repo_improvements"],
        "provenance": {
            **coach_hashes,
            "aggregate_postmortem": _payload_sha256(
                _load_json(postmortem_path, "aggregate postmortem"), spec["fixed_timestamp"]
            ),
            "hypothesis_revalidation": (
                _payload_sha256(
                    _load_json(
                        Path(consumed["hypothesis_revalidation"]["files"]["canonical"]),
                        "hypothesis revalidation",
                    ),
                    spec["fixed_timestamp"],
                )
                if "hypothesis_revalidation" in consumed
                else None
            ),
            "skill_review_findings": (
                _payload_sha256(
                    _load_json(
                        Path(consumed["skill_review_findings"]["files"]["canonical"]),
                        "skill review findings",
                    ),
                    spec["fixed_timestamp"],
                )
                if "skill_review_findings" in consumed
                else None
            ),
            "execution_mode": "manual_contract",
            "deferred_evidence": (
                "Decision log is transcribed from the human rule-change decision; native "
                "trader-memory-core decision/journal persistence remains deferred (issue 294)."
            ),
        },
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["monthly_decision_log"]["files"]["canonical"]), log_entry)
    _write_yaml(
        Path(artifacts["rule_changes_for_next_month"]["files"]["canonical"]),
        {
            "schema_version": 1,
            "coach_rule_decision": coach_decision,
            "rule_activation": "not_performed",
            "trade_rule_changes": decision["trade_rule_changes"],
            "repo_improvements": decision["repo_improvements"],
        },
    )
    _write_yaml(
        Path(artifacts["skill_improvement_backlog"]["files"]["canonical"]),
        {
            "schema_version": 1,
            "items": decision["skill_improvement_backlog"],
        },
    )
    return artifacts


_SWING_SCREEN_IDS = [
    "vcp_candidates",
    "momentum_burst_candidates",
    "exhaustion_hammer_candidates",
    "canslim_candidates",
    "theme_candidates",
]
_SWING_CANDIDATE_LIST_KEY = {
    "vcp_candidates": "candidates",
    "momentum_burst_candidates": "candidates",
    "exhaustion_hammer_candidates": "candidates",
    "canslim_candidates": "candidates",
    "theme_candidates": "themes",
}
_SWING_SCREEN_DISPLAY = {
    "vcp_candidates": "VCP",
    "momentum_burst_candidates": "Momentum",
    "exhaustion_hammer_candidates": "Exhaustion Hammer",
    "canslim_candidates": "CANSLIM",
    "theme_candidates": "fictional-theme",
}
_SWING_SCREEN_INPUT_KEY = {
    "vcp_candidates": "vcp_scan",
    "momentum_burst_candidates": "momentum_burst",
    "exhaustion_hammer_candidates": "exhaustion_hammer",
    "canslim_candidates": "canslim",
    "theme_candidates": "theme",
}
_SWING_SCREEN_CANONICAL = {
    "vcp_candidates": "02_vcp_candidates.json",
    "momentum_burst_candidates": "03_momentum_burst_candidates.json",
    "exhaustion_hammer_candidates": "04_exhaustion_hammer_candidates.json",
    "canslim_candidates": "05_canslim_candidates.json",
    "theme_candidates": "06_theme_candidates.json",
}
_SWING_SETUP_CANONICAL = "07_validated_setups.json"


def _swing_screen_symbols(payload: Mapping[str, Any] | None, screen_id: str) -> set[str]:
    if not isinstance(payload, dict):
        return set()
    list_key = _SWING_CANDIDATE_LIST_KEY[screen_id]
    value = payload.get(list_key)
    if not isinstance(value, list):
        return set()
    if screen_id == "theme_candidates":
        symbols: set[str] = set()
        for entry in value:
            if isinstance(entry, dict):
                symbols.update(s for s in entry.get("symbols", []) if isinstance(s, str))
        return symbols
    return {c.get("symbol") for c in value if isinstance(c, dict) and c.get("symbol")}


def _swing_payload_contains_symbol(
    payload: Mapping[str, Any] | None, screen_id: str, symbol: str
) -> bool:
    return symbol in _swing_screen_symbols(payload, screen_id)


def _swing_payloads_from_stage(stage: Path) -> dict[str, Mapping[str, Any]]:
    payloads: dict[str, Mapping[str, Any]] = {}
    for screen_id in _SWING_SCREEN_IDS:
        path = stage / _SWING_SCREEN_CANONICAL[screen_id]
        if path.exists():
            payloads[screen_id] = _load_json(path, f"{screen_id} stage")
    validated_path = stage / _SWING_SETUP_CANONICAL
    if validated_path.exists():
        payloads["validated_setups"] = _load_json(validated_path, "validated setups stage")
    return payloads


def _swing_corroboration_line(contributing: list[str]) -> str | None:
    names = [_SWING_SCREEN_DISPLAY[sid] for sid in contributing]
    if not names:
        return None
    if len(names) == 1:
        return f"{names[0]} screen corroborated the candidate."
    if len(names) == 2:
        return f"{names[0]} and {names[1]} screens corroborated the candidate."
    return f"{', '.join(names[:-1])}, and {names[-1]} screens corroborated the candidate."


def _swing_circuit_breaker(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    sizing = _load_json(inputs["sizing_parameters"], "sizing parameters")
    _require_finite_number(sizing.get("account_size"), "circuit breaker account_size")
    state_dir = work / "empty_state"
    state_dir.mkdir(parents=True)
    reports = work / "reports"
    reports.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(
                repo_root
                / "skills"
                / "drawdown-circuit-breaker"
                / "scripts"
                / "check_circuit_breaker.py"
            ),
            "--state-dir",
            str(state_dir),
            "--account-size",
            str(int(sizing["account_size"])),
            "--as-of",
            spec["fixed_timestamp"][:10],
            "--output-dir",
            str(reports),
            "--json-only",
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    _normalize_json_file(
        _latest_report(reports, "circuit_breaker_decision_*.json"),
        Path(artifacts["circuit_breaker_decision"]["files"]["canonical"]),
        spec["fixed_timestamp"],
        {str(state_dir): "$STATE/empty_state", str(reports): "$WORK/reports"},
    )
    return artifacts


def _swing_screen_executor(artifact_id: str):
    input_key = _SWING_SCREEN_INPUT_KEY[artifact_id]
    list_key = _SWING_CANDIDATE_LIST_KEY[artifact_id]

    def _executor(
        repo_root: Path,
        spec: Mapping[str, Any],
        step: Mapping[str, Any],
        inputs: Mapping[str, Path],
        consumed: Mapping[str, dict[str, Any]],
        work: Path,
        stage: Path,
    ) -> dict[str, dict[str, Any]]:
        if consumed:
            raise ReplayError(f"{artifact_id} must not consume upstream artifacts")
        fixture = _load_json(inputs[input_key], f"{artifact_id} fixture")
        if not isinstance(fixture, dict):
            raise ReplayError(f"{artifact_id} fixture must be a mapping")
        if not isinstance(fixture.get(list_key), list):
            raise ReplayError(f"{artifact_id} fixture {list_key!r} must be a list")
        artifacts = _artifact_paths(stage, step["output_files"])
        _write_json(Path(artifacts[artifact_id]["files"]["canonical"]), fixture)
        return artifacts

    return _executor


def _swing_validate_setups(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    fixture = _load_json(inputs["validated_setups"], "validated setups fixture")
    if not isinstance(fixture, dict) or not isinstance(fixture.get("setups"), list):
        raise ReplayError("validated setups fixture must contain a setups list")
    if "vcp_candidates" not in consumed:
        raise ReplayError("validated setups requires the VCP screen to have been run")
    provided = [sid for sid in _SWING_SCREEN_IDS if sid in consumed]
    missing = [sid for sid in _SWING_SCREEN_IDS if sid not in consumed]
    setups = []
    for item in fixture["setups"]:
        item = dict(item)
        symbol = item.get("symbol")
        if not symbol:
            raise ReplayError("validated setup is missing a symbol")
        vcp_path = Path(consumed["vcp_candidates"]["files"]["canonical"])
        vcp = _load_json(vcp_path, "vcp handoff")
        vcp_candidates = vcp.get("candidates")
        if not isinstance(vcp_candidates, list) or not vcp_candidates:
            raise ReplayError("VCP screen produced no candidates")
        by_symbol = {
            cand.get("symbol"): cand
            for cand in vcp_candidates
            if isinstance(cand, dict) and cand.get("symbol")
        }
        cand = by_symbol.get(symbol)
        if cand is None:
            raise ReplayError(
                f"validated setup symbol {symbol!r} does not match any VCP candidate "
                f"({sorted(by_symbol) or 'none'})"
            )
        pivot = cand.get("pivot_price")
        stop = cand.get("suggested_stop")
        if item.get("entry_price") != pivot:
            raise ReplayError(
                f"validated setup entry {item.get('entry_price')} != VCP pivot {pivot} for {symbol}"
            )
        if item.get("stop_price") != stop:
            raise ReplayError(
                f"validated setup stop {item.get('stop_price')} != VCP suggested stop {stop} "
                f"for {symbol}"
            )
        item["source_artifacts"] = [
            sid
            for sid in provided
            if _swing_payload_contains_symbol(
                _load_json(Path(consumed[sid]["files"]["canonical"]), f"{sid} handoff"),
                sid,
                symbol,
            )
        ]
        setups.append(item)
    payload = {
        "schema_version": fixture.get("schema_version"),
        "as_of": fixture.get("as_of"),
        "inputs_provided": provided,
        "inputs_missing": missing,
        "setups": setups,
        "rejected": fixture.get("rejected", []),
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["validated_setups"]["files"]["canonical"]), payload)
    return artifacts


def _swing_position_size(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    validated = _load_json(
        Path(consumed["validated_setups"]["files"]["canonical"]), "validated setups handoff"
    )
    setup = validated["setups"][0]
    sizing = _load_json(inputs["sizing_parameters"], "sizing parameters")
    reports = work / "reports"
    reports.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(repo_root / "skills" / "position-sizer" / "scripts" / "position_sizer.py"),
            "--account-size",
            str(sizing["account_size"]),
            "--entry",
            str(setup["entry_price"]),
            "--stop",
            str(setup["stop_price"]),
            "--risk-pct",
            str(sizing["risk_pct"]),
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    _normalize_json_file(
        _latest_report(reports, "position_sizer_*.json"),
        Path(artifacts["position_sizing"]["files"]["canonical"]),
        spec["fixed_timestamp"],
        {},
    )
    return artifacts


def _swing_build_plan(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"validated_setups", "position_sizing"}:
        raise ReplayError(f"swing build_plan received unexpected artifacts: {sorted(consumed)}")
    validated = _load_json(
        Path(consumed["validated_setups"]["files"]["canonical"]), "validated setups handoff"
    )
    sizing = _load_json(
        Path(consumed["position_sizing"]["files"]["canonical"]), "position sizing handoff"
    )
    setup = validated["setups"][0]
    entry = setup["entry_price"]
    stop = setup["stop_price"]
    target = setup["target_price"]
    shares = int(sizing["final_recommended_shares"])
    payload = {
        "schema_version": "1.0",
        "as_of": validated["as_of"],
        "plans": [
            {
                "symbol": setup["symbol"],
                "side": "BUY",
                "entry_type": "STOP_LIMIT",
                "entry_price": entry,
                "limit_price": round(entry * 1.005, 2),
                "stop_price": stop,
                "target_price": target,
                "shares": shares,
                "position_value": sizing["final_position_value"],
                "planned_risk_dollars": sizing["final_risk_dollars"],
                "risk_reward_ratio": round((target - entry) / (entry - stop), 4),
                "order_status": "PROPOSED_NOT_SUBMITTED",
            }
        ],
        "manual_execution_required": True,
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["trade_plans"]["files"]["canonical"]), payload)
    return artifacts


def _swing_thesis_date(spec: Mapping[str, Any]) -> str:
    """Return YYYYMMDD in the RFC3339 timestamp's declared offset, without UTC conversion."""
    fixed = _parse_rfc3339(spec["fixed_timestamp"], "fixed_timestamp")
    return fixed.strftime("%Y%m%d")


def _swing_journal(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    decision = load_yaml(inputs["journal"])
    fixed_ts = spec["fixed_timestamp"]
    has_trade_plans = "trade_plans" in consumed
    sizing = _load_json(
        Path(consumed["position_sizing"]["files"]["canonical"]), "position sizing handoff"
    )
    shares = int(sizing["final_recommended_shares"])
    entry_price = sizing["parameters"]["entry_price"]
    stop_price = sizing["parameters"]["stop_price"]

    stage_payloads = _swing_payloads_from_stage(stage)
    validated = stage_payloads.get("validated_setups")
    if not validated or not isinstance(validated.get("setups"), list):
        raise ReplayError("journal requires the validated setups artifact")
    setup_list = validated["setups"]
    if len(setup_list) != 1:
        raise ReplayError(
            f"journal must be tied to exactly one validated setup; found {len(setup_list)}"
        )
    setup = setup_list[0]
    symbol = setup.get("symbol")
    if not symbol:
        raise ReplayError("journal validated setup is missing a symbol")
    if setup.get("entry_price") != entry_price:
        raise ReplayError(
            f"journal setup entry {setup.get('entry_price')} != position sizing entry "
            f"{entry_price} for {symbol}"
        )
    if setup.get("stop_price") != stop_price:
        raise ReplayError(
            f"journal setup stop {setup.get('stop_price')} != position sizing stop "
            f"{stop_price} for {symbol}"
        )

    contributing = [
        sid
        for sid in _SWING_SCREEN_IDS
        if sid in stage_payloads
        and _swing_payload_contains_symbol(stage_payloads[sid], sid, symbol)
    ]
    non_vcp = [sid for sid in contributing if sid != "vcp_candidates"]
    corroboration = _swing_corroboration_line(non_vcp)
    evidence = [decision["evidence_base"]]
    if corroboration:
        evidence.append(corroboration)
    evidence.append(decision["evidence_manual"])

    if has_trade_plans:
        origin_skill = "breakout-trade-planner"
        origin_file = "09_trade_plans.json"
        idea_reason = decision["reason_full_path"]
        entry_ready_reason = "Weekly setup, position size, and optional trade plan were reviewed."
        thesis_suffix = "_cd34"
    else:
        origin_skill = "vcp-screener"
        origin_file = "02_vcp_candidates.json"
        idea_reason = decision["reason_required_only"]
        entry_ready_reason = "Weekly setup and position size were reviewed."
        thesis_suffix = "_ab12"
    thesis_date = _swing_thesis_date(spec)
    thesis_id = f"th_{symbol.lower()}_gro_{thesis_date}{thesis_suffix}"

    payload = {
        "thesis_id": thesis_id,
        "ticker": symbol,
        "created_at": fixed_ts,
        "updated_at": fixed_ts,
        "thesis_type": decision["thesis_type"],
        "setup_type": decision["setup_type"],
        "catalyst": decision.get("catalyst"),
        "status": "ENTRY_READY",
        "status_history": [
            {"status": "IDEA", "at": fixed_ts, "reason": idea_reason},
            {"status": "ENTRY_READY", "at": fixed_ts, "reason": entry_ready_reason},
        ],
        "thesis_statement": (
            f"{symbol} holds the fictional {entry_price:.2f} pivot after a tightening VCP base."
        ),
        "mechanism_tag": "behavior",
        "evidence": evidence,
        "kill_criteria": [f"Close below the planned {stop_price:.2f} stop invalidates the setup."],
        "confidence": decision["confidence"],
        "confidence_score": decision["confidence_score"],
        "entry": {
            "target_price": entry_price,
            "conditions": decision["entry_conditions"],
            "actual_price": None,
            "actual_date": None,
        },
        "exit": {
            "stop_loss": stop_price,
            "stop_loss_pct": decision["exit"]["stop_loss_pct"],
            "take_profit": decision["exit"]["take_profit"],
            "take_profit_rr": decision["exit"]["take_profit_rr"],
            "time_stop_days": decision["exit"]["time_stop_days"],
            "actual_price": None,
            "actual_date": None,
            "exit_reason": None,
        },
        "position": {
            "shares": shares,
            "shares_remaining": shares,
            "position_value": sizing["final_position_value"],
            "risk_dollars": sizing["final_risk_dollars"],
            "risk_pct_of_account": sizing["final_risk_pct"],
            "account_type": decision["account_type"],
            "sizing_method": decision["sizing_method"],
            "raw_source": {
                "skill": "position-sizer",
                "file": "08_position_sizing.json",
                "fields": {
                    "final_recommended_shares": shares,
                    "final_risk_dollars": sizing["final_risk_dollars"],
                },
            },
        },
        "market_context": decision["market_context"],
        "monitoring": {
            "review_interval_days": decision["monitoring"]["review_interval_days"],
            "next_review_date": decision["monitoring"]["next_review_date"],
            "last_review_date": None,
            "review_status": "OK",
            "triggers_config": [],
            "alerts": [],
        },
        "origin": {
            "skill": origin_skill,
            "output_file": origin_file,
            "screening_grade": decision["screening_grade"],
            "screening_score": decision["screening_score"],
            "raw_provenance": {"fixture": "fictional"},
        },
        "linked_reports": [],
        "outcome": {
            "pnl_dollars": None,
            "pnl_pct": None,
            "holding_days": None,
            "mae_pct": None,
            "mfe_pct": None,
            "mae_mfe_source": None,
            "lessons_learned": None,
        },
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_yaml(Path(artifacts["candidate_journal_entry"]["files"]["canonical"]), payload)
    return artifacts


def _swing_discipline(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    expected = {"candidate_journal_entry", "position_sizing", "circuit_breaker_decision"}
    if "trade_plans" in consumed:
        expected.add("trade_plans")
    if set(consumed) != expected:
        raise ReplayError(f"swing discipline received unexpected artifacts: {sorted(consumed)}")
    journal = load_yaml(Path(consumed["candidate_journal_entry"]["files"]["canonical"]))
    sizing = _load_json(
        Path(consumed["position_sizing"]["files"]["canonical"]), "position sizing handoff"
    )
    regime_path = inputs["exposure_decision"].resolve()
    cb_path = Path(consumed["circuit_breaker_decision"]["files"]["canonical"]).resolve()

    symbol = journal["ticker"]
    planned_risk = sizing["final_risk_dollars"]
    _require_finite_number(planned_risk, "discipline planned_risk_dollars")
    journal_shares = journal.get("position", {}).get("shares")
    if journal_shares != sizing["final_recommended_shares"]:
        raise ReplayError(
            f"journal shares {journal_shares} != position sizing "
            f"{sizing['final_recommended_shares']} for {symbol}"
        )
    if journal.get("position", {}).get("risk_dollars") != planned_risk:
        raise ReplayError(
            f"journal risk_dollars {journal.get('position', {}).get('risk_dollars')} != "
            f"position sizing {planned_risk} for {symbol}"
        )
    if journal.get("entry", {}).get("target_price") != sizing["parameters"]["entry_price"]:
        raise ReplayError(f"journal entry != position sizing entry for {symbol}")
    if journal.get("exit", {}).get("stop_loss") != sizing["parameters"]["stop_price"]:
        raise ReplayError(f"journal stop != position sizing stop for {symbol}")

    has_trade_plans = "trade_plans" in consumed
    plan_checks = {
        "entry_in_written_plan": False,
        "stop_predefined": False,
        "size_within_plan": False,
    }
    if has_trade_plans:
        plans_path = Path(consumed["trade_plans"]["files"]["canonical"]).resolve()
        plans = _load_json(plans_path, "trade plans handoff")
        plan_list = plans.get("plans")
        if not isinstance(plan_list, list) or not plan_list:
            raise ReplayError("trade plan handoff has no plans")
        if len(plan_list) != 1:
            raise ReplayError(f"discipline expects exactly one trade plan; found {len(plan_list)}")
        plan = plan_list[0]
        checks = [
            ("symbol", plan.get("symbol"), symbol),
            ("entry_price", plan.get("entry_price"), sizing["parameters"]["entry_price"]),
            ("stop_price", plan.get("stop_price"), sizing["parameters"]["stop_price"]),
            ("shares", plan.get("shares"), sizing["final_recommended_shares"]),
            ("position_value", plan.get("position_value"), sizing["final_position_value"]),
            (
                "planned_risk_dollars",
                plan.get("planned_risk_dollars"),
                sizing["final_risk_dollars"],
            ),
        ]
        mismatches = [
            (field, got, expected_val) for field, got, expected_val in checks if got != expected_val
        ]
        if mismatches:
            detail = ", ".join(
                f"{field}={got!r} != {expected_val!r}" for field, got, expected_val in mismatches
            )
            raise ReplayError(f"trade plan for {symbol} inconsistent with sizing/journal: {detail}")
        plan_checks["entry_in_written_plan"] = True
        plan_checks["stop_predefined"] = True
        plan_checks["size_within_plan"] = True

    answers_path = work / "answers.json"
    _write_json(
        answers_path,
        {
            "candidates": [
                {
                    "symbol": symbol,
                    "thesis_id": journal["thesis_id"],
                    "order_intent": "MANUAL_ORDER",
                    "entry_in_written_plan": plan_checks["entry_in_written_plan"],
                    "stop_predefined": plan_checks["stop_predefined"],
                    "size_within_plan": plan_checks["size_within_plan"],
                    "planned_risk_dollars": planned_risk,
                    "actual_risk_dollars": planned_risk,
                    "notes": f"Fictional {journal_shares}-share plan; no order submitted.",
                }
            ]
        },
    )

    reports = work / "reports"
    reports.mkdir(parents=True)
    journal_dir = work / "journal"
    journal_dir.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(
                repo_root
                / "skills"
                / "pre-trade-discipline-gate"
                / "scripts"
                / "check_pre_trade_discipline.py"
            ),
            "--answers-file",
            str(answers_path),
            "--as-of",
            spec["fixed_timestamp"],
            "--market-regime-decision",
            str(regime_path),
            "--circuit-breaker-decision",
            str(cb_path),
            "--output-dir",
            str(reports),
            "--journal-dir",
            str(journal_dir),
        ],
        repo_root,
    )

    artifacts = _artifact_paths(stage, step["output_files"])
    source = _latest_report(reports, "pre_trade_discipline_decision_*.json")
    payload = _canonicalize(
        _load_json(source, "pre-trade discipline decision"),
        spec["fixed_timestamp"],
        {
            str(regime_path): "00_exposure_decision.json",
            str(cb_path): "01_circuit_breaker_decision.json",
            str(reports): "$WORK/reports",
            str(journal_dir): "$WORK/journal",
        },
    )
    payload["artifact_paths"] = {
        "json": "11_pre_trade_discipline_decision.json",
        "markdown": "11_pre_trade_discipline_decision.md",
    }
    _write_json(Path(artifacts["pre_trade_discipline_decision"]["files"]["canonical"]), payload)
    markdown_sources = sorted(reports.glob("pre_trade_discipline_decision_*.md"))
    if not markdown_sources:
        raise ReplayError("pre-trade discipline markdown report was not produced")
    Path(artifacts["pre_trade_discipline_decision"]["files"]["companion"]).write_text(
        markdown_sources[-1].read_text(encoding="utf-8"), encoding="utf-8", newline="\n"
    )
    return artifacts


_swing_vcp_screen = _swing_screen_executor("vcp_candidates")
_swing_momentum_burst = _swing_screen_executor("momentum_burst_candidates")
_swing_exhaustion_hammer = _swing_screen_executor("exhaustion_hammer_candidates")
_swing_canslim = _swing_screen_executor("canslim_candidates")
_swing_theme = _swing_screen_executor("theme_candidates")


def _validate_kanchi_contract(payload: Any, definition: str) -> Mapping[str, Any]:
    schema = _load_json(KANCHI_REPLAY_SCHEMA, "kanchi replay contract schema")
    selected = {
        "$schema": schema["$schema"],
        "$defs": schema["$defs"],
        "$ref": f"#/$defs/{definition}",
    }
    errors = _schema_error_details(selected, payload)
    if errors:
        raise ReplayError(f"invalid kanchi {definition} contract:\n- " + "\n- ".join(errors))
    _assert_finite_json(payload, f"kanchi {definition}")
    return payload


def _kanchi_fixed_date(spec: Mapping[str, Any]) -> str:
    return _parse_rfc3339(spec["fixed_timestamp"], "fixed_timestamp").date().isoformat()


def _normalize_text_file(path: Path) -> None:
    """Keep generated text artifacts byte-stable under the end-of-file fixer."""
    path.write_text(
        path.read_text(encoding="utf-8").rstrip("\n") + "\n", encoding="utf-8", newline="\n"
    )


def _kanchi_candidate_screen(
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    stage: Path,
    *,
    input_name: str,
    artifact_id: str,
    expected_source: str,
) -> dict[str, dict[str, Any]]:
    if consumed:
        raise ReplayError(f"kanchi {input_name} screen must not consume prior artifacts")
    payload = _validate_kanchi_contract(
        _load_json(inputs[input_name], f"{input_name} fixture"), "candidate_list"
    )
    if payload["source"] != expected_source:
        raise ReplayError(f"{input_name} source must be {expected_source}")
    if payload["as_of"] != _kanchi_fixed_date(spec):
        raise ReplayError(f"{input_name} as_of must match fixed_timestamp date")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts[artifact_id]["files"]["canonical"]), payload)
    return artifacts


def _kanchi_high_yield_screen(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    return _kanchi_candidate_screen(
        spec,
        step,
        inputs,
        consumed,
        stage,
        input_name="high_yield_candidates",
        artifact_id="high_yield_candidates",
        expected_source="value-dividend-screener",
    )


def _kanchi_pullback_screen(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    return _kanchi_candidate_screen(
        spec,
        step,
        inputs,
        consumed,
        stage,
        input_name="pullback_candidates",
        artifact_id="pullback_candidates",
        expected_source="dividend-growth-pullback-screener",
    )


def _kanchi_underwrite(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if not set(consumed) <= {"high_yield_candidates", "pullback_candidates"}:
        raise ReplayError(f"kanchi underwriting received unexpected artifacts: {sorted(consumed)}")
    evidence = _validate_kanchi_contract(
        _load_json(inputs["underwriting_evidence"], "underwriting evidence"),
        "underwriting_evidence",
    )
    decision = _validate_kanchi_contract(
        load_yaml(inputs["underwriting_decision"]), "underwriting_decision"
    )
    fixed_date = _kanchi_fixed_date(spec)
    if evidence["as_of"] != fixed_date:
        raise ReplayError("underwriting evidence as_of must match fixed_timestamp date")
    tickers = [candidate["ticker"] for candidate in evidence["candidates"]]
    if len(tickers) != len(set(tickers)):
        raise ReplayError("underwriting evidence tickers must be unique")

    for artifact_id in sorted(consumed):
        payload = _load_json(
            Path(consumed[artifact_id]["files"]["canonical"]), f"{artifact_id} handoff"
        )
        _validate_kanchi_contract(payload, "candidate_list")
        unknown = {row["ticker"] for row in payload["candidates"]} - set(tickers)
        if unknown:
            raise ReplayError(
                f"{artifact_id} contains tickers missing from underwriting evidence: {sorted(unknown)}"
            )

    verdict_module = _repo_module(
        repo_root,
        "verdict",
        repo_root / "skills" / "kanchi-dividend-sop" / "scripts",
    )

    def _evaluate() -> list[tuple[str, str, bool, tuple[str, ...]]]:
        evaluated: list[tuple[str, str, bool, tuple[str, ...]]] = []
        for candidate in evidence["candidates"]:
            result = verdict_module.synthesize_verdict(
                step1_verdict=candidate["step1_verdict"],
                safety_verdict=candidate["safety_verdict"],
                event_verdict_cap=candidate["event_verdict_cap"],
                event_t1_blocked=candidate["event_t1_blocked"],
                pre_order_blockers=list(candidate["pre_order_blockers"]),
            )
            evaluated.append(
                (
                    candidate["ticker"],
                    result.verdict,
                    bool(result.t1_blocked),
                    tuple(result.reasons),
                )
            )
        return evaluated

    first = _evaluate()
    if first != _evaluate():
        raise ReplayError("native Kanchi verdict synthesis was non-deterministic")

    actionable = [row for row in first if row[1] in KANCHI_ACTIONABLE_VERDICTS]
    excluded = [row for row in first if row[1] not in KANCHI_ACTIONABLE_VERDICTS]
    if [row[0] for row in actionable] != decision["expected_actionable"]:
        raise ReplayError(
            "underwriting decision expected_actionable does not match native verdicts"
        )
    if [row[0] for row in excluded] != decision["expected_excluded"]:
        raise ReplayError("underwriting decision expected_excluded does not match native verdicts")

    kanchi_candidates = {
        "schema_version": 1,
        "as_of": evidence["as_of"],
        "profile": decision["sop_profile"],
        "candidates": [
            {
                "ticker": ticker,
                "verdict": verdict,
                "t1_blocked": flagged,
                "reasons": list(reasons),
            }
            for ticker, verdict, flagged, reasons in actionable
        ],
        "excluded": [
            {"ticker": ticker, "verdict": verdict, "reasons": list(reasons)}
            for ticker, verdict, _flagged, reasons in excluded
        ],
    }
    _validate_kanchi_contract(kanchi_candidates, "kanchi_candidates")

    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["kanchi_candidates"]["files"]["canonical"]), kanchi_candidates)

    sop_input = work / "sop_candidates.json"
    _write_json(
        sop_input,
        {
            "profile": decision["sop_profile"],
            "candidates": [
                {"ticker": ticker, "bucket": "unassigned"} for ticker, _, _, _ in actionable
            ],
        },
    )
    memo_path = Path(artifacts["stock_memo"]["files"]["canonical"])
    _run_cli(
        [
            sys.executable,
            str(repo_root / "skills" / "kanchi-dividend-sop" / "scripts" / "build_sop_plan.py"),
            "--input",
            str(sop_input),
            "--as-of",
            fixed_date,
            "--output-dir",
            str(memo_path.parent),
            "--filename",
            memo_path.name,
        ],
        repo_root,
    )
    _normalize_text_file(memo_path)
    return artifacts


def _kanchi_tax_advice(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if consumed:
        raise ReplayError("kanchi tax advice must not consume prior artifacts")
    payload = _load_json(inputs["tax_holdings"], "tax holdings")
    if (
        not isinstance(payload, dict)
        or not isinstance(payload.get("holdings"), list)
        or not payload["holdings"]
    ):
        raise ReplayError("tax holdings must provide a non-empty holdings list")
    fixed_date = _kanchi_fixed_date(spec)
    reports = work / "tax"
    reports.mkdir(parents=True)
    _run_cli(
        [
            sys.executable,
            str(
                repo_root
                / "skills"
                / "kanchi-dividend-us-tax-accounting"
                / "scripts"
                / "build_tax_planning_sheet.py"
            ),
            "--input",
            str(inputs["tax_holdings"]),
            "--output-dir",
            str(reports),
            "--as-of",
            fixed_date,
        ],
        repo_root,
    )
    markdown = reports / f"tax_planning_sheet_{fixed_date}.md"
    csv_file = reports / f"tax_planning_sheet_{fixed_date}.csv"
    if not markdown.is_file() or not csv_file.is_file():
        raise ReplayError("native tax planning CLI did not produce both markdown and CSV")
    artifacts = _artifact_paths(stage, step["output_files"])
    markdown_out = Path(artifacts["account_location_advice"]["files"]["markdown"])
    csv_out = Path(artifacts["account_location_advice"]["files"]["csv"])
    markdown_out.write_text(markdown.read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    csv_out.write_text(csv_file.read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    _normalize_text_file(markdown_out)
    _normalize_text_file(csv_out)
    return artifacts


def _kanchi_review_actions(report: Mapping[str, Any]) -> list[str]:
    results = report.get("results")
    if not isinstance(results, list):
        raise ReplayError("kanchi review queue report must contain a results list")
    actions: list[str] = []
    for row in results:
        if not isinstance(row, dict) or not isinstance(row.get("actions"), list):
            raise ReplayError("kanchi review queue results must declare an actions list")
        actions.extend(str(action) for action in row["actions"])
    return actions


def _kanchi_review_queue(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if consumed:
        raise ReplayError("kanchi review queue must not consume prior artifacts")
    payload = _load_json(inputs["review_monitor"], "review monitor input")
    if (
        not isinstance(payload, dict)
        or not isinstance(payload.get("holdings"), list)
        or not payload["holdings"]
    ):
        raise ReplayError("review monitor input must provide a non-empty holdings list")
    if payload.get("as_of") != _kanchi_fixed_date(spec):
        raise ReplayError("review monitor as_of must match fixed_timestamp date")
    reports = work / "review"
    reports.mkdir(parents=True)
    json_out = reports / "review_queue.json"
    markdown_out = reports / "review_queue.md"
    _run_cli(
        [
            sys.executable,
            str(
                repo_root
                / "skills"
                / "kanchi-dividend-review-monitor"
                / "scripts"
                / "build_review_queue.py"
            ),
            "--input",
            str(inputs["review_monitor"]),
            "--output",
            str(json_out),
            "--markdown",
            str(markdown_out),
        ],
        repo_root,
    )
    raw = _load_json(json_out, "review queue report")
    generated_at = raw.get("generated_at")
    canonical = _canonicalize(raw, spec["fixed_timestamp"], {})
    for action in _kanchi_review_actions(canonical):
        lowered = action.lower()
        if any(token in lowered for token in KANCHI_FORBIDDEN_REVIEW_TOKENS):
            raise ReplayError(
                f"kanchi review queue must never propose a sell-like action: {action!r}"
            )
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["review_queue"]["files"]["canonical"]), canonical)
    markdown = markdown_out.read_text(encoding="utf-8")
    if isinstance(generated_at, str) and generated_at:
        markdown = re.sub(
            rf"(?m)^- Generated at: `{re.escape(generated_at)}`$",
            lambda _: f"- Generated at: `{spec['fixed_timestamp']}`",
            markdown,
            count=1,
        )
    review_markdown = Path(artifacts["review_queue"]["files"]["companion"])
    review_markdown.write_text(markdown, encoding="utf-8", newline="\n")
    _normalize_text_file(review_markdown)
    return artifacts


def _kanchi_artifact_link(
    consumed: Mapping[str, dict[str, Any]], artifact_id: str, role: str, stage: Path
) -> str:
    """Derive a stable link token from the artifact actually handed forward.

    The token keeps the full path relative to the published staging root, so a
    nested output such as ``nested/03_stock_memo.md`` is not truncated to its
    basename. A target that escapes staging or does not exist fails closed.
    """
    try:
        raw_path = Path(consumed[artifact_id]["files"][role])
    except (KeyError, TypeError) as exc:
        raise ReplayError(
            f"kanchi registration is missing the {artifact_id}.{role} handoff"
        ) from exc
    resolved = raw_path.resolve()
    stage_root = stage.resolve()
    try:
        relative = resolved.relative_to(stage_root)
    except ValueError as exc:
        raise ReplayError(
            f"kanchi registration link target escapes staging: {artifact_id}.{role}"
        ) from exc
    if not resolved.is_file():
        raise ReplayError(f"kanchi registration link target does not exist: {artifact_id}.{role}")
    return f"$ARTIFACT/{relative.as_posix()}"


def _kanchi_register_thesis(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    required = {"kanchi_candidates", "stock_memo"}
    optional = {"account_location_advice", "review_queue"}
    if not required <= set(consumed) or not set(consumed) <= required | optional:
        raise ReplayError(f"kanchi registration received unexpected artifacts: {sorted(consumed)}")
    decision = _validate_kanchi_contract(
        load_yaml(inputs["register_decision"]), "register_decision"
    )
    fixed_date = _kanchi_fixed_date(spec)
    candidates_path = Path(consumed["kanchi_candidates"]["files"]["canonical"])
    candidates = _validate_kanchi_contract(
        _load_json(candidates_path, "kanchi candidates handoff"), "kanchi_candidates"
    )
    memo_path = Path(consumed["stock_memo"]["files"]["canonical"])
    if not memo_path.is_file():
        raise ReplayError("kanchi registration requires the stock_memo handoff")
    if [row["ticker"] for row in candidates["candidates"]] != decision["expected_idea"]:
        raise ReplayError("register decision expected_idea does not match kanchi_candidates")

    scripts_dir = repo_root / "skills" / "trader-memory-core" / "scripts"
    thesis_ingest = _repo_module(repo_root, "thesis_ingest", scripts_dir)
    thesis_store = _repo_module(repo_root, "thesis_store", scripts_dir)
    state_dir = work / "kanchi-state"
    state_dir.mkdir(parents=True)
    thesis_ids = thesis_ingest.ingest("kanchi-dividend-sop", str(candidates_path), str(state_dir))
    if not thesis_ids:
        raise ReplayError("native thesis ingest registered no theses")
    theses = [thesis_store.get(state_dir, thesis_id) for thesis_id in thesis_ids]
    if sorted(row["ticker"] for row in theses) != sorted(decision["expected_idea"]):
        raise ReplayError("native thesis ingest did not register the expected IDEA theses")

    linked_specs = [
        ("kanchi-dividend-sop", _kanchi_artifact_link(consumed, "stock_memo", "canonical", stage))
    ]
    if "account_location_advice" in consumed:
        linked_specs.append(
            (
                "kanchi-dividend-us-tax-accounting",
                _kanchi_artifact_link(consumed, "account_location_advice", "markdown", stage),
            )
        )
    if "review_queue" in consumed:
        linked_specs.append(
            (
                "kanchi-dividend-review-monitor",
                _kanchi_artifact_link(consumed, "review_queue", "canonical", stage),
            )
        )
    for thesis in theses:
        for skill, token in linked_specs:
            thesis_store.link_report(state_dir, thesis["thesis_id"], skill, token, fixed_date)

    entries = []
    for thesis in theses:
        reloaded = thesis_store.get(state_dir, thesis["thesis_id"])
        if reloaded["status"] != "IDEA":
            raise ReplayError("kanchi registration must never leave IDEA status")
        if decision["expected_active"]:
            raise ReplayError("register decision must not promote any thesis to ACTIVE")
        linked = reloaded.get("linked_reports") or []
        memo_link = {
            "skill": "kanchi-dividend-sop",
            "file": linked_specs[0][1],
            "date": fixed_date,
        }
        if memo_link not in linked:
            raise ReplayError("stock_memo was not linked to the IDEA thesis")
        entries.append(
            {
                "ticker": reloaded["ticker"],
                "thesis_type": reloaded["thesis_type"],
                "status": reloaded["status"],
                "created_at": reloaded["created_at"],
                "next_review_date": reloaded["monitoring"]["next_review_date"],
                "origin_skill": reloaded["origin"]["skill"],
                "linked_reports": linked,
            }
        )
    entries.sort(key=lambda row: row["ticker"])
    record = {
        "schema_version": 1,
        "workflow_id": "kanchi-dividend-weekly",
        "recorded_at": spec["fixed_timestamp"],
        "theses": entries,
        "provenance": {
            "execution_mode": "composite",
            "components": ["manual_contract", "native_api"],
            "native_component": "trader-memory-core.thesis_ingest + thesis_store.link_report",
            "source_date": fixed_date,
            "limitation": (
                "Human register decision is a fixture; no broker fill exists, so every "
                "thesis stays IDEA and no order is placed."
            ),
        },
    }
    _validate_kanchi_contract(record, "thesis_record")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["thesis_record"]["files"]["canonical"]), record)
    return artifacts


def _shapiro_parameters(inputs, spec):
    data = _load_json(inputs["decision"], "Shapiro operator decision")
    schema = load_yaml(REPO_ROOT / "examples/workflows/shapiro-contrarian/decision.schema.yaml")
    errors = list(Draft202012Validator(schema).iter_errors(data))
    if errors:
        raise ReplayError(f"invalid Shapiro operator decision: {errors[0].message}")
    _assert_finite_json(data, "Shapiro operator decision")
    if data["as_of"] != datetime.fromisoformat(spec["fixed_timestamp"]).date().isoformat():
        raise ReplayError("Shapiro decision as_of differs from fixed_timestamp")
    return data


def _shapiro_logic(repo_root):
    return _repo_module(repo_root, "gate_logic", repo_root / "skills/contrarian-setup-gate/scripts")


def _shapiro_detector(logic, payload, decision):
    normalized = logic.normalize_crowding(
        payload, None, symbol=decision["symbol"], as_of=decision["as_of"], max_age_days=10
    )
    if normalized.state != logic.STATE_CONFIRMED:
        raise ReplayError(f"Shapiro crowding halted: {normalized.state}: {normalized.reason}")
    # The replay is deliberately a single-market scenario; never silently pick
    # one row from a duplicate or unrelated market universe.
    if len(payload["markets"]) != 1 or payload.get("skipped"):
        raise ReplayError("Shapiro crowding requires exactly one unambiguous market")
    if payload["markets"][0].get("data_date") != payload["run_context"].get("data_date"):
        raise ReplayError("Shapiro crowding dates disagree")
    return normalized


def _shapiro_manual(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _shapiro_parameters(inputs, spec)
    number = step["step"]
    names = {1: "crowding", 2: "news", 3: "price"}
    envelope = _load_json(inputs[names[number]], "Shapiro manual report fixture")
    if (
        not isinstance(envelope, dict)
        or set(envelope) != {"human_approved", "fictional", "report"}
        or envelope["human_approved"] is not True
        or envelope["fictional"] is not True
    ):
        raise ReplayError("Shapiro reports require an approved fictional fixture envelope")
    payload = envelope["report"]
    _assert_finite_json(payload, "Shapiro report")
    logic = _shapiro_logic(repo_root)
    if number == 1:
        _shapiro_detector(logic, payload, decision)
    else:
        detector = _load_json(
            Path(consumed["cot_crowding_report"]["files"]["canonical"]), "crowding handoff"
        )
        normalized_detector = _shapiro_detector(logic, detector, decision)
        normalize = logic.normalize_news if number == 2 else logic.normalize_price_action
        normalized = normalize(
            payload,
            None,
            symbol=decision["symbol"],
            as_of=decision["as_of"],
            max_age_days=7,
            detector=normalized_detector,
        )
        if normalized.state != logic.STATE_CONFIRMED:
            raise ReplayError(
                f"Shapiro {names[number]} halted: {normalized.state}: {normalized.reason}"
            )
    if number == 3:
        stop = _require_finite_number(
            payload["swing_levels"]["stop_reference"], "Shapiro swing stop", minimum=0
        )
        handoff_stop = _require_finite_number(
            payload["handoff"]["price_action"]["stop_reference"], "Shapiro handoff stop", minimum=0
        )
        if stop <= 0 or stop != handoff_stop:
            raise ReplayError("Shapiro price-action stop fields disagree")
    artifacts = _artifact_paths(stage, step["output_files"])
    for bundle in artifacts.values():
        _write_json(Path(bundle["files"]["canonical"]), payload)
    return artifacts


def _shapiro_gate(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _shapiro_parameters(inputs, spec)
    reports = work / "reports"
    command = [
        sys.executable,
        str(repo_root / "skills/contrarian-setup-gate/scripts/run_contrarian_setup_gate.py"),
        "--symbol",
        decision["symbol"],
        "--as-of",
        decision["as_of"],
        "--output-dir",
        str(reports),
        "--format",
        "json",
    ]
    sources = {}
    replacements = {}
    for artifact, flag in (
        ("cot_crowding_report", "--detector-json"),
        ("news_failure_verdict", "--news-json"),
        ("price_action_confirmation_report", "--price-action-json"),
    ):
        path = Path(consumed[artifact]["files"]["canonical"])
        link = _kanchi_artifact_link(consumed, artifact, "canonical", stage)
        command += [flag, str(path)]
        replacements[str(path)] = link
        sources[artifact] = {"file": link, "sha256": _file_sha256(path)}
    _run_cli(command, repo_root)
    files = list(reports.glob("*.json"))
    if len(files) != 1:
        raise ReplayError("Shapiro gate expected one native report")
    payload = _canonicalize(
        _load_json(files[0], "native contrarian gate"), spec["fixed_timestamp"], replacements
    )
    if payload.get("setup_status") != "READY_FOR_PLAN":
        raise ReplayError(f"Shapiro gate halted: {payload.get('setup_status')}")
    payload["replay_sources"] = sources
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["contrarian_setup_gate_report"]["files"]["canonical"]), payload)
    return artifacts


def _shapiro_size(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _shapiro_parameters(inputs, spec)
    gate_path = Path(consumed["contrarian_setup_gate_report"]["files"]["canonical"])
    gate = _load_json(gate_path, "Shapiro sizing gate")
    if gate.get("symbol") != decision["symbol"] or gate.get("setup_status") != "READY_FOR_PLAN":
        raise ReplayError("Shapiro sizing requires a matching READY_FOR_PLAN gate")
    reports = work / "reports"
    _run_cli(
        [
            sys.executable,
            str(repo_root / "skills/futures-position-sizer/scripts/futures_position_sizer.py"),
            "--gate-json",
            str(gate_path),
            "--entry",
            str(decision["entry"]),
            "--account-size",
            str(decision["account_size"]),
            "--risk-pct",
            str(decision["risk_pct"]),
            "--as-of",
            decision["as_of"],
            "--output-dir",
            str(reports),
            "--format",
            "json",
        ],
        repo_root,
    )
    files = list(reports.glob("*.json"))
    if len(files) != 1:
        raise ReplayError("Shapiro sizing expected one native report")
    payload = _canonicalize(
        _load_json(files[0], "native futures sizing"),
        spec["fixed_timestamp"],
        {
            str(gate_path): _kanchi_artifact_link(
                consumed, "contrarian_setup_gate_report", "canonical", stage
            )
        },
    )
    if payload.get("sizing_status") != "SIZED":
        raise ReplayError(f"Shapiro sizing halted: {payload.get('sizing_status')}")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["futures_position_size"]["files"]["canonical"]), payload)
    return artifacts


def _shapiro_journal(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _shapiro_parameters(inputs, spec)
    gate_path = Path(consumed["contrarian_setup_gate_report"]["files"]["canonical"])
    size_path = Path(consumed["futures_position_size"]["files"]["canonical"])
    gate = _load_json(gate_path, "Shapiro journal gate")
    sizing = _load_json(size_path, "Shapiro journal sizing")
    if (
        gate.get("setup_status") != "READY_FOR_PLAN"
        or sizing.get("sizing_status") != "SIZED"
        or gate.get("symbol") != decision["symbol"]
        or sizing.get("symbol") != decision["symbol"]
        or sizing.get("direction") != gate.get("direction")
        or sizing.get("entry") != decision["entry"]
        or sizing.get("stop") != gate.get("invalidation_level")
    ):
        raise ReplayError(
            "Shapiro journal requires matching gate, symbol, direction, entry and stop"
        )
    sources = gate.get("replay_sources", {})
    expected = {"cot_crowding_report", "news_failure_verdict", "price_action_confirmation_report"}
    if set(sources) != expected:
        raise ReplayError("Shapiro journal requires the complete upstream evidence chain")
    # Resolve gate-carried lineage against the actual staging tree before any
    # native state writes. No filenames are assumed and no missing links pass.
    for source in sources.values():
        token = source.get("file", "")
        if not token.startswith("$ARTIFACT/"):
            raise ReplayError("invalid Shapiro evidence link")
        path = _safe_relative(stage, token[len("$ARTIFACT/") :], "Shapiro evidence link")
        if not path.is_file() or _file_sha256(path) != source.get("sha256"):
            raise ReplayError("Shapiro evidence hash mismatch")
    sources = dict(sources)
    for artifact, path in (
        ("contrarian_setup_gate_report", gate_path),
        ("futures_position_size", size_path),
    ):
        sources[artifact] = {
            "file": _kanchi_artifact_link(consumed, artifact, "canonical", stage),
            "sha256": _file_sha256(path),
        }
    store = _repo_module(repo_root, "thesis_store", repo_root / "skills/trader-memory-core/scripts")
    state = work / "state"
    thesis_id = store.register(
        state,
        {
            "ticker": decision["symbol"],
            "thesis_type": "mean_reversion",
            "thesis_statement": decision["thesis_statement"],
            "kill_criteria": [decision["kill_criterion"]],
            "_source_date": decision["as_of"],
            "origin": {
                "skill": "contrarian-setup-gate",
                "output_file": sources["contrarian_setup_gate_report"]["file"],
            },
        },
    )
    store.attach_futures_position(
        state,
        thesis_id,
        str(size_path),
        expected_entry=decision["entry"],
        expected_stop=gate["invalidation_level"],
    )
    producer_skills = {
        "cot_crowding_report": "cot-contrarian-detector",
        "news_failure_verdict": "news-reaction-failure-analyzer",
        "price_action_confirmation_report": "technical-analyst",
        "contrarian_setup_gate_report": "contrarian-setup-gate",
        "futures_position_size": "futures-position-sizer",
    }
    for artifact, source in sorted(sources.items()):
        store.link_report(
            state, thesis_id, producer_skills[artifact], source["file"], decision["as_of"]
        )
    thesis = store.get(state, thesis_id)
    if thesis["status"] != "IDEA" or thesis["entry"].get("actual_price") is not None:
        raise ReplayError("Shapiro replay must never record a fill or promote to ACTIVE")
    # The native store also attaches an ephemeral sizing-report path; replace
    # it with the portable link in the export, retaining the native mutation.
    payload = {
        key: thesis[key]
        for key in (
            "ticker",
            "status",
            "created_at",
            "position",
            "entry",
            "thesis_statement",
            "kill_criteria",
        )
    }
    payload["linked_reports"] = _canonicalize(
        thesis["linked_reports"],
        spec["fixed_timestamp"],
        {str(size_path): sources["futures_position_size"]["file"]},
    )
    payload["sources"] = sources
    payload["manual_review_required"] = True
    payload["execution_authorized"] = False
    payload = _canonicalize(
        payload, spec["fixed_timestamp"], {str(size_path): sources["futures_position_size"]["file"]}
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["contrarian_thesis_entry"]["files"]["canonical"]), payload)
    return artifacts


def _ep_input(inputs, name, spec):
    envelope = _load_json(inputs[name], f"EP {name} fixture")
    if (
        not isinstance(envelope, dict)
        or set(envelope) != {"human_approved", "fictional", "as_of", "data"}
        or envelope["human_approved"] is not True
        or envelope["fictional"] is not True
        or envelope["as_of"] != spec["fixed_timestamp"][:10]
    ):
        raise ReplayError(f"EP {name} requires a dated, approved fictional fixture")
    _assert_finite_json(envelope, f"EP {name}")
    return envelope["data"]


def _ep_parameters(inputs, spec):
    data = _ep_input(inputs, "decision", spec)
    schema = load_yaml(REPO_ROOT / "examples/workflows/stockbee-ep-daily/decision.schema.yaml")
    errors = list(Draft202012Validator(schema).iter_errors(data))
    if errors:
        raise ReplayError(f"invalid EP decision: {errors[0].message}")
    return data


def _ep_read(consumed, artifact):
    return _load_json(Path(consumed[artifact]["files"]["canonical"]), f"EP {artifact} handoff")


def _ep_sources(consumed, stage):
    return {
        key: {
            "file": _kanchi_artifact_link(consumed, key, "canonical", stage),
            "sha256": _file_sha256(Path(bundle["files"]["canonical"])),
        }
        for key, bundle in sorted(consumed.items())
    }


def _ep_circuit(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _ep_parameters(inputs, spec)
    regime = _ep_input(inputs, "exposure", spec)
    if (
        regime.get("recommendation") != "NEW_ENTRY_ALLOWED"
        or regime.get("generated_at") != spec["fixed_timestamp"]
    ):
        raise ReplayError("EP market gate requires a current NEW_ENTRY_ALLOWED decision")
    state = _ep_input(inputs, "account_state", spec)
    if not isinstance(state, list) or not all(isinstance(item, dict) for item in state):
        raise ReplayError("EP account state must be an explicit thesis list")
    ids = set()
    for thesis in state:
        if (
            not isinstance(thesis.get("thesis_id"), str)
            or not thesis["thesis_id"]
            or thesis["thesis_id"] in ids
            or not isinstance(thesis.get("ticker"), str)
            or not thesis["ticker"]
            or thesis.get("status")
            not in {"IDEA", "ACTIVE", "PARTIALLY_CLOSED", "CLOSED", "INVALIDATED"}
        ):
            raise ReplayError(
                "EP account state requires unique identified theses with valid statuses"
            )
        ids.add(thesis["thesis_id"])
    state_dir = work / "state"
    state_dir.mkdir()
    for index, thesis in enumerate(state):
        _write_yaml(state_dir / f"th_fixture_{index}.yaml", thesis)
    reports = work / "reports"
    _run_cli(
        [
            sys.executable,
            str(repo_root / "skills/drawdown-circuit-breaker/scripts/check_circuit_breaker.py"),
            "--state-dir",
            str(state_dir),
            "--account-size",
            str(decision["account_size"]),
            "--as-of",
            spec["fixed_timestamp"],
            "--output-dir",
            str(reports),
            "--json-only",
        ],
        repo_root,
    )
    payload = _canonicalize(
        _load_json(
            _latest_report(reports, "circuit_breaker_decision_*.json"), "EP circuit decision"
        ),
        spec["fixed_timestamp"],
        {str(state_dir): "$WORK/account_state", str(reports): "$WORK/reports"},
    )
    if payload.get("recommendation") != "TRADING_ALLOWED":
        raise ReplayError(f"EP circuit breaker halted: {payload.get('recommendation')}")
    payload["replay_inputs"] = {
        key: _file_sha256(inputs[key]) for key in ("exposure", "account_state")
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["circuit_breaker_decision"]["files"]["canonical"]), payload)
    return artifacts


def _ep_screen(repo_root, spec, step, inputs, consumed, work, stage):
    name = "earnings" if step["step"] == 2 else "momentum"
    payload = _ep_input(inputs, name, spec)
    rows = payload.get("results") if isinstance(payload, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ReplayError(f"EP {name} requires explicit screen results")
    events = _ep_input(inputs, "events", spec)["events"]
    symbols = {e["symbol"] for e in events}
    if any(not isinstance(row, dict) or row.get("symbol") not in symbols for row in rows):
        raise ReplayError(f"EP {name} contains an unbound symbol")
    date_key = "earnings_date" if name == "earnings" else "setup_date"
    if any(row.get(date_key) != spec["fixed_timestamp"][:10] for row in rows):
        raise ReplayError(f"EP {name} contains a stale date")
    artifacts = _artifact_paths(stage, step["output_files"])
    for bundle in artifacts.values():
        _write_json(Path(bundle["files"]["canonical"]), payload)
    return artifacts


def _validate_ep_analyze_contract(payload: Any) -> Mapping[str, Any]:
    schema = _load_json(EP_ANALYZE_SCHEMA, "stockbee-ep analyze replay contract schema")
    selected = {
        "$schema": schema["$schema"],
        "$defs": schema["$defs"],
        "$ref": "#/$defs/analyze_ep_report",
    }
    errors = _schema_error_details(selected, payload)
    if errors:
        raise ReplayError("invalid stockbee-ep analyze report contract:\n- " + "\n- ".join(errors))
    _assert_finite_json(payload, "stockbee-ep analyze report")
    return payload


def _ep_analyze(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _ep_parameters(inputs, spec)
    events = _ep_input(inputs, "events", spec)
    prices = _ep_input(inputs, "prices", spec)
    rows = events.get("events") if isinstance(events, dict) else None
    if not isinstance(rows, list) or not rows or any(not isinstance(e, dict) for e in rows):
        raise ReplayError("EP requires nonempty catalyst events")
    symbols = [e.get("symbol") for e in rows]
    if any(
        not isinstance(s, str) or not re.fullmatch(r"[A-Z][A-Z0-9]{0,9}", s) for s in symbols
    ) or len(set(symbols)) != len(symbols):
        raise ReplayError("EP event symbols must be valid and unique")
    bars_by_symbol = prices.get("prices") if isinstance(prices, dict) else None
    if not isinstance(bars_by_symbol, dict) or set(bars_by_symbol) != set(symbols):
        raise ReplayError("EP prices must cover exactly the event symbols")
    for event in rows:
        if event.get("event_date") != spec["fixed_timestamp"][:10] or not event.get("headline"):
            raise ReplayError("EP requires a current explicit catalyst")
        bars = bars_by_symbol[event["symbol"]]
        if not isinstance(bars, list) or len(bars) < 51:
            raise ReplayError("EP requires complete offline OHLCV history")
        dates = []
        for bar in bars:
            if not isinstance(bar, dict):
                raise ReplayError("EP invalid OHLCV row")
            dates.append(datetime.strptime(bar["date"], "%Y-%m-%d").date().isoformat())
            for field in ("open", "high", "low", "close", "volume"):
                _require_finite_number(bar.get(field), f"EP {field}", minimum=0)
            if (
                not 0
                < bar["low"]
                <= min(bar["open"], bar["close"])
                <= max(bar["open"], bar["close"])
                <= bar["high"]
            ):
                raise ReplayError("EP inconsistent OHLC prices")
        if dates != sorted(set(dates)) or dates[-1] != event["event_date"]:
            raise ReplayError("EP history must be ordered, unique, and end on the event date")
    event_path, prices_path = work / "events.json", work / "prices.json"
    _write_json(event_path, events)
    _write_json(prices_path, prices)
    reports = work / "reports"
    command = [
        sys.executable,
        str(repo_root / "skills/stockbee-episodic-pivot-analyzer/scripts/analyze_ep.py"),
        "--events-json",
        str(event_path),
        "--prices-json",
        str(prices_path),
        "--max-api-calls",
        "0",
        "--max-risk-pct",
        str(decision["max_ep_risk_pct"]),
        "--output-dir",
        str(reports),
    ]
    replacements = {str(event_path): "$INPUT/events", str(prices_path): "$INPUT/prices"}
    for artifact, flag in (
        ("earnings_candidates", "--earnings-json"),
        ("momentum_burst_candidates", "--momentum-json"),
    ):
        if artifact in consumed:
            path = Path(consumed[artifact]["files"]["canonical"])
            screen = _load_json(path, artifact)
            if any(row.get("symbol") not in symbols for row in screen["results"]):
                raise ReplayError("EP screen handoff symbol mismatch")
            command += [flag, str(path)]
            replacements[str(path)] = _kanchi_artifact_link(consumed, artifact, "canonical", stage)
    _run_cli(command, repo_root)
    payload = _canonicalize(
        _load_json(_latest_report(reports, "stockbee_episodic_pivot_*.json"), "native EP result"),
        spec["fixed_timestamp"],
        replacements,
    )
    _validate_ep_analyze_contract(payload)
    if payload["metadata"].get("api_stats") is not None:
        raise ReplayError("EP replay unexpectedly enabled live API enrichment")
    if {r["symbol"] for r in payload["results"]} != set(symbols):
        raise ReplayError("native EP result lost or added symbols")
    actionable = [r["symbol"] for r in payload["results"] if r["state"] == "ACTIONABLE_DAY1"]
    if actionable != [decision["symbol"]]:
        raise ReplayError("EP gate requires exactly the reviewed ACTIONABLE_DAY1 candidate")
    payload["sources"] = _ep_sources(consumed, stage)
    payload["input_sha256"] = {key: _file_sha256(inputs[key]) for key in ("events", "prices")}
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["episodic_pivot_candidates"]["files"]["canonical"]), payload)
    for key in ("pead_handoff_candidates", "delayed_ep_watchlist"):
        _write_json(
            Path(artifacts[key]["files"]["canonical"]),
            {"candidates": payload[key], "order_authorized": False},
        )
    return artifacts


def _ep_validate(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _ep_parameters(inputs, spec)
    analysis = _ep_read(consumed, "episodic_pivot_candidates")
    _validate_ep_analyze_contract(analysis)
    selected = [
        r
        for r in analysis["results"]
        if r["symbol"] == decision["symbol"] and r["state"] == "ACTIONABLE_DAY1"
    ]
    if len(selected) != 1:
        raise ReplayError("EP chart review requires the actionable native classification")
    setup = _ep_input(inputs, "chart", spec)
    row = selected[0]
    if (
        setup.get("verdict") != "CONFIRMED"
        or setup.get("symbol") != row["symbol"]
        or setup.get("entry_price") != row["trade_plan_inputs"]["entry_reference"]
        or setup.get("stop_price") != row["trade_plan_inputs"]["stop_reference"]
    ):
        raise ReplayError("EP chart confirmation does not match the native entry/EP-day low")
    for key in ("entry_price", "stop_price", "target_price"):
        _require_finite_number(setup.get(key), f"EP chart {key}", minimum=0)
    if not 0 < setup["stop_price"] < setup["entry_price"] < setup["target_price"]:
        raise ReplayError("EP chart requires a sizeable long setup")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(
        Path(artifacts["validated_ep_setups"]["files"]["canonical"]),
        {
            "as_of": spec["fixed_timestamp"][:10],
            "setups": [setup],
            "sources": _ep_sources(consumed, stage),
            "watchlist": [
                {"symbol": r["symbol"], "state": r["state"], "pead_handoff": r["pead_handoff"]}
                for r in analysis["results"]
                if r["state"] != "ACTIONABLE_DAY1"
            ],
        },
    )
    return artifacts


def _ep_size(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _ep_parameters(inputs, spec)
    validated = _ep_read(consumed, "validated_ep_setups")
    if len(validated["setups"]) != 1 or validated["setups"][0]["symbol"] != decision["symbol"]:
        raise ReplayError("EP sizing requires one reviewed setup")
    setup = validated["setups"][0]
    for key in ("entry_price", "stop_price", "target_price"):
        _require_finite_number(setup.get(key), f"EP sizing {key}", minimum=0)
    if not 0 < setup["stop_price"] < setup["entry_price"] < setup["target_price"]:
        raise ReplayError("EP sizing requires a valid long setup")
    parameters = work / "parameters.json"
    _write_json(parameters, decision)
    result = _swing_position_size(
        repo_root,
        spec,
        dict(step, output_files={"position_sizing": step["output_files"]["ep_position_sizing"]}),
        {"sizing_parameters": parameters},
        {"validated_setups": consumed["validated_ep_setups"]},
        work,
        stage,
    )
    return {"ep_position_sizing": result["position_sizing"]}


def _ep_match_size(consumed, decision):
    setup = _ep_read(consumed, "validated_ep_setups")["setups"][0]
    size = _ep_read(consumed, "ep_position_sizing")
    if (
        setup["symbol"] != decision["symbol"]
        or size["parameters"]["entry_price"] != setup["entry_price"]
        or size["parameters"]["stop_price"] != setup["stop_price"]
    ):
        raise ReplayError("EP sizing/setup mismatch")
    shares = _require_finite_number(
        size["final_recommended_shares"], "EP shares", integer=True, minimum=1
    )
    risk = _require_finite_number(size["final_risk_dollars"], "EP risk", minimum=0)
    value = _require_finite_number(size["final_position_value"], "EP position value", minimum=0)
    if not math.isclose(value, shares * setup["entry_price"], abs_tol=0.01):
        raise ReplayError("EP position value disagrees with shares and entry")
    if (
        not math.isclose(risk, shares * (setup["entry_price"] - setup["stop_price"]), abs_tol=0.01)
        or risk > decision["account_size"] * decision["risk_pct"] / 100 + 0.01
    ):
        raise ReplayError("EP sizing exceeds the reviewed risk budget")
    return setup, size


def _ep_plan(repo_root, spec, step, inputs, consumed, work, stage):
    _ep_match_size(consumed, _ep_parameters(inputs, spec))
    result = _swing_build_plan(
        repo_root,
        spec,
        dict(step, output_files={"trade_plans": step["output_files"]["ep_trade_plan"]}),
        inputs,
        {
            "validated_setups": consumed["validated_ep_setups"],
            "position_sizing": consumed["ep_position_sizing"],
        },
        work,
        stage,
    )
    return {"ep_trade_plan": result["trade_plans"]}


def _ep_journal(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _ep_parameters(inputs, spec)
    setup, size = _ep_match_size(consumed, decision)
    sources = _ep_sources(consumed, stage)
    store = _repo_module(repo_root, "thesis_store", repo_root / "skills/trader-memory-core/scripts")
    state = work / "journal"
    tid = store.register(
        state,
        {
            "ticker": setup["symbol"],
            "thesis_type": "growth_momentum",
            "thesis_statement": decision["thesis_statement"],
            "kill_criteria": [decision["kill_criterion"]],
            "_source_date": spec["fixed_timestamp"][:10],
            "entry": {"target_price": setup["entry_price"]},
            "exit": {"stop_loss": setup["stop_price"]},
            "origin": {
                "skill": "stockbee-episodic-pivot-analyzer",
                "output_file": sources["validated_ep_setups"]["file"],
            },
        },
    )
    path = Path(consumed["ep_position_sizing"]["files"]["canonical"])
    store.attach_position(
        state,
        tid,
        str(path),
        expected_entry=setup["entry_price"],
        expected_stop=setup["stop_price"],
    )
    producer_skills = {
        "validated_ep_setups": "technical-analyst",
        "ep_position_sizing": "position-sizer",
        "ep_trade_plan": "breakout-trade-planner",
    }
    for artifact, source in sources.items():
        store.link_report(
            state, tid, producer_skills[artifact], source["file"], spec["fixed_timestamp"][:10]
        )
    thesis = store.get(state, tid)
    if thesis["status"] != "IDEA" or thesis["entry"]["actual_price"] is not None:
        raise ReplayError("EP must retain IDEA without a fill")
    payload = {
        k: thesis[k]
        for k in (
            "ticker",
            "status",
            "created_at",
            "thesis_statement",
            "kill_criteria",
            "entry",
            "exit",
            "position",
            "linked_reports",
        )
    }
    payload["sources"] = sources
    payload["watchlist"] = _ep_read(consumed, "validated_ep_setups")["watchlist"]
    payload["execution_authorized"] = False
    payload = _canonicalize(
        payload, spec["fixed_timestamp"], {str(path): sources["ep_position_sizing"]["file"]}
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["ep_journal_entry"]["files"]["canonical"]), payload)
    return artifacts


def _ep_discipline(repo_root, spec, step, inputs, consumed, work, stage):
    decision = _ep_parameters(inputs, spec)
    journal = _ep_read(consumed, "ep_journal_entry")
    size = _ep_read(consumed, "ep_position_sizing")
    circuit = _ep_read(consumed, "circuit_breaker_decision")
    if circuit.get("recommendation") != "TRADING_ALLOWED":
        raise ReplayError("EP discipline received a stopped circuit breaker")
    if (
        journal["ticker"] != decision["symbol"]
        or journal["status"] != "IDEA"
        or journal["position"]["shares"] != size["final_recommended_shares"]
        or journal["position"]["risk_dollars"] != size["final_risk_dollars"]
        or journal["entry"]["target_price"] != size["parameters"]["entry_price"]
        or journal["exit"]["stop_loss"] != size["parameters"]["stop_price"]
    ):
        raise ReplayError("EP journal/sizing discipline mismatch")
    answers = _ep_input(inputs, "checklist", spec)
    fields = ("entry_in_written_plan", "stop_predefined", "size_within_plan")
    if answers.get("symbol") != journal["ticker"] or any(
        type(answers.get(k)) is not bool for k in fields
    ):
        raise ReplayError(
            "EP checklist must contain explicit reviewed booleans for the same symbol"
        )
    candidate = {
        "symbol": journal["ticker"],
        "order_intent": "MANUAL_ORDER",
        **{k: answers[k] for k in fields},
        "planned_risk_dollars": size["final_risk_dollars"],
        "actual_risk_dollars": size["final_risk_dollars"],
    }
    if "ep_trade_plan" not in consumed:
        candidate.update({k: False for k in fields})
    else:
        plans = _ep_read(consumed, "ep_trade_plan").get("plans")
        expected = {
            "symbol": journal["ticker"],
            "entry_price": size["parameters"]["entry_price"],
            "stop_price": size["parameters"]["stop_price"],
            "shares": size["final_recommended_shares"],
            "position_value": size["final_position_value"],
            "planned_risk_dollars": size["final_risk_dollars"],
        }
        if (
            not isinstance(plans, list)
            or len(plans) != 1
            or any(plans[0].get(k) != v for k, v in expected.items())
        ):
            raise ReplayError("EP written plan does not match journal and sizing")
    answer_path, regime_path = work / "answers.json", work / "regime.json"
    watch_answers = [
        {"symbol": row["symbol"], "order_intent": "WATCHLIST"} for row in journal["watchlist"]
    ]
    _write_json(answer_path, {"candidates": [candidate, *watch_answers]})
    _write_json(regime_path, _ep_input(inputs, "exposure", spec))
    circuit_path = Path(consumed["circuit_breaker_decision"]["files"]["canonical"])
    state_dir = work / "account_state"
    state_dir.mkdir()
    for index, thesis in enumerate(_ep_input(inputs, "account_state", spec)):
        _write_yaml(state_dir / f"th_fixture_{index}.yaml", thesis)
    reports, journal_dir = work / "reports", work / "discipline_journal"
    _run_cli(
        [
            sys.executable,
            str(
                repo_root / "skills/pre-trade-discipline-gate/scripts/check_pre_trade_discipline.py"
            ),
            "--state-dir",
            str(state_dir),
            "--answers-file",
            str(answer_path),
            "--as-of",
            spec["fixed_timestamp"],
            "--market-regime-decision",
            str(regime_path),
            "--circuit-breaker-decision",
            str(circuit_path),
            "--output-dir",
            str(reports),
            "--journal-dir",
            str(journal_dir),
        ],
        repo_root,
    )
    payload = _load_json(
        _latest_report(reports, "pre_trade_discipline_decision_*.json"), "native EP discipline"
    )
    payload = _canonicalize(
        payload,
        spec["fixed_timestamp"],
        {
            str(regime_path): "$INPUT/exposure",
            str(state_dir): "$WORK/account_state",
            str(circuit_path): _kanchi_artifact_link(
                consumed, "circuit_breaker_decision", "canonical", stage
            ),
            str(reports): "$WORK/reports",
            str(journal_dir): "$WORK/discipline_journal",
        },
    )
    artifacts = _artifact_paths(stage, step["output_files"])
    payload["artifact_paths"] = {
        "json": _safe_relative(
            stage,
            step["output_files"]["pre_trade_discipline_decision"]["canonical"],
            "EP discipline output",
        )
        .relative_to(stage.resolve())
        .as_posix()
    }
    payload["replay_sources"] = _ep_sources(consumed, stage)
    payload["checklist_sha256"] = _file_sha256(inputs["checklist"])
    payload["execution_authorized"] = False
    _write_json(Path(artifacts["pre_trade_discipline_decision"]["files"]["canonical"]), payload)
    return artifacts


def _validate_multi_asset_contract(payload: Any, definition: str) -> Mapping[str, Any]:
    schema = _load_json(MULTI_ASSET_REPLAY_SCHEMA, "multi-asset replay contract schema")
    selected = {
        "$schema": schema["$schema"],
        "$defs": schema["$defs"],
        "$ref": f"#/$defs/{definition}",
    }
    errors = _schema_error_details(selected, payload)
    if errors:
        raise ReplayError(f"invalid multi-asset {definition} contract:\n- " + "\n- ".join(errors))
    _assert_finite_json(payload, f"multi-asset {definition}")
    return payload


def _multi_asset_fixed_date(spec: Mapping[str, Any]) -> str:
    return _parse_rfc3339(spec["fixed_timestamp"], "fixed_timestamp").date().isoformat()


def _multi_macro_modules(repo_root: Path) -> tuple[Any, Any]:
    scripts_dir = repo_root / "skills" / "macro-regime-detector" / "scripts"
    scorer = _load_module_from_path(scripts_dir / "scorer.py", "multi_asset_macro_scorer")
    reporter = _load_module_from_path(
        scripts_dir / "report_generator.py", "multi_asset_macro_reporter"
    )
    return scorer, reporter


def _multi_macro_regime(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if consumed:
        raise ReplayError("multi-asset macro regime must not consume prior artifacts")
    fixture = _validate_multi_asset_contract(
        _load_json(inputs["macro_components"], "macro components fixture"), "macro_components"
    )
    fixed_date = _multi_asset_fixed_date(spec)
    if fixture["as_of"] != fixed_date:
        raise ReplayError("macro components as_of must match fixed_timestamp date")
    components = fixture["components"]
    scorer, reporter = _multi_macro_modules(repo_root)

    def _analyze() -> dict[str, Any]:
        component_scores = {key: value["score"] for key, value in components.items()}
        data_availability = {key: value["data_available"] for key, value in components.items()}
        composite = scorer.calculate_composite_score(component_scores, data_availability)
        regime = scorer.classify_regime(components)
        regime["consistency"] = scorer.check_regime_consistency(
            regime["current_regime"], components
        )
        return {
            "metadata": {
                "generated_at": spec["fixed_timestamp"],
                "data_source": "fixture",
                "data_mode": "offline",
                "as_of": fixed_date,
            },
            "composite": composite,
            "regime": regime,
            "components": components,
        }

    first = _analyze()
    if first != _analyze():
        raise ReplayError("native macro regime synthesis was non-deterministic")
    if not first["regime"].get("regime_label"):
        raise ReplayError("native macro regime synthesis produced no regime label")
    if first["composite"].get("composite_score") is None:
        raise ReplayError("native macro regime synthesis produced no composite score")
    artifacts = _artifact_paths(stage, step["output_files"])
    draft = work / "macro_regime_brief.json"
    try:
        reporter.generate_json_report(first, str(draft))
    except Exception as exc:
        raise ReplayError(f"macro regime native report API failed: {exc}") from exc
    produced = _load_json(draft, "macro regime generated brief")
    if produced != first:
        raise ReplayError("macro regime native report did not round-trip the analysis")
    _assert_finite_json(produced, "macro regime brief")
    _write_json(Path(artifacts["macro_regime_brief"]["files"]["canonical"]), produced)
    return artifacts


def _multi_theme(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"macro_regime_brief"}:
        raise ReplayError(f"multi-asset theme received unexpected artifacts: {sorted(consumed)}")
    brief_path = Path(consumed["macro_regime_brief"]["files"]["canonical"])
    brief = _load_json(brief_path, "macro regime brief handoff")
    evidence = _validate_multi_asset_contract(
        _load_json(inputs["theme_evidence"], "theme evidence fixture"), "theme_evidence"
    )
    if evidence["as_of"] != _multi_asset_fixed_date(spec):
        raise ReplayError("theme evidence as_of must match fixed_timestamp date")
    if evidence["regime_label"] != brief["regime"]["regime_label"]:
        raise ReplayError("theme evidence regime_label does not match the macro regime brief")
    names = [theme["name"] for theme in evidence["themes"]]
    if len(names) != len(set(names)):
        raise ReplayError("theme evidence theme names must be unique")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["hot_themes"]["files"]["canonical"]), evidence)
    return artifacts


def _multi_news_brief(
    _repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    _work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"hot_themes"}:
        raise ReplayError(
            f"multi-asset news brief received unexpected artifacts: {sorted(consumed)}"
        )
    hot_path = Path(consumed["hot_themes"]["files"]["canonical"])
    hot = _load_json(hot_path, "hot themes handoff")
    brief = _validate_multi_asset_contract(load_yaml(inputs["news_brief"]), "news_brief")
    if brief["as_of"] != _multi_asset_fixed_date(spec):
        raise ReplayError("news brief as_of must match fixed_timestamp date")
    known = {theme["name"] for theme in hot["themes"]}
    unknown = set(brief["based_on_themes"]) - known
    if unknown:
        raise ReplayError(
            f"news brief references themes missing from hot_themes: {sorted(unknown)}"
        )
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["catalyst_news_brief"]["files"]["canonical"]), brief)
    return artifacts


def _require_unique_ids(ids: Sequence[str], label: str) -> None:
    """Fail closed when a hypothesis id list contains duplicates.

    Primary guard for lists the schema cannot constrain: native ideator
    output and uniqueness across the actionable + excluded arrays. The human
    decision lists also carry schema uniqueItems, which fires first; calling
    it there too keeps the partition checks correct if that schema is relaxed.
    """
    seen: set[str] = set()
    dups: set[str] = set()
    for value in ids:
        if value in seen:
            dups.add(value)
        seen.add(value)
    if dups:
        raise ReplayError(f"{label} contain duplicate hypothesis ids: {sorted(dups)}")


def _multi_hypotheses(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if "catalyst_news_brief" in consumed:
        expected_consumed = {"macro_regime_brief", "hot_themes", "catalyst_news_brief"}
    else:
        expected_consumed = {"macro_regime_brief", "hot_themes"}
    if set(consumed) != expected_consumed:
        raise ReplayError(
            f"multi-asset hypotheses received unexpected artifacts: {sorted(consumed)}"
        )
    bundle = _validate_multi_asset_contract(
        _load_json(inputs["hypotheses_bundle"], "hypotheses bundle"), "hypotheses_bundle"
    )
    raw = _validate_multi_asset_contract(
        _load_json(inputs["raw_hypotheses"], "raw hypotheses"), "raw_hypotheses"
    )
    raw_by_id = {card["hypothesis_id"]: card for card in raw["hypotheses"]}
    if len(raw_by_id) != len(raw["hypotheses"]):
        raise ReplayError("raw hypotheses contain duplicate hypothesis ids")
    decision = _validate_multi_asset_contract(load_yaml(inputs["gate_decision"]), "gate_decision")
    binding = bundle["source_binding"]
    for artifact_id in ("macro_regime_brief", "hot_themes"):
        actual = _file_sha256(Path(consumed[artifact_id]["files"]["canonical"]))
        if binding[artifact_id] != actual:
            raise ReplayError(
                f"hypotheses bundle source_binding mismatch for {artifact_id}: "
                f"expected {binding[artifact_id]}, actual {actual}"
            )
    if "catalyst_news_brief" in consumed:
        actual = _file_sha256(Path(consumed["catalyst_news_brief"]["files"]["canonical"]))
        if binding["catalyst_news_brief"] != actual:
            raise ReplayError(
                "hypotheses bundle source_binding mismatch for catalyst_news_brief: "
                f"expected {binding['catalyst_news_brief']}, actual {actual}"
            )
    # When the optional step 3 is disabled (required-only), the shared bundle's
    # catalyst binding is simply not checked; the full-path run above enforces it.

    reports = work / "reports"
    reports.mkdir(parents=True)
    ideator = (
        repo_root / "skills" / "trade-hypothesis-ideator" / "scripts" / "run_hypothesis_ideator.py"
    )
    _run_cli(
        [
            sys.executable,
            str(ideator),
            "--input",
            str(inputs["hypotheses_bundle"]),
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    _run_cli(
        [
            sys.executable,
            str(ideator),
            "--input",
            str(inputs["hypotheses_bundle"]),
            "--hypotheses",
            str(inputs["raw_hypotheses"]),
            "--output-dir",
            str(reports),
        ],
        repo_root,
    )
    bundle_out = _load_json(
        _latest_report(reports, "output_bundle.json"), "hypothesis output bundle"
    )
    if "generated_at_utc" in bundle_out:
        bundle_out["generated_at_utc"] = spec["fixed_timestamp"]
    _assert_finite_json(bundle_out, "hypothesis output bundle")
    output_ids = [card["hypothesis_id"] for card in bundle_out["hypotheses"]]
    _require_unique_ids(output_ids, "hypothesis output bundle")
    if set(output_ids) != set(raw_by_id) or len(output_ids) != len(raw_by_id):
        raise ReplayError("hypothesis output bundle does not preserve the raw hypothesis cards")
    accepted = decision["accepted"]
    rejected = decision["rejected"]
    _require_unique_ids(accepted, "gate_decision.accepted")
    _require_unique_ids(rejected, "gate_decision.rejected")
    if set(accepted) | set(rejected) != set(output_ids) or set(accepted) & set(rejected):
        raise ReplayError("gate decision must partition exactly the output hypothesis cards")
    actionable: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    for card in bundle_out["hypotheses"]:
        raw_card = raw_by_id[card["hypothesis_id"]]
        merged = {
            **card,
            "ticker": raw_card.get("ticker"),
            "asset_class": raw_card.get("asset_class", "equity"),
            "research_only": bool(raw_card.get("research_only", False)),
        }
        if card["hypothesis_id"] in set(accepted):
            if merged["asset_class"] == "forex":
                raise ReplayError(
                    f"actionable hypothesis {card['hypothesis_id']} is forex: research-only output must never be sized"
                )
            actionable.append(merged)
        else:
            excluded.append(merged)
    for card in actionable + excluded:
        if card["asset_class"] == "forex" and not card["research_only"]:
            raise ReplayError(
                f"forex hypothesis {card['hypothesis_id']} must carry research_only=true"
            )
    if not actionable:
        raise ReplayError("hypothesis gate produced no actionable cards")
    cards = {
        "schema_version": 1,
        "as_of": _multi_asset_fixed_date(spec),
        "hypotheses": actionable,
        "excluded": excluded,
    }
    _validate_multi_asset_contract(cards, "hypothesis_cards")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["hypothesis_cards"]["files"]["canonical"]), cards)
    return artifacts


def _multi_position_size(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"hypothesis_cards"}:
        raise ReplayError(
            f"multi-asset position sizing received unexpected artifacts: {sorted(consumed)}"
        )
    cards_path = Path(consumed["hypothesis_cards"]["files"]["canonical"])
    cards_doc = _validate_multi_asset_contract(
        _load_json(cards_path, "hypothesis cards handoff"), "hypothesis_cards"
    )
    # The schema cannot express cross-array uniqueness, so the union of
    # actionable and excluded ids is checked here explicitly.
    _require_unique_ids(
        [card["hypothesis_id"] for card in cards_doc["hypotheses"]]
        + [card["hypothesis_id"] for card in cards_doc.get("excluded", [])],
        "hypothesis cards handoff",
    )
    params = _validate_multi_asset_contract(
        _load_json(inputs["sizing_params"], "sizing parameters"), "sizing_params"
    )
    actionable = cards_doc["hypotheses"]
    param_by_id = {row["hypothesis_id"]: row for row in params["cards"]}
    if len(param_by_id) != len(params["cards"]):
        raise ReplayError("sizing parameters contain duplicate hypothesis ids")
    if set(param_by_id) != {card["hypothesis_id"] for card in actionable}:
        raise ReplayError("sizing parameters must cover exactly the actionable hypothesis cards")
    reports = work / "reports"
    reports.mkdir(parents=True)
    sizer = repo_root / "skills" / "position-sizer" / "scripts" / "position_sizer.py"
    sized: list[dict[str, Any]] = []
    for index, card in enumerate(actionable):
        entry = param_by_id[card["hypothesis_id"]]
        card_dir = reports / f"card-{index}"
        card_dir.mkdir(parents=True)
        command = [
            sys.executable,
            str(sizer),
            "--account-size",
            str(params["account_size"]),
            "--entry",
            str(entry["entry"]),
            "--stop",
            str(entry["stop"]),
            "--risk-pct",
            str(params["risk_pct"]),
        ]
        if params.get("max_position_pct") is not None:
            command.extend(["--max-position-pct", str(params["max_position_pct"])])
        command.extend(["--output-dir", str(card_dir)])
        _run_cli(command, repo_root)
        native = _load_json(
            _latest_report(card_dir, "position_sizer_*.json"), "position sizer report"
        )
        canonical = _canonicalize(native, spec["fixed_timestamp"], {})
        _assert_finite_json(canonical, "position sizer report")
        sized.append(
            {
                "hypothesis_id": card["hypothesis_id"],
                "ticker": card.get("ticker"),
                "entry": entry["entry"],
                "stop": entry["stop"],
                "shares": canonical.get("final_recommended_shares"),
                "position_value": canonical.get("final_position_value"),
                "risk_dollars": canonical.get("final_risk_dollars"),
                "constraints_applied": canonical.get("constraints_applied"),
            }
        )
    if any(row["shares"] is None or row["position_value"] is None for row in sized):
        raise ReplayError("position sizer report is missing shares or position value")
    # Defense in depth: re-verify the sizer's cap instead of trusting its
    # output. An absent max_position_pct means the sizer applies no cap, so
    # this check falls back to 100% of account (no leverage).
    max_position_value = params["account_size"] * params.get("max_position_pct", 100.0) / 100.0
    for row in sized:
        if row["position_value"] > max_position_value + 1e-9:
            raise ReplayError(
                f"sized hypothesis {row['hypothesis_id']} breaches the max position cap"
            )
    payload = {
        "schema_version": 1,
        "as_of": _multi_asset_fixed_date(spec),
        "account": {
            "account_size": params["account_size"],
            "risk_pct": params["risk_pct"],
            "max_position_pct": params.get("max_position_pct"),
        },
        "sized": sized,
    }
    _validate_multi_asset_contract(payload, "sized_hypotheses")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["sized_hypotheses"]["files"]["canonical"]), payload)
    return artifacts


def _multi_register(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"hypothesis_cards", "sized_hypotheses"}:
        raise ReplayError(
            f"multi-asset registration received unexpected artifacts: {sorted(consumed)}"
        )
    decision = _validate_multi_asset_contract(
        load_yaml(inputs["register_decision"]), "register_decision"
    )
    fixed_date = _multi_asset_fixed_date(spec)
    cards_path = Path(consumed["hypothesis_cards"]["files"]["canonical"])
    cards_doc = _validate_multi_asset_contract(
        _load_json(cards_path, "hypothesis cards handoff"), "hypothesis_cards"
    )
    # The schema cannot express cross-array uniqueness, so the union of
    # actionable and excluded ids is checked here explicitly.
    _require_unique_ids(
        [card["hypothesis_id"] for card in cards_doc["hypotheses"]]
        + [card["hypothesis_id"] for card in cards_doc.get("excluded", [])],
        "hypothesis cards handoff",
    )
    sized_path = Path(consumed["sized_hypotheses"]["files"]["canonical"])
    sized_doc = _validate_multi_asset_contract(
        _load_json(sized_path, "sized hypotheses handoff"), "sized_hypotheses"
    )
    actionable_ids = [card["hypothesis_id"] for card in cards_doc["hypotheses"]]
    excluded_ids = [card["hypothesis_id"] for card in cards_doc.get("excluded", [])]
    idea = decision["idea"]
    entry_ready = decision["entry_ready"]
    rejected = decision["rejected"]
    # Duplicates are otherwise caught only incidentally by the sorted-list
    # comparisons below; check explicitly for a clear failure message.
    _require_unique_ids(idea, "register_decision.idea")
    _require_unique_ids(entry_ready, "register_decision.entry_ready")
    _require_unique_ids(rejected, "register_decision.rejected")
    if set(idea) & set(entry_ready):
        raise ReplayError("register_decision.idea and register_decision.entry_ready overlap")
    if sorted(idea + entry_ready) != sorted(actionable_ids) or len(
        set(idea) | set(entry_ready)
    ) != len(actionable_ids):
        raise ReplayError("register decision must partition exactly the actionable hypotheses")
    if sorted(rejected) != sorted(excluded_ids):
        raise ReplayError("register decision rejected must match the gate-excluded hypotheses")
    sized_ids = {row["hypothesis_id"] for row in sized_doc["sized"]}
    if set(actionable_ids) != sized_ids:
        raise ReplayError("sized hypotheses must cover exactly the actionable hypothesis cards")
    card_by_id = {card["hypothesis_id"]: card for card in cards_doc["hypotheses"]}

    scripts_dir = repo_root / "skills" / "trader-memory-core" / "scripts"
    thesis_ingest = _repo_module(repo_root, "thesis_ingest", scripts_dir)
    thesis_store = _repo_module(repo_root, "thesis_store", scripts_dir)
    records = []
    for hypothesis_id in idea + entry_ready:
        card = card_by_id[hypothesis_id]
        if not card.get("ticker"):
            raise ReplayError(f"hypothesis {hypothesis_id} has no ticker for thesis registration")
        records.append(
            {
                "ticker": card["ticker"],
                "thesis_statement": card.get("thesis") or card.get("title") or hypothesis_id,
                "thesis_type": decision["thesis_type"],
                "as_of": fixed_date,
            }
        )
    state_dir = work / "multi-asset-state"
    state_dir.mkdir(parents=True)
    ingest_path = work / "manual_theses.json"
    _write_json(ingest_path, records)
    thesis_ids = thesis_ingest.ingest("manual", str(ingest_path), str(state_dir))
    if len(thesis_ids) != len(records):
        raise ReplayError("native thesis ingest did not register every expected thesis")
    theses = [thesis_store.get(state_dir, thesis_id) for thesis_id in thesis_ids]
    if sorted(row["ticker"] for row in theses) != sorted(
        card_by_id[hypothesis_id]["ticker"] for hypothesis_id in idea + entry_ready
    ):
        raise ReplayError("native thesis ingest did not register the expected tickers")

    linked_specs = [
        (
            "trade-hypothesis-ideator",
            _kanchi_artifact_link(consumed, "hypothesis_cards", "canonical", stage),
        ),
        ("position-sizer", _kanchi_artifact_link(consumed, "sized_hypotheses", "canonical", stage)),
    ]
    for thesis in theses:
        for skill, token in linked_specs:
            thesis_store.link_report(state_dir, thesis["thesis_id"], skill, token, fixed_date)

    entries = []
    registered_tickers = [
        card_by_id[hypothesis_id]["ticker"] for hypothesis_id in idea + entry_ready
    ]
    if len(set(registered_tickers)) != len(registered_tickers):
        raise ReplayError("registered hypotheses must have unique tickers")
    thesis_id_by_ticker = {row["ticker"]: row["thesis_id"] for row in theses}
    for hypothesis_id in actionable_ids:
        card = card_by_id[hypothesis_id]
        status = "ENTRY_READY" if hypothesis_id in set(entry_ready) else "IDEA"
        reloaded = thesis_store.get(state_dir, thesis_id_by_ticker[card["ticker"]])
        if reloaded["status"] != "IDEA":
            raise ReplayError("multi-asset registration must never leave IDEA status")
        if card.get("asset_class") == "forex" and not card.get("research_only"):
            raise ReplayError(f"forex hypothesis {hypothesis_id} must carry research_only=true")
        linked = reloaded.get("linked_reports") or []
        entries.append(
            {
                "hypothesis_id": hypothesis_id,
                "ticker": card.get("ticker"),
                "status": status,
                "thesis_id": None,
                "research_only": bool(card.get("research_only", False)),
                "linked_reports": linked,
            }
        )
    for card in cards_doc.get("excluded", []):
        hypothesis_id = card["hypothesis_id"]
        if card.get("asset_class") == "forex" and not card.get("research_only"):
            raise ReplayError(f"forex hypothesis {hypothesis_id} must carry research_only=true")
        entries.append(
            {
                "hypothesis_id": hypothesis_id,
                "ticker": card.get("ticker"),
                "status": "rejected",
                "thesis_id": None,
                "research_only": bool(card.get("research_only", False)),
                "linked_reports": [],
            }
        )
    entries.sort(key=lambda row: row["hypothesis_id"])
    record = {
        "schema_version": 1,
        "workflow_id": "multi-asset-opportunity-daily",
        "recorded_at": spec["fixed_timestamp"],
        "entries": entries,
        "provenance": {
            "execution_mode": "composite",
            "components": ["manual_contract", "native_api"],
            "native_component": "trader-memory-core.thesis_ingest + thesis_store.link_report",
            "source_date": fixed_date,
            "limitation": (
                "Human register decision is a fixture; no broker fill exists, so every "
                "thesis stays IDEA and no order is placed. ENTRY_READY is a recorded "
                "human decision, not a thesis transition. Thesis IDs are intentionally "
                "nulled because the state is disposable and never published."
            ),
        },
    }
    _validate_multi_asset_contract(record, "opportunity_journal_entries")
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["opportunity_journal_entries"]["files"]["canonical"]), record)
    return artifacts


def _strategy_research_tickets(report_dir: Path) -> list[dict[str, Any]]:
    paths = sorted((report_dir / "tickets").glob("*/*.yaml"))
    tickets = [load_yaml(path) for path in paths]
    if len({ticket.get("id") for ticket in tickets}) != len(tickets):
        raise ReplayError("strategy research generated duplicate ticket IDs")
    return tickets


def _strategy_research_detect(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
    *,
    final: bool,
) -> dict[str, dict[str, Any]]:
    expected = {"edge_hints"} if final else set()
    if set(consumed) != expected:
        raise ReplayError(f"strategy research detection requires {sorted(expected)}")
    as_of = spec["fixed_timestamp"][:10]
    report_dir = work / "reports"
    command = [
        sys.executable,
        str(repo_root / "skills/edge-candidate-agent/scripts/auto_detect_candidates.py"),
        "--ohlcv",
        str(inputs["ohlcv"]),
        "--as-of",
        as_of,
        "--output-dir",
        str(report_dir),
    ]
    if final:
        command.extend(["--hints", consumed["edge_hints"]["files"]["canonical"]])
    _run_cli(command, repo_root)
    tickets = _strategy_research_tickets(report_dir)
    artifacts = _artifact_paths(stage, step["output_files"])
    if final:
        if not tickets:
            raise ReplayError("strategy research replay needs a final ticket for evaluation")
        payload = {
            "as_of": as_of,
            "ohlcv_sha256": _file_sha256(inputs["ohlcv"]),
            "hints_sha256": _file_sha256(Path(consumed["edge_hints"]["files"]["canonical"])),
            "tickets": tickets,
        }
        _write_json(Path(artifacts["final_research_tickets"]["files"]["canonical"]), payload)
    else:
        summary = _load_json(report_dir / "market_summary.json", "initial market summary")
        anomalies = _load_json(report_dir / "anomalies.json", "initial anomalies")
        _write_json(Path(artifacts["initial_market_summary"]["files"]["canonical"]), summary)
        _write_json(Path(artifacts["initial_anomalies"]["files"]["canonical"]), anomalies)
        _write_json(Path(artifacts["initial_tickets"]["files"]["canonical"]), tickets)
    return artifacts


def _strategy_research_detect_initial(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    return _strategy_research_detect(
        repo_root, spec, step, inputs, consumed, work, stage, final=False
    )


def _strategy_research_hints(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    del inputs
    if set(consumed) != {"initial_market_summary", "initial_anomalies"}:
        raise ReplayError("strategy research hints require initial summary and anomalies")
    output = work / "hints.yaml"
    _run_cli(
        [
            sys.executable,
            str(repo_root / "skills/edge-hint-extractor/scripts/build_hints.py"),
            "--market-summary",
            consumed["initial_market_summary"]["files"]["canonical"],
            "--anomalies",
            consumed["initial_anomalies"]["files"]["canonical"],
            "--as-of",
            spec["fixed_timestamp"][:10],
            "--output",
            str(output),
        ],
        repo_root,
    )
    hints = load_yaml(output)
    if hints.get("as_of") != spec["fixed_timestamp"][:10]:
        raise ReplayError("strategy research hints as_of differs from detector as_of")
    hints.pop("generated_at_utc", None)
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_yaml(Path(artifacts["edge_hints"]["files"]["canonical"]), hints)
    return artifacts


def _strategy_research_detect_final(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    return _strategy_research_detect(
        repo_root, spec, step, inputs, consumed, work, stage, final=True
    )


def _strategy_research_hold(
    repo_root: Path,
    spec: Mapping[str, Any],
    step: Mapping[str, Any],
    inputs: Mapping[str, Path],
    consumed: Mapping[str, dict[str, Any]],
    work: Path,
    stage: Path,
) -> dict[str, dict[str, Any]]:
    if set(consumed) != {"final_research_tickets"}:
        raise ReplayError("strategy research evaluation requires final tickets")
    tickets_path = Path(consumed["final_research_tickets"]["files"]["canonical"])
    final = _load_json(tickets_path, "final research tickets")
    metrics = _require_mapping_keys(
        _load_json(inputs["backtest_metrics"], "strategy research backtest metrics"),
        label="strategy research backtest metrics",
        required={
            "ticket_id",
            "as_of",
            "universe",
            "period",
            "cost_assumptions",
            "source",
            "total_trades",
            "win_rate",
            "avg_win_pct",
            "avg_loss_pct",
            "max_drawdown_pct",
            "years_tested",
            "num_parameters",
            "slippage_tested",
        },
    )
    tickets = {ticket["id"]: ticket for ticket in final["tickets"]}
    ticket_id = _require_non_empty_string(metrics["ticket_id"], "backtest ticket_id")
    for field in ("universe", "period", "source"):
        _require_non_empty_string(metrics[field], f"backtest {field}")
    if not isinstance(metrics["cost_assumptions"], dict):
        raise ReplayError("backtest cost_assumptions must be a mapping")
    if metrics["slippage_tested"] is not True and metrics["slippage_tested"] is not False:
        raise ReplayError("backtest slippage_tested must be boolean")
    reasons = []
    ticket = tickets.get(ticket_id)
    if ticket is None:
        reasons.append("ticket ID is absent from final research tickets")
    if metrics["as_of"] != final["as_of"]:
        reasons.append("metrics as-of date differs from final detection")
    if ticket is not None:
        if ticket.get("observation", {}).get("symbol") not in metrics["universe"]:
            reasons.append("metrics universe does not identify the selected ticket symbol")
        test_spec = ticket.get("test_spec") or {}
        if metrics["period"] != test_spec.get("period"):
            reasons.append("metrics period differs from selected ticket test period")
        if metrics["cost_assumptions"] != test_spec.get("cost_model"):
            reasons.append("metrics costs differ from selected ticket cost model")
    if not metrics["slippage_tested"]:
        reasons.append("slippage was not separately tested")
    reasons.append("independent look-ahead, survivorship, and out-of-sample reviews are absent")
    reasons.append("fictional aggregate metrics are not separate backtest provenance")
    result = {
        "status": "HOLD",
        "evaluation_invoked": False,
        "reasons": reasons,
        "provenance": {
            "execution": "manual_contract_only",
            "ticket_id": ticket_id,
            "as_of": final["as_of"],
            "universe": metrics["universe"],
            "period": metrics["period"],
            "cost_assumptions": metrics["cost_assumptions"],
            "source": metrics["source"],
            "final_tickets_sha256": _file_sha256(tickets_path),
            "limitation": "No backtest or scoring CLI was executed; human review is required.",
        },
    }
    artifacts = _artifact_paths(stage, step["output_files"])
    _write_json(Path(artifacts["backtest_quality_assessment"]["files"]["canonical"]), result)
    return artifacts


EXECUTORS: dict[str, ExecutorRegistration] = {
    "strategy_research_detect_initial": ExecutorRegistration(
        "native_cli", _strategy_research_detect_initial
    ),
    "strategy_research_hints": ExecutorRegistration("native_cli", _strategy_research_hints),
    "strategy_research_detect_final": ExecutorRegistration(
        "native_cli", _strategy_research_detect_final
    ),
    "strategy_research_hold": ExecutorRegistration("manual_contract", _strategy_research_hold),
    "ep_circuit": ExecutorRegistration("native_cli", _ep_circuit),
    "ep_screen": ExecutorRegistration("manual_contract", _ep_screen),
    "ep_analyze": ExecutorRegistration("native_cli", _ep_analyze),
    "ep_validate": ExecutorRegistration("manual_contract", _ep_validate),
    "ep_size": ExecutorRegistration("native_cli", _ep_size),
    "ep_plan": ExecutorRegistration("manual_contract", _ep_plan),
    "ep_journal": ExecutorRegistration("composite", _ep_journal, ("manual_contract", "native_api")),
    "ep_discipline": ExecutorRegistration(
        "composite", _ep_discipline, ("manual_contract", "native_cli")
    ),
    "shapiro_manual": ExecutorRegistration("manual_contract", _shapiro_manual),
    "shapiro_gate": ExecutorRegistration("native_cli", _shapiro_gate),
    "shapiro_size": ExecutorRegistration("native_cli", _shapiro_size),
    "shapiro_journal": ExecutorRegistration(
        "composite", _shapiro_journal, ("manual_contract", "native_api")
    ),
    "stockbee_fluency_ingest": ExecutorRegistration("native_cli", _stockbee_ingest),
    "stockbee_fluency_update": ExecutorRegistration("native_cli", _stockbee_update),
    "stockbee_fluency_summarize": ExecutorRegistration("native_cli", _stockbee_summarize),
    "manual_lessons_log": ExecutorRegistration("manual_contract", _manual_lessons),
    "twenty_pct_scan": ExecutorRegistration("native_cli", _twenty_pct_scan),
    "twenty_pct_enrich": ExecutorRegistration("native_cli", _twenty_pct_enrich),
    "twenty_pct_update_outcomes": ExecutorRegistration("native_cli", _twenty_pct_update_outcomes),
    "twenty_pct_summarize": ExecutorRegistration("native_cli", _twenty_pct_summarize),
    "manual_twenty_pct_lessons": ExecutorRegistration(
        "manual_contract", _manual_twenty_pct_lessons
    ),
    "trade_memory_close": ExecutorRegistration("native_cli", _trade_memory_close),
    "trade_memory_postmortem": ExecutorRegistration(
        "composite",
        _trade_memory_postmortem,
        ("native_api", "manual_contract"),
    ),
    "trade_memory_coach": ExecutorRegistration(
        "composite",
        _trade_memory_coach,
        ("native_cli", "manual_contract"),
    ),
    "trade_memory_backtest": ExecutorRegistration("native_cli", _trade_memory_backtest),
    "trade_memory_lessons": ExecutorRegistration(
        "composite",
        _trade_memory_lessons,
        ("native_api", "manual_contract"),
    ),
    "market_regime_breadth": ExecutorRegistration("native_api", _market_regime_breadth),
    "market_regime_uptrend": ExecutorRegistration("native_api", _market_regime_uptrend),
    "market_regime_top_risk": ExecutorRegistration("native_api", _market_regime_top_risk),
    "market_regime_exposure": ExecutorRegistration("native_cli", _market_regime_exposure),
    "core_portfolio_snapshot": ExecutorRegistration("manual_contract", _core_portfolio_snapshot),
    "core_portfolio_allocation": ExecutorRegistration(
        "manual_contract", _core_portfolio_allocation
    ),
    "core_portfolio_dividend": ExecutorRegistration("native_api", _core_portfolio_dividend),
    "core_portfolio_rebalance": ExecutorRegistration("manual_contract", _core_portfolio_rebalance),
    "core_portfolio_journal": ExecutorRegistration("manual_contract", _core_portfolio_journal),
    "monthly_aggregate": ExecutorRegistration("manual_contract", _monthly_aggregate),
    "monthly_postmortem": ExecutorRegistration(
        "composite",
        _monthly_postmortem,
        ("native_api", "manual_contract"),
    ),
    "monthly_coach": ExecutorRegistration(
        "composite",
        _monthly_coach,
        ("native_cli", "manual_contract"),
    ),
    "monthly_backtest": ExecutorRegistration("native_cli", _monthly_backtest),
    "monthly_skill_review": ExecutorRegistration("native_cli", _monthly_skill_review),
    "monthly_decision_log": ExecutorRegistration("manual_contract", _monthly_decision_log),
    "swing_theme": ExecutorRegistration("manual_contract", _swing_theme),
    "swing_validate_setups": ExecutorRegistration("manual_contract", _swing_validate_setups),
    "swing_position_size": ExecutorRegistration("native_cli", _swing_position_size),
    "swing_build_plan": ExecutorRegistration("manual_contract", _swing_build_plan),
    "swing_journal": ExecutorRegistration("manual_contract", _swing_journal),
    "swing_discipline": ExecutorRegistration("native_cli", _swing_discipline),
    "swing_circuit_breaker": ExecutorRegistration("native_cli", _swing_circuit_breaker),
    "swing_vcp_screen": ExecutorRegistration("manual_contract", _swing_vcp_screen),
    "swing_momentum_burst": ExecutorRegistration("manual_contract", _swing_momentum_burst),
    "swing_exhaustion_hammer": ExecutorRegistration("manual_contract", _swing_exhaustion_hammer),
    "swing_canslim": ExecutorRegistration("manual_contract", _swing_canslim),
    "kanchi_high_yield_screen": ExecutorRegistration("manual_contract", _kanchi_high_yield_screen),
    "kanchi_pullback_screen": ExecutorRegistration("manual_contract", _kanchi_pullback_screen),
    "kanchi_underwrite": ExecutorRegistration(
        "composite",
        _kanchi_underwrite,
        ("native_cli", "native_api", "manual_contract"),
    ),
    "kanchi_tax_advice": ExecutorRegistration("native_cli", _kanchi_tax_advice),
    "kanchi_review_queue": ExecutorRegistration("native_cli", _kanchi_review_queue),
    "kanchi_register_thesis": ExecutorRegistration(
        "composite",
        _kanchi_register_thesis,
        ("manual_contract", "native_api"),
    ),
    "multi_macro_regime": ExecutorRegistration("native_api", _multi_macro_regime),
    "multi_theme": ExecutorRegistration("manual_contract", _multi_theme),
    "multi_news_brief": ExecutorRegistration("manual_contract", _multi_news_brief),
    "multi_hypotheses": ExecutorRegistration(
        "composite",
        _multi_hypotheses,
        ("native_cli", "manual_contract"),
    ),
    "multi_position_size": ExecutorRegistration("native_cli", _multi_position_size),
    "multi_register": ExecutorRegistration(
        "composite",
        _multi_register,
        ("manual_contract", "native_api"),
    ),
}


def _prompt_text(workflow: Mapping[str, Any], variant: str) -> str:
    if variant == "required-only":
        optional_text = "Skip every optional step."
    elif workflow["id"] == "stockbee-20pct-study-daily":
        optional_text = (
            "Run the optional human-approved lessons step after reviewing the 20% mover "
            "cohort evidence."
        )
    elif workflow["id"] == "trade-memory-loop":
        optional_text = (
            "Run the optional native coaching and fixture-metric evaluation steps before "
            "recording the separately human-approved lesson."
        )
    elif workflow["id"] == "market-regime-daily":
        optional_text = (
            "Include the optional fixture-backed market-top score before running the "
            "native exposure posture CLI."
        )
    elif workflow["id"] == "core-portfolio-weekly":
        optional_text = (
            "Include the optional native dividend-rule review while keeping every "
            "rebalance action proposed, manual, and not submitted."
        )
    elif workflow["id"] == "stockbee-ep-daily":
        optional_text = "Include the fictional earnings and momentum handoffs and reviewed written plan. Keep delayed EP candidates on watch; never submit orders."
    elif workflow["id"] == "kanchi-dividend-weekly":
        optional_text = (
            "Include the optional screeners, tax/account-location advice, and "
            "existing-holding review while keeping every buy proposal manual and "
            "never activating a thesis."
        )
    elif workflow["id"] == "multi-asset-opportunity-daily":
        optional_text = (
            "Include the optional news/catalyst brief while keeping every hypothesis "
            "card manual-review-gated and never wiring forex output to a broker."
        )
    else:
        optional_text = (
            "Run the optional human-approved lessons step after reviewing the cohort evidence."
        )
    return (
        f"# Prompt: {variant} {workflow['id']} replay\n\n"
        "Replay this workflow with the bundled fictional input data. "
        "This is not investment advice and must not submit orders or call live APIs.\n\n"
        f"{optional_text}\n"
    )


def _write_manifest(
    stage: Path,
    workflow: Mapping[str, Any],
    variant: str,
    report: Mapping[str, Any],
    artifacts: Mapping[str, dict[str, Any]],
) -> None:
    artifact_contract = {item["id"]: item for item in workflow["artifacts"]}
    step_contract = {int(item["step"]): item for item in workflow["steps"]}
    entries = []
    for artifact_id, bundle in artifacts.items():
        contract = artifact_contract[artifact_id]
        step_number = int(contract["produced_by_step"])
        entry = {
            "step": step_number,
            "artifact_id": artifact_id,
            "skill": step_contract[step_number]["skill"],
            "execution_mode": next(
                item["executor_mode"] for item in report["steps"] if item["step"] == step_number
            ),
            "files": {
                role: Path(path).resolve().relative_to(stage.resolve()).as_posix()
                for role, path in bundle["files"].items()
            },
        }
        report_step = next(item for item in report["steps"] if item["step"] == step_number)
        if report_step.get("executor_components"):
            entry["executor_components"] = report_step["executor_components"]
        entries.append(entry)
    entries.sort(key=lambda item: (item["step"], item["artifact_id"]))
    completed_steps = [int(item["step"]) for item in report["steps"]]
    completed = set(completed_steps)
    halted_after = completed_steps[-1] if report["status"] == "halted" else None
    required_steps_not_executed = [
        {
            "step": int(step["step"]),
            "skill": step["skill"],
            "reason": (
                f"halted after step {halted_after}" if halted_after is not None else "not executed"
            ),
        }
        for step in workflow["steps"]
        if not step.get("optional") and int(step["step"]) not in completed
    ]
    skipped = [
        {
            "step": int(step["step"]),
            "skill": step["skill"],
            "reason": "required-only executable replay",
        }
        for step in workflow["steps"]
        if step.get("optional") and variant == "required-only"
    ]
    payload = {
        "workflow_id": workflow["id"],
        "sample_type": variant,
        "status": report["status"],
        "completed_steps": completed_steps,
        "required_steps_not_executed": required_steps_not_executed,
        "illustrative": True,
        "generated_by": "scripts/workflow_replay.py generate",
        "prompt": "prompt.md",
        "network_policy": report["network_policy"],
        "optional_steps_skipped": skipped,
        "artifacts": entries,
    }
    if workflow["id"] == "swing-opportunity-daily":
        payload["execution_evidence_limitations"] = [
            "When step 11 executes, the native discipline CLI consumes checklist answers synthesized from offline fixtures and plan/sizing consistency checks, not human checklist responses.",
            "No live human-approval workflow is exercised and no broker order is submitted; neither fixture GO nor NO_GO authorizes a real trade.",
            "In the bundled full-path fixture, the consistent optional written plan yields fixture GO when step 11 executes; this is not human approval."
            if variant == "full-path"
            else "In required-only replay, the optional written plan is absent, so step 11 returns NO_GO when executed.",
        ]
    if workflow["id"] == "stockbee-ep-daily":
        payload["execution_evidence_limitations"] = [
            "Native circuit breaker, EP classification and position sizing consume fictional offline inputs; live providers and news verification are not executed.",
            "Chart confirmation and execution checklist are human-approved fixtures; native trader-memory APIs persist IDEA only in disposable state, without fills or order authorization.",
            "Native discipline consumes the account history; delayed EP candidates remain non-actionable watch entries.",
            "Full path includes manual-contract earnings/momentum screens and a written plan."
            if variant == "full-path"
            else "Optional earnings/momentum screens and written plan are skipped; the absent written plan forces NO_GO.",
        ]
    if workflow["id"] == "shapiro-contrarian":
        payload["execution_evidence_limitations"] = [
            "Steps 1-3 validate human-approved fictional report contracts; no CFTC/FMP/news provider or live chart analysis is executed.",
            "Steps 4-5 execute the native contrarian gate and futures sizing CLIs on those actual handoffs.",
            "Step 6 uses native register, attach_futures_position, get and link_report APIs in disposable state. It preserves IDEA without broker fills or order authorization.",
            "Both variants execute the same six required steps because this workflow has no optional steps.",
        ]
    if workflow["id"] == "trade-memory-loop":
        payload["execution_evidence_limitations"] = [
            "Root-cause and lesson decisions are human-approved fixtures bound by SHA-256.",
            "Backtest Expert evaluates bundled aggregate metrics; it does not run a strategy backtest.",
            "Only staged temporary trader-memory state is mutated; no user state is accessed.",
        ]
    elif workflow["id"] == "market-regime-daily":
        payload["execution_evidence_limitations"] = [
            "Breadth, uptrend, and top-risk provider fetches are not executed.",
            "Individual component calculators and live API failure paths are not executed.",
            "Native scorer and JSON report APIs consume complete fictional component fixtures.",
            "INSUFFICIENT_EVIDENCE is not a literal contract for these skills; unavailable fixture components fail closed before publication.",
            "Exposure Coach runs as the native CLI against the generated artifact handoffs.",
        ]
    elif workflow["id"] == "core-portfolio-weekly":
        payload["execution_evidence"] = {
            "native_portfolio_manager_executed": False,
            "native_trader_memory_append_executed": False,
            "native_dividend_rule_api_executed": any(
                row["executor"] == "core_portfolio_dividend" for row in report["steps"]
            ),
            "broker_or_live_api_calls": False,
            "execution_authorized": False,
        }
        payload["execution_evidence_limitations"] = [
            "Holdings, target allocation, rebalance, and journal decisions are fictional manual contracts sealed to upstream artifact SHA-256 values.",
            "Allocation and projected-weight arithmetic is recomputed, but Portfolio Manager has no offline native decision API and is not claimed as executed.",
            "The optional full path calls the native Kanchi dividend rule API after joining enrichment to the step-1 snapshot identity.",
            "The journal is staged transactionally; Trader Memory Core is not mutated and no broker order is placed or authorized.",
        ]
    elif workflow["id"] == "kanchi-dividend-weekly":
        payload["execution_evidence"] = {
            "native_kanchi_verdict_api_executed": any(
                row["executor"] == "kanchi_underwrite" for row in report["steps"]
            ),
            "native_tax_planning_cli_executed": any(
                row["executor"] == "kanchi_tax_advice" for row in report["steps"]
            ),
            "native_review_queue_cli_executed": any(
                row["executor"] == "kanchi_review_queue" for row in report["steps"]
            ),
            "native_trader_memory_register_executed": any(
                row["executor"] == "kanchi_register_thesis" for row in report["steps"]
            ),
            "broker_or_live_api_calls": False,
            "execution_authorized": False,
        }
        limitations = [
            "The live kanchi_candidates producer (build_entry_signals.py) requires FMP data and is not executed; step 3 recomputes the native verdict tier from fixture evidence.",
            "stock_memo is generated by the offline build_sop_plan.py planning CLI, not the hand-written stock-note-template one-pager.",
        ]
        if any(row["executor"] == "kanchi_high_yield_screen" for row in report["steps"]):
            limitations.append(
                "Screener steps 1-2 are human-approved candidate-list fixtures; no FINVIZ or FMP screener is called."
            )
        if any(row["executor"] == "kanchi_tax_advice" for row in report["steps"]):
            limitations.append(
                "Step 4 calls the native tax-planning CLI on fictional holdings; account-location advice remains advisory."
            )
        if any(row["executor"] == "kanchi_review_queue" for row in report["steps"]):
            limitations.append(
                "Step 5 calls the native dividend review-queue CLI on fictional holdings; a WARN/REVIEW never triggers an automatic sell."
            )
        limitations.append(
            "Step 6 calls the native trader-memory-core ingest and link_report APIs on disposable temporary state; every thesis stays IDEA and no order is placed or authorized."
        )
        payload["execution_evidence_limitations"] = limitations
    elif workflow["id"] == "multi-asset-opportunity-daily":
        payload["execution_evidence"] = {
            "native_macro_regime_api_executed": any(
                row["executor"] == "multi_macro_regime" for row in report["steps"]
            ),
            "native_hypothesis_cli_executed": any(
                row["executor"] == "multi_hypotheses" for row in report["steps"]
            ),
            "native_position_sizer_cli_executed": any(
                row["executor"] == "multi_position_size" for row in report["steps"]
            ),
            "native_trader_memory_register_executed": any(
                row["executor"] == "multi_register" for row in report["steps"]
            ),
            "broker_or_live_api_calls": False,
            "execution_authorized": False,
        }
        limitations = [
            "Step 1 recomputes the native macro-regime composite, regime classification, and consistency check from fixture component results; provider fetches and calculator histories are not executed.",
            "Step 2 themes are a human-approved fixture bound to the replayed regime brief; no FINVIZ fetch is executed.",
            "Step 4 runs the native trade-hypothesis-ideator CLI on a fixture bundle bound by SHA-256 to the replayed upstream artifacts; hypothesis accept/reject is a human gate decision.",
            "Step 5 sizes actionable cards with the native position-sizer CLI on fictional entries, stops, and risk; portfolio caps are fixture-enforced.",
            "Step 6 calls the native trader-memory-core ingest and link_report APIs on disposable temporary state; every thesis stays IDEA and no order is placed or authorized. Forex output is research-only and never wired to a broker.",
        ]
        payload["execution_evidence_limitations"] = limitations
    (stage / "manifest.yaml").write_text(
        yaml.safe_dump(payload, sort_keys=False, allow_unicode=True), encoding="utf-8", newline="\n"
    )
    (stage / "prompt.md").write_text(
        _prompt_text(workflow, variant), encoding="utf-8", newline="\n"
    )


def _cleanup_backup(path: Path) -> None:
    shutil.rmtree(path)


def _publish_tree(stage: Path, destination: Path) -> None:
    destination = destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Defense in depth mirroring _publish_trees_transactionally: today
    # _validate_runtime_output rejects a non-directory output_dir before
    # execution, and execute_replay is the only call site, so this branch is
    # unreachable in practice. It guards against a file destination if that
    # invariant is ever relaxed or this function is called from elsewhere.
    if destination.exists() and not destination.is_dir():
        raise ReplayError(f"publish destination must be a directory: {destination}")
    candidate = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.candidate-", dir=destination.parent)
    )
    backup_root = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.backup-", dir=destination.parent)
    )
    backup = backup_root / "previous"
    committed = False
    try:
        shutil.copytree(stage, candidate, dirs_exist_ok=True)
        had_destination = destination.exists()
        if had_destination:
            os.replace(destination, backup)
        try:
            os.replace(candidate, destination)
        except Exception:
            if had_destination and backup.exists() and not destination.exists():
                os.replace(backup, destination)
            raise
        committed = True
    finally:
        if candidate.exists():
            shutil.rmtree(candidate)
        if committed:
            try:
                _cleanup_backup(backup_root)
            except OSError:
                # Publication already committed. Retain the uniquely named
                # backup for manual cleanup rather than report a false failure.
                pass
        elif backup_root.exists() and not backup.exists():
            shutil.rmtree(backup_root)


def _publish_trees_transactionally(staged_trees: list[tuple[Path, Path]]) -> None:
    """Publish multiple generated trees as one rollback-capable transaction."""
    destinations = [destination.resolve() for _stage, destination in staged_trees]
    for index, destination in enumerate(destinations):
        for other in destinations[index + 1 :]:
            if _paths_overlap(destination, other):
                raise ReplayError(f"transaction destinations overlap: {destination} and {other}")

    prepared: list[dict[str, Any]] = []
    succeeded = False
    try:
        for stage, raw_destination in staged_trees:
            destination = raw_destination.resolve()
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists() and not destination.is_dir():
                raise ReplayError(f"transaction destination must be a directory: {destination}")
            candidate = Path(
                tempfile.mkdtemp(prefix=f".{destination.name}.candidate-", dir=destination.parent)
            )
            backup_root = Path(
                tempfile.mkdtemp(prefix=f".{destination.name}.backup-", dir=destination.parent)
            )
            entry = {
                "destination": destination,
                "candidate": candidate,
                "backup_root": backup_root,
                "backup": backup_root / "previous",
                "backup_moved": False,
                "candidate_committed": False,
            }
            prepared.append(entry)
            shutil.copytree(stage, candidate, dirs_exist_ok=True)

        for entry in prepared:
            destination = entry["destination"]
            if destination.exists():
                os.replace(destination, entry["backup"])
                entry["backup_moved"] = True
            os.replace(entry["candidate"], destination)
            entry["candidate_committed"] = True
        succeeded = True
    except Exception as exc:
        rollback_errors: list[str] = []
        for entry in reversed(prepared):
            destination = entry["destination"]
            try:
                if entry["candidate_committed"] and destination.exists():
                    shutil.rmtree(destination)
                if entry["backup_moved"] and entry["backup"].exists():
                    os.replace(entry["backup"], destination)
            except Exception as rollback_exc:  # pragma: no cover - catastrophic filesystem path
                rollback_errors.append(f"{destination}: {rollback_exc}")
        if rollback_errors:
            raise ReplayError(
                f"golden publication failed ({exc}); rollback also failed: "
                + "; ".join(rollback_errors)
            ) from exc
        raise
    finally:
        for entry in prepared:
            candidate = entry["candidate"]
            backup_root = entry["backup_root"]
            backup = entry["backup"]
            if candidate.exists():
                shutil.rmtree(candidate)
            if succeeded:
                try:
                    _cleanup_backup(backup_root)
                except OSError:
                    pass
            elif backup_root.exists() and not backup.exists():
                shutil.rmtree(backup_root)


def execute_replay(
    repo_root: Path,
    spec_path: Path,
    variant: str,
    output_dir: Path,
    *,
    input_overrides: Mapping[str, Path] | None = None,
    before_step: Callable[[int, dict[str, dict[str, Any]]], None] | None = None,
    after_step: Callable[[int, dict[str, dict[str, Any]]], None] | None = None,
) -> dict[str, Any]:
    validation = validate_spec(repo_root, spec_path)
    if variant not in VARIANTS:
        raise ReplayError(f"unknown replay variant: {variant}")
    spec = load_yaml(spec_path)
    workflow = load_yaml(repo_root / "workflows" / f"{spec['workflow_id']}.yaml")
    workflow_steps = {int(item["step"]): item for item in workflow["steps"]}
    spec_steps = {int(item["step"]): item for item in spec["steps"]}
    provenance_requirements = {
        artifact_id: number
        for number, step in spec_steps.items()
        for artifact_id in step.get("required_provenance", [])
    }
    inputs = dict(validation["inputs"])
    for name, path in (input_overrides or {}).items():
        if name not in inputs:
            raise ReplayError(f"unknown input override: {name}")
        inputs[name] = Path(path).resolve()
    _validate_runtime_output(repo_root, spec_path, spec, inputs, output_dir)

    completed_steps: list[int] = []
    artifacts: dict[str, dict[str, Any]] = {}
    sealed_artifact_digests: dict[str, str] = {}
    step_reports: list[dict[str, Any]] = []
    status = "completed"
    with tempfile.TemporaryDirectory(prefix="workflow-replay-") as temp_name:
        temp = Path(temp_name)
        stage = temp / "published"
        stage.mkdir()
        try:
            for number in spec["variants"][variant]["enabled_steps"]:
                workflow_step = workflow_steps[number]
                replay_step = spec_steps[number]
                if before_step:
                    before_step(number, artifacts)
                _validate_artifact_files(stage, artifacts, "artifact store")
                consumed: dict[str, dict[str, Any]] = {}
                for artifact_id in workflow_step.get("consumes") or []:
                    if artifact_id in artifacts:
                        consumed[artifact_id] = artifacts[artifact_id]
                        continue
                    contract = next(
                        item for item in workflow["artifacts"] if item["id"] == artifact_id
                    )
                    producer = workflow_steps[int(contract["produced_by_step"])]
                    if not producer.get("optional"):
                        raise ReplayError(
                            f"step {number} missing required consumed artifact {artifact_id!r}",
                            completed_steps,
                        )
                _validate_artifact_provenance(
                    consumed, provenance_requirements, f"step {number} consumed"
                )
                executor_name = replay_step["executor"]
                registration = EXECUTORS.get(executor_name)
                if registration is None:
                    raise ReplayError(f"unknown executor {executor_name!r}", completed_steps)
                step_work = temp / "work" / f"step-{number}"
                step_work.mkdir(parents=True)
                produced = registration.run(
                    repo_root,
                    spec,
                    replay_step,
                    inputs,
                    consumed,
                    step_work,
                    stage,
                )
                if set(produced) != set(workflow_step.get("produces") or []):
                    raise ReplayError(
                        f"step {number} executor produced {sorted(produced)}, expected "
                        f"{sorted(workflow_step.get('produces') or [])}",
                        completed_steps,
                    )
                candidate_artifacts = dict(artifacts)
                candidate_artifacts.update(produced)
                _validate_artifact_files(stage, candidate_artifacts, f"step {number} output")
                _validate_artifact_provenance(
                    produced, provenance_requirements, f"step {number} output"
                )
                produced_digests = _artifact_file_digests(produced)
                duplicate_seals = set(produced_digests) & set(sealed_artifact_digests)
                if duplicate_seals:
                    raise ReplayError(
                        f"step {number} replaced sealed artifacts: {sorted(duplicate_seals)}",
                        completed_steps,
                    )
                sealed_artifact_digests.update(produced_digests)
                artifacts = candidate_artifacts
                completed_steps.append(number)
                step_report = {
                    "step": number,
                    "skill": workflow_step["skill"],
                    "executor": executor_name,
                    "executor_mode": registration.mode,
                    "gate_policy": replay_step["gate_policy"],
                    "consumed": sorted(consumed),
                    "produced": sorted(produced),
                }
                if registration.components:
                    step_report["executor_components"] = list(registration.components)
                step_reports.append(step_report)
                if after_step:
                    after_step(number, artifacts)
                if replay_step["gate_policy"] == "halt":
                    status = "halted"
                    break

            _validate_artifact_files(stage, artifacts, "final artifact store")
            _validate_artifact_provenance(
                artifacts, provenance_requirements, "final artifact store"
            )
            final_digests = _artifact_file_digests(artifacts)
            changed_artifacts = sorted(
                artifact_id
                for artifact_id in set(final_digests) | set(sealed_artifact_digests)
                if final_digests.get(artifact_id) != sealed_artifact_digests.get(artifact_id)
            )
            if changed_artifacts:
                raise ReplayError(
                    f"final artifact integrity mismatch: {changed_artifacts}", completed_steps
                )

            report = {
                "schema_version": 1,
                "workflow_id": spec["workflow_id"],
                "variant": variant,
                "status": status,
                "network_policy": "offline-input-required",
                "steps": step_reports,
                "artifact_ids": sorted(artifacts),
            }
            _write_manifest(stage, workflow, variant, report, artifacts)
            _publish_tree(stage, output_dir)
            return report
        except ReplayError as exc:
            if not exc.completed_steps:
                exc.completed_steps = list(completed_steps)
            raise
        except Exception as exc:
            raise ReplayError(f"replay failed: {exc}", completed_steps) from exc


def compare_trees(actual: Path, expected: Path) -> list[str]:
    actual_files = {
        path.relative_to(actual).as_posix(): path for path in actual.rglob("*") if path.is_file()
    }
    expected_files = {
        path.relative_to(expected).as_posix(): path
        for path in expected.rglob("*")
        if path.is_file()
    }
    differences = []
    for name in sorted(set(actual_files) - set(expected_files)):
        differences.append(f"unexpected generated file: {name}")
    for name in sorted(set(expected_files) - set(actual_files)):
        differences.append(f"missing generated file: {name}")
    for name in sorted(set(actual_files) & set(expected_files)):
        if actual_files[name].read_bytes() != expected_files[name].read_bytes():
            differences.append(f"content drift: {name}")
    return differences


def _covered_specs(coverage_path: Path) -> list[tuple[str, Path, Mapping[str, Any]]]:
    coverage = load_yaml(coverage_path)
    result = []
    for workflow_id, entry in sorted((coverage.get("covered") or {}).items()):
        result.append((workflow_id, (coverage_path.parent / entry["spec"]).resolve(), entry))
    return result


def check_goldens(repo_root: Path, coverage_path: Path, report_path: Path | None) -> list[str]:
    rows = []
    all_differences: list[str] = []
    coverage_counts = {
        "covered": 0,
        "total": len(list((repo_root / "workflows").glob("*.yaml"))),
    }
    try:
        coverage_summary = validate_coverage(repo_root, coverage_path)
        coverage_counts["covered"] = len(coverage_summary["covered"])
        covered_specs = _covered_specs(coverage_path)
        with tempfile.TemporaryDirectory(prefix="workflow-replay-check-") as temp_name:
            temp = Path(temp_name)
            for workflow_id, spec_path, entry in covered_specs:
                spec = load_yaml(spec_path)
                for variant in entry["variants"]:
                    generated = temp / workflow_id / variant
                    try:
                        execution = execute_replay(repo_root, spec_path, variant, generated)
                        golden = (
                            spec_path.parent / spec["variants"][variant]["golden_dir"]
                        ).resolve()
                        differences = compare_trees(generated, golden)
                        rows.append(
                            {
                                "workflow_id": workflow_id,
                                "variant": variant,
                                "status": "pass" if not differences else "drift",
                                "execution": execution,
                                "differences": differences,
                            }
                        )
                        all_differences.extend(
                            f"{workflow_id}/{variant}: {difference}" for difference in differences
                        )
                    except Exception as exc:
                        difference = f"{workflow_id}/{variant}: execution error: {exc}"
                        all_differences.append(difference)
                        rows.append(
                            {
                                "workflow_id": workflow_id,
                                "variant": variant,
                                "status": "error",
                                "error": str(exc),
                                "completed_steps": list(getattr(exc, "completed_steps", []) or []),
                            }
                        )
    except Exception as exc:
        all_differences.append(f"coverage validation error: {exc}")
        rows.append(
            {
                "workflow_id": None,
                "variant": None,
                "status": "error",
                "stage": "validation",
                "error": str(exc),
                "completed_steps": list(getattr(exc, "completed_steps", []) or []),
            }
        )
    finally:
        if report_path:
            _write_json(
                report_path,
                {
                    "schema_version": 1,
                    "coverage": coverage_counts,
                    "issue": 294,
                    "rows": rows,
                },
            )
    return all_differences


def generate_goldens(repo_root: Path, coverage_path: Path) -> dict[str, list[str]]:
    validate_coverage(repo_root, coverage_path)
    staged_trees: list[tuple[Path, Path]] = []
    generated: list[str] = []
    with tempfile.TemporaryDirectory(prefix="workflow-replay-generate-") as temp_name:
        temp = Path(temp_name)
        for workflow_id, spec_path, entry in _covered_specs(coverage_path):
            spec = load_yaml(spec_path)
            for variant in entry["variants"]:
                staged = temp / workflow_id / variant
                execute_replay(repo_root, spec_path, variant, staged)
                destination = (spec_path.parent / spec["variants"][variant]["golden_dir"]).resolve()
                staged_trees.append((staged, destination))
                generated.append(f"{workflow_id}:{variant}")
        _publish_trees_transactionally(staged_trees)
    return {"generated": generated}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate = subparsers.add_parser("validate", help="Validate coverage and replay specs")
    validate.add_argument("--coverage", type=Path, default=DEFAULT_COVERAGE)

    run = subparsers.add_parser("run", help="Run one replay variant")
    run.add_argument("--spec", type=Path, required=True)
    run.add_argument("--variant", choices=VARIANTS, required=True)
    run.add_argument("--output-dir", type=Path, required=True)

    check = subparsers.add_parser("check", help="Regenerate in temp and compare goldens")
    check.add_argument("--coverage", type=Path, default=DEFAULT_COVERAGE)
    check.add_argument("--report", type=Path)

    generate = subparsers.add_parser(
        "generate", help="Regenerate committed example goldens from source inputs"
    )
    generate.add_argument("--coverage", type=Path, default=DEFAULT_COVERAGE)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "validate":
        summary = validate_coverage(REPO_ROOT, args.coverage.resolve())
        print(json.dumps(summary, indent=2))
        return 0
    if args.command == "run":
        report = execute_replay(
            REPO_ROOT, args.spec.resolve(), args.variant, args.output_dir.resolve()
        )
        print(json.dumps(report, indent=2))
        return 0
    if args.command == "check":
        differences = check_goldens(
            REPO_ROOT,
            args.coverage.resolve(),
            args.report.resolve() if args.report else None,
        )
        if differences:
            print("Workflow replay drift detected:", file=sys.stderr)
            for difference in differences:
                print(f"- {difference}", file=sys.stderr)
            return 1
        print("Workflow replay goldens are current.")
        return 0
    if args.command == "generate":
        generate_goldens(REPO_ROOT, args.coverage.resolve())
        print("Workflow replay goldens regenerated.")
        return 0
    raise AssertionError(f"unhandled command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
