# Uptrend Analyzer - Calculator modules
